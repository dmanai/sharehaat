import { createFileRoute } from "@tanstack/react-router";
import { HaatSignIn } from "@/components/haat/signin";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

function LoginPage() {
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-phone flex-col justify-center bg-surface px-6">
      <p className="text-xs font-bold tracking-widest text-haat">SHAREHAAT</p>
      <h1 className="mt-2 text-3xl font-extrabold text-forest">Sign in to your haat</h1>
      <p className="mt-2 text-sm leading-relaxed text-ink-soft">
        Your seller details stay on your account. Lots you post are on the community board for everyone.
      </p>
      <div className="mt-6">
        <HaatSignIn callback="/" />
      </div>
    </main>
  );
}
