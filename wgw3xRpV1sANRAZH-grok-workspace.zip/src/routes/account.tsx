import { createFileRoute } from "@tanstack/react-router";
import { AccountScreen } from "@/components/haat/info";

export const Route = createFileRoute("/account")({
  component: AccountScreen,
});
