import { createFileRoute } from "@tanstack/react-router";
import { ListingScreen } from "@/components/haat/market";

export const Route = createFileRoute("/listing/$listingId")({
  component: ListingRoute,
});

function ListingRoute() {
  const { listingId } = Route.useParams();
  return <ListingScreen listingId={listingId} />;
}
