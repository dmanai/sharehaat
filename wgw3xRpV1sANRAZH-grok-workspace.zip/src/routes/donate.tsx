import { createFileRoute } from "@tanstack/react-router";
import { DonateScreen } from "@/components/haat/community";

export const Route = createFileRoute("/donate")({
  component: DonateScreen,
});
