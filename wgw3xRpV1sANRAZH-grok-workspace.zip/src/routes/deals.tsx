import { createFileRoute } from "@tanstack/react-router";
import { DealsScreen } from "@/components/haat/market";

export const Route = createFileRoute("/deals")({
  component: DealsScreen,
});
