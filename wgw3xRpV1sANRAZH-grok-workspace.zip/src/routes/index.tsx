import { createFileRoute } from "@tanstack/react-router";
import { HomeScreen } from "@/components/haat/market";

export const Route = createFileRoute("/")({
  component: HomeScreen,
});
