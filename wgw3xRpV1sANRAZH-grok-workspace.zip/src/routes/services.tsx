import { createFileRoute } from "@tanstack/react-router";
import { ServicesScreen } from "@/components/haat/community";

export const Route = createFileRoute("/services")({
  component: ServicesScreen,
});
