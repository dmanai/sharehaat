import { createFileRoute } from "@tanstack/react-router";
import { ContactScreen } from "@/components/haat/info";

export const Route = createFileRoute("/contact")({
  component: ContactScreen,
});
