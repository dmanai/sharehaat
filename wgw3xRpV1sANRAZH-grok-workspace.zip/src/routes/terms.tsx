import { createFileRoute } from "@tanstack/react-router";
import { TermsScreen } from "@/components/haat/info";

export const Route = createFileRoute("/terms")({
  component: TermsScreen,
});
