import { createFileRoute } from "@tanstack/react-router";
import { SchemesScreen } from "@/components/haat/info";

export const Route = createFileRoute("/schemes")({
  component: SchemesScreen,
});
