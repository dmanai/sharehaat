import { createFileRoute } from "@tanstack/react-router";
import { SellScreen } from "@/components/haat/market";

export const Route = createFileRoute("/sell")({
  validateSearch: (search: Record<string, unknown>): { kind?: "deal" } => {
    if (search.kind === "deal") return { kind: "deal" };
    return {};
  },
  component: SellRoute,
});

function SellRoute() {
  const { kind } = Route.useSearch();
  return <SellScreen initialKind={kind === "deal" ? "todays_deal" : "shop_item"} />;
}
