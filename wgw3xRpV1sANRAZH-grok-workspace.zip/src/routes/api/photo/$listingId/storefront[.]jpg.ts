import { createFileRoute } from "@tanstack/react-router";

function imageResponse(photoUrl: string) {
  if (photoUrl.startsWith("https://") || photoUrl.startsWith("http://")) {
    return Response.redirect(photoUrl, 302);
  }
  const match = /^data:(image\/(?:jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=\s]+)$/.exec(photoUrl);
  if (!match || !match[1] || !match[2]) return new Response("Not found", { status: 404 });
  const type = match[1] === "image/jpg" ? "image/jpeg" : match[1];
  const binary = atob(match[2].replace(/\s/g, ""));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return new Response(bytes, {
    status: 200,
    headers: {
      "Content-Type": type,
      "Content-Length": String(bytes.byteLength),
      "Cache-Control": "public, max-age=86400",
      "Content-Disposition": 'inline; filename="sharehaat.jpg"',
      "X-Content-Type-Options": "nosniff",
    },
  });
}

export const Route = createFileRoute("/api/photo/$listingId/storefront.jpg")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const parts = new URL(request.url).pathname.split("/").filter(Boolean);
        const id = decodeURIComponent(parts[2] ?? "");
        if (!/^[A-Za-z0-9_-]{4,80}$/.test(id)) return new Response("Not found", { status: 404 });
        const { getSql } = await import("@/lib/db");
        const sql = await getSql();
        const rows = await sql<{ photo_url: string; status: string }>`
          select photo_url, status from haat_listings where id = ${id} limit 1
        `;
        const row = rows[0];
        if (!row || row.status === "deleted" || !row.photo_url) return new Response("Not found", { status: 404 });
        return imageResponse(row.photo_url);
      },
    },
  },
});
