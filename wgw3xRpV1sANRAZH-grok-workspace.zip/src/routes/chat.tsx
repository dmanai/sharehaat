import { createFileRoute } from "@tanstack/react-router";
import { ChatScreen } from "@/components/haat/info";

export const Route = createFileRoute("/chat")({
  component: ChatScreen,
});
