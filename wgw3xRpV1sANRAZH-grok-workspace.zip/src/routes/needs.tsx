import { createFileRoute, Navigate } from "@tanstack/react-router";
import { NeedsScreen, type NeedTab } from "@/components/haat/community";

export const Route = createFileRoute("/needs")({
  validateSearch: (search: Record<string, unknown>): { tab?: NeedTab | "give" } => {
    const tab = search.tab;
    if (tab === "goods" || tab === "services" || tab === "providers" || tab === "give") {
      return { tab };
    }
    return {};
  },
  component: NeedsRoute,
});

function NeedsRoute() {
  const { tab } = Route.useSearch();
  if (tab === "give") return <Navigate to="/donate" />;
  return <NeedsScreen tab={tab ?? "goods"} />;
}