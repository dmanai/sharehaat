import { createFileRoute } from "@tanstack/react-router";
import { MyHaatScreen } from "@/components/haat/market";

export const Route = createFileRoute("/my-haat")({
  component: MyHaatScreen,
});
