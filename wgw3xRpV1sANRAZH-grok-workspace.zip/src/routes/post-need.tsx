import { createFileRoute } from "@tanstack/react-router";
import { PostNeedScreen } from "@/components/haat/community";

type Kind = "looking" | "donate" | "services";

export const Route = createFileRoute("/post-need")({
  validateSearch: (search: Record<string, unknown>): { kind?: Kind } => {
    if (search.kind === "donate" || search.kind === "services" || search.kind === "looking") {
      return { kind: search.kind };
    }
    return {};
  },
  component: PostRoute,
});

function PostRoute() {
  const { kind } = Route.useSearch();
  return <PostNeedScreen kind={kind ?? "looking"} />;
}
