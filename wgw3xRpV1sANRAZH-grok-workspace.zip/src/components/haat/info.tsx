import { useEffect, useState } from "react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { UserButton } from "@/lib/auth/gates";
import { deleteMyData, saveMyProfile } from "@/lib/haat/board";
import {
  advise,
  APP_BLURB,
  boardBrief,
  contactMessage,
  DISTRICTS,
  emptyProfile,
  FSSAI_DUTY,
  LEGAL_NOTICE,
  OPERATOR_NAME,
  OPERATOR_WHATSAPP,
  prettyPhone,
  PROHIBITED_NOTICE,
  SCHEMES,
  SELLER_TYPES,
  SERVICE_TRADES,
} from "@/lib/haat/data";
import { askHaat } from "@/lib/haat/ask";
import { useHaat } from "@/lib/haat/store";
import { explainFailure, refreshBoard } from "@/lib/haat/sync";
import { Field, fieldClass, openWa } from "./bits";
import { HaatShell } from "./shell";
import { HaatSignIn } from "./signin";

export function SchemesScreen() {
  return (
    <HaatShell title="Schemes" subtitle="Official desks. ShareHaat does not apply for you." back>
      <div className="space-y-3 px-4 pt-4">
        {SCHEMES.map((s) => (
          <article key={s.id} className="rounded-2xl border border-line bg-card p-4">
            <p className="text-[11px] font-bold tracking-wide text-haat">{s.who}</p>
            <h2 className="text-base font-bold text-forest">{s.name}</h2>
            <p className="mt-1 text-sm leading-relaxed text-ink-soft">{s.summary}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <a href={s.href} target="_blank" rel="noreferrer" className="inline-flex h-10 items-center rounded-lg bg-forest px-3 text-xs font-bold text-on-forest">
                Official site
              </a>
              {s.extraHref ? (
                <a href={s.extraHref} target="_blank" rel="noreferrer" className="inline-flex h-10 items-center rounded-lg border border-line px-3 text-xs font-bold text-forest">
                  {s.extraLabel ?? "State page"}
                </a>
              ) : null}
            </div>
          </article>
        ))}
      </div>
    </HaatShell>
  );
}

export function TermsScreen() {
  const cards = [
    { title: "What ShareHaat is", body: APP_BLURB },
    { title: "1. WhatsApp is the chat. ShareHaat is the board.", body: LEGAL_NOTICE },
    {
      title: "2. A simple storefront",
      body: "A listing is a name, photo, category, mobile, village or ward, district, and a rate. No PIN. No OTP. Lots can stay up 24 hrs, 36 hours, 72 hours, or 7, 12 or 15 days.",
    },
    { title: "3. Food and FSSAI", body: FSSAI_DUTY },
    {
      title: "4. Consignments and the road",
      body: "For a full harvest lot, the cooperative can help book an existing Sumo, town drop, or hired truck. Weight loss and spoilage in transit are not guaranteed. Goods money stays between buyer and seller.",
    },
    { title: "5. Prohibited items", body: PROHIBITED_NOTICE },
  ];
  return (
    <HaatShell title="About & Terms" subtitle="How the haat works" back>
      <div className="space-y-3 px-4 pt-4">
        <p className="text-xs font-semibold text-muted">{OPERATOR_NAME}</p>
        {cards.map((c) => (
          <article key={c.title} className="rounded-2xl border border-line bg-card p-4">
            <h2 className="text-sm font-bold text-forest">{c.title}</h2>
            <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{c.body}</p>
          </article>
        ))}
      </div>
    </HaatShell>
  );
}

export function ContactScreen() {
  const [voice, setVoice] = useState(false);
  const [sellerName, setSellerName] = useState("");
  const [itemName, setItemName] = useState("");
  const [rate, setRate] = useState("");
  const [qty, setQty] = useState("");
  const [mobile, setMobile] = useState("");
  const [error, setError] = useState("");

  return (
    <HaatShell title="I don't know how to sell" subtitle="We can list it for you on WhatsApp" back>
      <form
        className="space-y-3 px-4 pt-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!sellerName.trim() || !itemName.trim() || digitsOk(mobile) === false) {
            setError("Name, item and a 10-digit mobile are required.");
            return;
          }
          openWa(
            OPERATOR_WHATSAPP,
            contactMessage({ sellerName, itemName, rate, qty, mobile, voice }),
          );
        }}
      >
        <div className="rounded-2xl bg-mint/60 p-4">
          <p className="text-sm font-bold text-forest">Need help listing a harvest?</p>
          <p className="mt-1 text-xs leading-relaxed text-ink-soft">
            Send a photo or a voice note on WhatsApp (+91 {prettyPhone(OPERATOR_WHATSAPP)}). {OPERATOR_NAME} can put it on the board for you.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button type="button" onClick={() => setVoice(false)} className={`h-11 rounded-xl text-sm font-bold ${!voice ? "bg-forest text-on-forest" : "border border-line bg-card"}`}>
            Fill details
          </button>
          <button type="button" onClick={() => setVoice(true)} className={`h-11 rounded-xl text-sm font-bold ${voice ? "bg-wa text-on-forest" : "border border-line bg-card"}`}>
            Voice note
          </button>
        </div>
        <Field label="Seller’s name">
          <input className={fieldClass} value={sellerName} onChange={(e) => setSellerName(e.target.value)} />
        </Field>
        <Field label="Item name">
          <input className={fieldClass} value={itemName} onChange={(e) => setItemName(e.target.value)} />
        </Field>
        {!voice ? (
          <>
            <Field label="Rate">
              <input className={fieldClass} value={rate} onChange={(e) => setRate(e.target.value)} placeholder="₹350/kg" />
            </Field>
            <Field label="Quantity">
              <input className={fieldClass} value={qty} onChange={(e) => setQty(e.target.value)} />
            </Field>
          </>
        ) : null}
        <Field label="Mobile">
          <input className={fieldClass} inputMode="tel" value={mobile} onChange={(e) => setMobile(e.target.value)} />
        </Field>
        {error ? <p className="text-sm font-semibold text-deal">{error}</p> : null}
        <button type="submit" className="h-12 w-full rounded-xl bg-wa text-sm font-bold text-on-forest">
          Open WhatsApp
        </button>
      </form>
    </HaatShell>
  );
}

function digitsOk(value: string) {
  return value.replace(/\D/g, "").length >= 10;
}

export function AccountScreen() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <HaatShell title="Seller Profile" subtitle="Your particulars" back>
        <p className="px-4 py-8 text-sm text-muted">Opening your profile…</p>
      </HaatShell>
    );
  }
  if (!user) {
    return (
      <HaatShell title="Seller Profile" subtitle="Your particulars" back>
        <div className="space-y-3 px-4 pt-4">
          <p className="text-sm leading-relaxed text-ink-soft">
            Sign in once. Sell, donate and buyer needs will fill your name, WhatsApp and village. You can edit or clear them any time.
          </p>
          <HaatSignIn callback="/account" />
        </div>
      </HaatShell>
    );
  }
  return <AccountForm />;
}

function AccountForm() {
  const profile = useHaat((s) => s.profile);
  const profileReady = useHaat((s) => s.profileReady);
  const saveProfile = useHaat((s) => s.saveProfile);
  const [draft, setDraft] = useState(profile);
  const [primed, setPrimed] = useState(false);
  const [saved, setSaved] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!profileReady || primed) return;
    setDraft(profile);
    setPrimed(true);
  }, [profileReady, primed, profile]);

  async function persist(next = draft) {
    setBusy(true);
    setSaved("");
    try {
      const savedProfile = await saveMyProfile({
        data: {
          ...next,
          phone: next.phone.replace(/\D/g, "").slice(-10),
          name: next.name.trim(),
          place: next.place.trim(),
        },
      });
      saveProfile(savedProfile);
      setDraft(savedProfile);
      setSaved("Saved. Sell, donate and needs will use these details.");
    } catch (err) {
      setSaved(explainFailure(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <HaatShell title="Seller Profile" subtitle="Used whenever you sell, donate or post a need" back>
      <form
        className="space-y-3 px-4 pt-4"
        onSubmit={(e) => {
          e.preventDefault();
          void persist();
        }}
      >
        <UserButton />
        <p className="text-sm leading-relaxed text-ink-soft">
          These particulars fill in on Sell, Donate and Buyer’s Need. Change them here, or edit them on a post. Clear a field to remove it.
        </p>
        {!profileReady ? <p className="text-sm text-muted">Loading your saved details…</p> : null}
        <Field label="Name">
          <input className={fieldClass} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
        </Field>
        <Field label="WhatsApp">
          <input className={fieldClass} inputMode="tel" value={draft.phone} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} />
        </Field>
        <Field label="You usually sell as">
          <select className={fieldClass} value={draft.sellerType} onChange={(e) => setDraft({ ...draft, sellerType: e.target.value })}>
            {SELLER_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="District">
          <select className={fieldClass} value={draft.district} onChange={(e) => setDraft({ ...draft, district: e.target.value })}>
            {DISTRICTS.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </Field>
        <Field label="Village or ward">
          <input className={fieldClass} value={draft.place} onChange={(e) => setDraft({ ...draft, place: e.target.value })} />
        </Field>
        <label className="flex items-center gap-2 text-sm font-semibold">
          <input type="checkbox" checked={draft.isServiceProvider} onChange={(e) => setDraft({ ...draft, isServiceProvider: e.target.checked })} />
          I also take service jobs
        </label>
        {draft.isServiceProvider ? (
          <Field label="Trade">
            <select className={fieldClass} value={draft.serviceCategory} onChange={(e) => setDraft({ ...draft, serviceCategory: e.target.value })}>
              <option value="">Choose</option>
              {SERVICE_TRADES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </Field>
        ) : null}
        <button type="submit" disabled={busy} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60">
          Save particulars
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={() => {
            const cleared = { ...draft, name: "", phone: "", place: "", serviceCategory: "", isServiceProvider: false };
            setDraft(cleared);
            void persist(cleared);
          }}
          className="h-11 w-full rounded-xl border border-line text-sm font-bold text-ink-soft"
        >
          Clear my details
        </button>
        {confirmDelete ? (
          <button
            type="button"
            disabled={busy}
            onClick={() => {
              setBusy(true);
              void deleteMyData()
                .then(async () => {
                  const cleared = { ...emptyProfile, district: draft.district, sellerType: draft.sellerType };
                  saveProfile(cleared);
                  setDraft(cleared);
                  await refreshBoard();
                  setSaved("Your lots, needs and profile were deleted.");
                  setConfirmDelete(false);
                })
                .catch((err) => setSaved(explainFailure(err)))
                .finally(() => setBusy(false));
            }}
            className="h-11 w-full rounded-xl bg-deal text-sm font-bold text-on-forest"
          >
            Yes, delete my data
          </button>
        ) : (
          <button type="button" onClick={() => setConfirmDelete(true)} className="h-11 w-full text-sm font-semibold text-deal">
            Delete my data
          </button>
        )}
        {saved ? <p className="text-center text-sm font-semibold text-haat">{saved}</p> : null}
      </form>
    </HaatShell>
  );
}

type Role = "market" | "fast" | "deep";

export function ChatScreen() {
  const listings = useHaat((s) => s.listings);
  const needs = useHaat((s) => s.needs);
  const providers = useHaat((s) => s.providers);
  const [role, setRole] = useState<Role>("market");
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState<{ id: string; from: "user" | "bot"; text: string; tag: string }[]>([
    {
      id: "welcome",
      from: "bot",
      tag: "Ask ShareHaat",
      text: "Hello. Ask ShareHaat about a lot on the board, a district, a trade, packing, road drop, or a scheme such as PMFME.",
    },
  ]);

  const prompts = ["Raja mircha rate today", "Electrician near Dimapur", "How do I post a deal?", "PM-KISAN in short"];

  async function send(raw: string) {
    const message = raw.trim();
    if (message.length < 2 || busy) return;
    const id = `m-${Date.now()}`;
    setMessages((m) => [...m, { id, from: "user", text: message, tag: "" }]);
    setText("");
    setBusy(true);
    const ctx = { listings, needs, providers };
    const local = advise(message, role, ctx);
    let reply = local;
    let tag = "Haat board";
    try {
      const res = await askHaat({ data: { role, message, board: boardBrief(ctx) } });
      if (res.ok && res.text) {
        reply = res.text;
        tag = "Grok";
      }
    } catch {
      reply = local;
    }
    setMessages((m) => [...m, { id: `${id}-a`, from: "bot", text: reply, tag }]);
    setBusy(false);
  }

  return (
    <HaatShell title="Ask ShareHaat" subtitle={role === "fast" ? "Short answers" : role === "deep" ? "Harvest plan" : "Market & services"} back>
      <div className="flex min-h-[70dvh] flex-col px-4 pt-3">
        <div className="grid grid-cols-3 gap-1 rounded-xl bg-canvas p-1">
          {(
            [
              ["market", "Market"],
              ["fast", "Fast"],
              ["deep", "Plan"],
            ] as const
          ).map(([id, label]) => (
            <button key={id} type="button" onClick={() => setRole(id)} className={`h-9 rounded-lg text-xs font-bold ${role === id ? "bg-card text-forest shadow-card" : "text-muted"}`}>
              {label}
            </button>
          ))}
        </div>
        <div className="mt-3 flex-1 space-y-2">
          {messages.map((m) => (
            <div key={m.id} className={`max-w-[92%] rounded-2xl px-3 py-2 text-sm leading-relaxed whitespace-pre-wrap ${m.from === "user" ? "ml-auto bg-forest text-on-forest" : "bg-card text-ink border border-line"}`}>
              {m.tag ? <p className={`mb-1 text-[10px] font-bold ${m.from === "user" ? "text-sand" : "text-haat"}`}>{m.tag}</p> : null}
              {m.text}
            </div>
          ))}
          {busy ? <p className="text-xs text-muted">Checking the board…</p> : null}
        </div>
        <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
          {prompts.map((p) => (
            <button key={p} type="button" onClick={() => void send(p)} className="h-8 shrink-0 rounded-full border border-line bg-card px-3 text-[11px] font-semibold text-forest">
              {p}
            </button>
          ))}
        </div>
        <form
          className="mt-2 flex gap-2 pb-2"
          onSubmit={(e) => {
            e.preventDefault();
            void send(text);
          }}
        >
          <input className={fieldClass} value={text} onChange={(e) => setText(e.target.value)} placeholder="Ask about a lot, a trade, a scheme…" />
          <button type="submit" disabled={busy} className="h-12 shrink-0 rounded-xl bg-forest px-4 text-sm font-bold text-on-forest disabled:opacity-60">
            Send
          </button>
        </form>
      </div>
    </HaatShell>
  );
}
