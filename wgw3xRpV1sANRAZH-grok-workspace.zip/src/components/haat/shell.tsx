import { Link, useRouter } from "@tanstack/react-router";
import {
  ArrowLeft,
  BookOpen,
  CircleUser,
  ClipboardList,
  Hammer,
  HandHeart,
  Info,
  Menu,
  Phone,
  Plus,
  Store,
  X,
} from "lucide-react";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useBoardSync } from "@/lib/haat/sync";

type Tab = "home" | "donate" | "sell" | "needs" | null;

const NowContext = createContext(Date.now());

export function useNow() {
  return useContext(NowContext);
}

export function useClock() {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 30000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

export function HaatShell({
  title = "ShareHaat",
  subtitle,
  back = false,
  tab = null,
  account = false,
  children,
}: {
  title?: string;
  subtitle?: string;
  back?: boolean;
  tab?: Tab;
  account?: boolean;
  children: ReactNode;
}) {
  const router = useRouter();
  const [menu, setMenu] = useState(false);
  const [post, setPost] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  useBoardSync();

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 30000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <NowContext.Provider value={now}>
      <div className="mx-auto flex min-h-dvh w-full max-w-phone flex-col bg-surface shadow-[0_0_0_1px_var(--color-line)]">
        <header className="sticky top-0 z-30 border-b border-line bg-card">
          <div className="flex items-center gap-2 px-3 py-2.5">
            {back ? (
              <button
                type="button"
                aria-label="Back"
                onClick={() => {
                  if (window.history.length > 1) router.history.back();
                  else void router.navigate({ to: "/" });
                }}
                className="grid size-11 shrink-0 place-items-center rounded-full text-forest"
              >
                <ArrowLeft className="size-5" />
              </button>
            ) : (
              <span className="grid size-9 shrink-0 place-items-center rounded-full bg-mint text-forest">
                <Store className="size-5" />
              </span>
            )}
            <div className="min-w-0 flex-1">
              <p className="truncate text-lg font-extrabold leading-tight tracking-tight text-forest">{title}</p>
              {subtitle ? <p className="truncate text-xs font-semibold text-haat">{subtitle}</p> : null}
            </div>
            {account ? (
              <Link
                to="/account"
                aria-label="Your seller profile"
                className="grid size-11 place-items-center rounded-full text-forest"
              >
                <CircleUser className="size-6" />
              </Link>
            ) : null}
          </div>
        </header>

        <main className={tab === "home" ? (post ? "flex-1 pb-64" : "flex-1 pb-40") : tab ? "flex-1 pb-24" : "flex-1 pb-8"}>{children}</main>

        {tab === "home" ? (
          <div className="fixed bottom-[calc(4.35rem+env(safe-area-inset-bottom))] left-1/2 z-30 w-full max-w-phone -translate-x-1/2 px-3">
            {post ? (
              <div className="mb-2 rounded-2xl border border-line bg-card p-2 shadow-card">
                <p className="px-1 pb-2 text-xs font-semibold text-muted">Post on ShareHaat. Members get the form filled in.</p>
                <div className="grid grid-cols-3 gap-2">
                  <Link
                    to="/post-need"
                    search={{ kind: "donate" }}
                    onClick={() => setPost(false)}
                    className="flex h-14 items-center justify-center rounded-xl bg-mint text-sm font-bold text-forest"
                  >
                    Donate
                  </Link>
                  <Link
                    to="/sell"
                    onClick={() => setPost(false)}
                    className="flex h-14 items-center justify-center rounded-xl bg-forest text-sm font-bold text-on-forest"
                  >
                    Sell
                  </Link>
                  <Link
                    to="/post-need"
                    search={{ kind: "looking" }}
                    onClick={() => setPost(false)}
                    className="flex h-14 items-center justify-center rounded-xl bg-sand text-sm font-bold text-forest"
                  >
                    Needs
                  </Link>
                </div>
              </div>
            ) : null}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                aria-expanded={post}
                onClick={() => setPost((open) => !open)}
                className={`flex h-11 items-center justify-center rounded-xl text-sm font-bold text-on-forest shadow-card ${post ? "bg-haat" : "bg-forest"}`}
              >
                ShareHaat
              </button>
              <Link to="/chat" className="flex h-11 items-center justify-center rounded-xl bg-ash text-sm font-bold text-ink-soft shadow-card">
                Ask ShareHaat
              </Link>
            </div>
          </div>
        ) : null}

        {tab ? (
          <nav className="fixed bottom-0 left-1/2 z-40 w-full max-w-phone -translate-x-1/2 border-t border-line bg-card pb-[env(safe-area-inset-bottom)]">
            <ul className="grid grid-cols-5">
              <NavItem to="/" label="Market" active={tab === "home"} />
              <NavItem to="/donate" label="Donate" active={tab === "donate"} />
              <li>
                <Link to="/sell" className="flex flex-col items-center gap-0.5 px-1 pt-1.5 pb-2 text-forest">
                  <span className="grid size-9 place-items-center rounded-full bg-forest text-on-forest">
                    <Plus className="size-5" />
                  </span>
                  <span className="text-[11px] font-bold">Sell</span>
                </Link>
              </li>
              <NavItem to="/needs" label="Needs" active={tab === "needs"} />
              <li>
                <button
                  type="button"
                  onClick={() => setMenu(true)}
                  className="flex w-full flex-col items-center gap-0.5 px-1 pt-2 pb-2 text-muted"
                >
                  <Menu className="size-5" />
                  <span className="text-[11px] font-medium">Menu</span>
                </button>
              </li>
            </ul>
          </nav>
        ) : null}

        {menu ? <MenuSheet onClose={() => setMenu(false)} /> : null}
      </div>
    </NowContext.Provider>
  );
}

function NavItem({ to, label, active }: { to: "/" | "/donate" | "/needs"; label: string; active: boolean }) {
  const icon =
    label === "Market" ? <Store className="size-5" /> : label === "Donate" ? <HandHeart className="size-5" /> : <ClipboardList className="size-5" />;
  return (
    <li>
      <Link
        to={to}
        className={`flex flex-col items-center gap-0.5 px-1 pt-2.5 pb-2 ${active ? "text-forest" : "text-muted"}`}
      >
        <span className={`grid h-8 place-items-center rounded-full px-3 ${active ? "bg-mint" : ""}`}>{icon}</span>
        <span className={`text-[11px] ${active ? "font-bold" : "font-medium"}`}>{label}</span>
      </Link>
    </li>
  );
}

function MenuSheet({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-scrim/45" onClick={onClose}>
      <div
        role="dialog"
        aria-label="ShareHaat menu"
        className="max-h-[88dvh] w-full max-w-phone overflow-y-auto rounded-t-3xl bg-card px-4 pt-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-card"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-start justify-between gap-3">
          <div>
            <p className="text-xl font-bold text-forest">ShareHaat Menu</p>
            <p className="text-xs text-muted">Nagaland cooperative marketplace</p>
          </div>
          <button type="button" aria-label="Close menu" onClick={onClose} className="grid size-11 place-items-center text-muted">
            <X className="size-5" />
          </button>
        </div>
        <div className="space-y-2">
          <MenuLink to="/account" icon={<CircleUser className="size-5" />} tint="bg-sage text-forest" title="Seller Profile" subtitle="Name and WhatsApp, saved on your account" badge="You" onClick={onClose} />
          <MenuLink to="/my-haat" icon={<Store className="size-5" />} tint="bg-mint text-forest" title="My Haat" subtitle="Your storefront on the community board" badge="Store" onClick={onClose} />
          <MenuLink to="/contact" icon={<Phone className="size-5" />} tint="bg-mint text-haat" title="I don't know how to sell" subtitle="Send a photo or voice note on WhatsApp" badge="Help" onClick={onClose} />
          <MenuLink to="/services" icon={<Hammer className="size-5" />} tint="bg-mint text-forest" title="Register as Service Provider" subtitle="Electricians, plumbers, mechanics" badge="Free" onClick={onClose} />
          <MenuLink to="/schemes" icon={<BookOpen className="size-5" />} tint="bg-sand text-forest" title="Government Schemes" subtitle="PM-KISAN, PMFME, MOVCD-NER, FPOs" badge="Schemes" onClick={onClose} />
          <MenuLink to="/terms" icon={<Info className="size-5" />} tint="bg-canvas text-ink-soft" title="About & Community Terms" subtitle="No escrow, FSSAI, community rules" badge="Info" onClick={onClose} />
        </div>
      </div>
    </div>
  );
}

function MenuLink({
  to,
  icon,
  tint,
  title,
  subtitle,
  badge,
  onClick,
}: {
  to: "/services" | "/my-haat" | "/account" | "/schemes" | "/contact" | "/terms";
  icon: ReactNode;
  tint: string;
  title: string;
  subtitle: string;
  badge: string;
  onClick: () => void;
}) {
  return (
    <Link to={to} onClick={onClick} className="flex items-center gap-3 rounded-xl bg-surface px-3 py-3">
      <span className={`grid size-10 shrink-0 place-items-center rounded-full ${tint}`}>{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="truncate text-sm font-bold text-ink">{title}</span>
          <span className="rounded bg-mint px-1.5 py-0.5 text-[10px] font-bold text-forest">{badge}</span>
        </span>
        <span className="block truncate text-xs text-muted">{subtitle}</span>
      </span>
    </Link>
  );
}
