import { useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { createNeed, createProvider, saveMyProfile } from "@/lib/haat/board";
import {
  AREA_TYPES,
  BUYER_TYPES,
  digits,
  DISTRICTS,
  donateMessage,
  needSupplyMessage,
  prettyPhone,
  PRICE_UNITS,
  SERVICE_TRADES,
  serviceReply,
  type Profile,
} from "@/lib/haat/data";
import { useHaat, useHydrated } from "@/lib/haat/store";
import { explainFailure, refreshBoard } from "@/lib/haat/sync";
import { Field, fieldClass, MemberFillNote, openWa } from "./bits";
import { EmptyNote, NeedCard, ProviderCard } from "./cards";
import { HaatShell } from "./shell";
import { HaatSignIn } from "./signin";

export type NeedTab = "goods" | "services" | "providers";

export function NeedsScreen({ tab }: { tab: NeedTab }) {
  const ready = useHydrated();
  const needs = useHaat((s) => s.needs);
  const providers = useHaat((s) => s.providers);
  const reviews = useHaat((s) => s.reviews);
  const profile = useHaat((s) => s.profile);
  const navigate = useNavigate();
  const open = needs.filter((n) => n.status === "open");

  const tabs: { id: NeedTab; label: string }[] = [
    { id: "goods", label: "Looking" },
    { id: "services", label: "Services" },
    { id: "providers", label: "Trades" },
  ];

  return (
    <HaatShell title="Buyer’s Need" subtitle="Produce, bulk lots and skilled trades" back tab="needs">
      <div className="space-y-3 px-4 pt-3">
        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => void navigate({ to: "/needs", search: { tab: t.id } })}
              className={`h-9 shrink-0 rounded-full px-3 text-xs font-bold ${tab === t.id ? "bg-forest text-on-forest" : "bg-card text-ink-soft border border-line"}`}
            >
              {t.label}
            </button>
          ))}
        </div>
        {!ready ? <p className="text-sm text-muted">Loading the board…</p> : null}
        {tab === "providers" ? (
          <>
            <button type="button" onClick={() => void navigate({ to: "/services" })} className="h-11 w-full rounded-xl bg-mint text-sm font-bold text-forest">
              Register your trade — free listing
            </button>
            {providers.map((p) => (
              <ProviderCard
                key={p.id}
                provider={p}
                reviews={reviews}
                onChat={() =>
                  openWa(
                    p.phone,
                    `Hello ${p.providerName}, I found you on ShareHaat. I need a ${p.serviceCategory.toLowerCase()} in ${p.district}.`,
                  )
                }
              />
            ))}
          </>
        ) : null}
        {tab === "goods"
          ? open
              .filter((n) => n.kind !== "donate" && n.needCategoryType === "goods")
              .map((need) => (
                <NeedCard key={need.id} need={need} action="I can supply this" onAction={() => openWa(need.buyerPhone, needSupplyMessage(need))} />
              ))
          : null}
        {tab === "services"
          ? open
              .filter((n) => n.needCategoryType === "services")
              .map((need) => (
                <NeedCard
                  key={need.id}
                  need={need}
                  action="I can do this job"
                  onAction={() =>
                    openWa(
                      need.buyerPhone,
                      serviceReply(need, profile.name || "a ShareHaat provider", profile.serviceCategory || need.serviceCategory),
                    )
                  }
                />
              ))
          : null}
        {tab !== "providers" ? (
          <button
            type="button"
            onClick={() =>
              void navigate({
                to: "/post-need",
                search: {
                  kind: tab === "services" ? "services" : "looking",
                },
              })
            }
            className="h-12 w-full rounded-xl bg-deal text-sm font-bold text-on-forest"
          >
            {tab === "services" ? "Post a service need" : "Post what you are looking for"}
          </button>
        ) : null}
      </div>
    </HaatShell>
  );
}

export function DonateScreen() {
  const ready = useHydrated();
  const needs = useHaat((s) => s.needs);
  const navigate = useNavigate();
  const gifts = needs.filter((n) => n.status === "open" && n.kind === "donate");

  return (
    <HaatShell title="Donate" subtitle="Giveaways, separate from buyer needs" tab="donate">
      <div className="space-y-3 px-4 pt-4">
        <p className="rounded-2xl bg-mint px-3 py-3 text-xs leading-relaxed text-forest">
          Offer books, seeds, tools or a spare lot for free. Collectors chat you on WhatsApp. This is not a buyer need.
        </p>
        {!ready ? <p className="text-sm text-muted">Loading giveaways…</p> : null}
        {ready && gifts.length === 0 ? <EmptyNote>No giveaways yet. Offer one for a school, church or household.</EmptyNote> : null}
        {gifts.map((need) => (
          <NeedCard key={need.id} need={need} action="I can collect" onAction={() => openWa(need.buyerPhone, donateMessage(need))} />
        ))}
        <button
          type="button"
          onClick={() => void navigate({ to: "/post-need", search: { kind: "donate" } })}
          className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest"
        >
          Offer a giveaway
        </button>
      </div>
    </HaatShell>
  );
}

export function PostNeedScreen({ kind }: { kind: "looking" | "donate" | "services" }) {
  const profile = useHaat((s) => s.profile);
  const profileReady = useHaat((s) => s.profileReady);
  const saveProfile = useHaat((s) => s.saveProfile);
  const addNeed = useHaat((s) => s.addNeed);
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [item, setItem] = useState("");
  const [qty, setQty] = useState("1");
  const [unit, setUnit] = useState(kind === "services" ? "job" : "kg");
  const [budget, setBudget] = useState(kind === "donate" ? "0" : "");
  const [neededBy, setNeededBy] = useState("Within this week");
  const [buyerType, setBuyerType] = useState("Household");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [place, setPlace] = useState("");
  const [district, setDistrict] = useState("Dimapur");
  const [notes, setNotes] = useState("");
  const [trade, setTrade] = useState("Electrician");
  const [area, setArea] = useState("village");
  const [error, setError] = useState("");
  const [needsAuth, setNeedsAuth] = useState(false);
  const [busy, setBusy] = useState(false);
  const [seeded, setSeeded] = useState(false);

  useEffect(() => {
    if (!profileReady || seeded || isPending) return;
    setName(profile.name || (user && !user.isDevFallback ? user.displayName || "" : ""));
    setPhone(profile.phone);
    setPlace(profile.place);
    if (profile.district) setDistrict(profile.district);
    if (profile.serviceCategory) setTrade(profile.serviceCategory);
    setSeeded(true);
  }, [profileReady, seeded, profile, user, isPending]);

  const title = kind === "donate" ? "Giveaway details" : kind === "services" ? "Need a trade" : "Need details";
  const memberFilled = Boolean(profile.name || profile.phone || profile.place || (user && !user.isDevFallback && user.displayName));

  async function submit() {
    if (item.trim().length < 3) return setError("Say what you need or are giving.");
    if (name.trim().length < 2) return setError("Enter your name.");
    if (digits(phone).length < 10) return setError("Enter a 10-digit WhatsApp number.");
    if (place.trim().length < 2) return setError("Enter the place.");
    if (!isPending && !user) {
      setNeedsAuth(true);
      setError("Sign in so this post is on the community board.");
      return;
    }
    setBusy(true);
    const nextProfile: Profile = {
      ...profile,
      name: name.trim(),
      phone: digits(phone).slice(-10),
      district,
      place: place.trim(),
      serviceCategory: kind === "services" ? trade : profile.serviceCategory,
    };
    try {
      const need = await createNeed({
        data: {
          kind,
          item: item.trim(),
          qty: Number(qty) || 1,
          qtyUnit: unit,
          district,
          placeName: place.trim(),
          neededBy,
          budgetInr: kind === "donate" ? 0 : Number(budget) || 0,
          buyerType,
          buyerName: nextProfile.name,
          buyerPhone: nextProfile.phone,
          notes: notes.trim(),
          trade,
          areaType: area,
        },
      });
      addNeed(need);
      const saved = await saveMyProfile({ data: nextProfile });
      saveProfile(saved);
      await refreshBoard();
      if (kind === "donate") {
        void navigate({ to: "/donate" });
        return;
      }
      void navigate({ to: "/needs", search: { tab: kind === "services" ? "services" : "goods" } });
    } catch (err) {
      const message = explainFailure(err);
      setError(message);
      setNeedsAuth(/sign in/i.test(message));
      setBusy(false);
    }
  }

  return (
    <HaatShell title={title} subtitle={kind === "donate" ? "Giveaway form. Members are filled in." : "People reply on your WhatsApp"} back>
      <form
        className="space-y-3 px-4 pt-4"
        onSubmit={(e) => {
          e.preventDefault();
          void submit();
        }}
      >
        <MemberFillNote filled={memberFilled} />
        {kind === "services" ? (
          <Field label="Trade">
            <select className={fieldClass} value={trade} onChange={(e) => setTrade(e.target.value)}>
              {SERVICE_TRADES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </Field>
        ) : null}
        <Field label={kind === "donate" ? "What you are giving" : kind === "services" ? "Job to be done" : "What you are looking for"}>
          <input className={fieldClass} value={item} onChange={(e) => setItem(e.target.value)} placeholder="Hill ginger, carved table, inverter repair..." />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Quantity">
            <input className={fieldClass} inputMode="decimal" value={qty} onChange={(e) => setQty(e.target.value)} />
          </Field>
          <Field label="Unit">
            <select className={fieldClass} value={unit} onChange={(e) => setUnit(e.target.value)}>
              {(kind === "services" ? ["job", "machine", "installation", "day"] : PRICE_UNITS).map((u) => (
                <option key={u}>{u}</option>
              ))}
            </select>
          </Field>
        </div>
        {kind !== "donate" ? (
          <Field label={kind === "services" ? "Budget in ₹" : "Budget per unit in ₹"}>
            <input className={fieldClass} inputMode="decimal" value={budget} onChange={(e) => setBudget(e.target.value)} placeholder="Optional" />
          </Field>
        ) : null}
        <Field label="Needed by">
          <input className={fieldClass} value={neededBy} onChange={(e) => setNeededBy(e.target.value)} />
        </Field>
        <Field label="You are a">
          <select className={fieldClass} value={buyerType} onChange={(e) => setBuyerType(e.target.value)}>
            {BUYER_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="Area">
          <select className={fieldClass} value={area} onChange={(e) => setArea(e.target.value)}>
            {AREA_TYPES.map((a) => (
              <option key={a.key} value={a.key}>
                {a.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Village / town / colony">
          <input className={fieldClass} value={place} onChange={(e) => setPlace(e.target.value)} />
        </Field>
        <Field label="District">
          <select className={fieldClass} value={district} onChange={(e) => setDistrict(e.target.value)}>
            {DISTRICTS.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </Field>
        <Field label="Your name">
          <input className={fieldClass} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="WhatsApp mobile">
          <input className={fieldClass} inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </Field>
        <Field label="Details">
          <textarea className={`${fieldClass} h-24 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>
        {error ? <p className="text-sm font-semibold text-deal">{error}</p> : null}
        {needsAuth && !isPending && !user ? <HaatSignIn callback={kind === "donate" ? "/donate" : "/needs"} /> : null}
        <button type="submit" disabled={busy} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60">
          {busy ? "Posting…" : "Post on the board"}
        </button>
      </form>
    </HaatShell>
  );
}

export function ServicesScreen() {
  const profile = useHaat((s) => s.profile);
  const profileReady = useHaat((s) => s.profileReady);
  const addProvider = useHaat((s) => s.addProvider);
  const saveProfile = useHaat((s) => s.saveProfile);
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [trade, setTrade] = useState("Electrician");
  const [area, setArea] = useState("village");
  const [district, setDistrict] = useState("Dimapur");
  const [place, setPlace] = useState("");
  const [years, setYears] = useState("3");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState("");
  const [needsAuth, setNeedsAuth] = useState(false);
  const [busy, setBusy] = useState(false);
  const [seeded, setSeeded] = useState(false);

  useEffect(() => {
    if (!profileReady || seeded) return;
    setName(profile.name);
    setPhone(profile.phone);
    setPlace(profile.place);
    if (profile.serviceCategory) setTrade(profile.serviceCategory);
    if (profile.district) setDistrict(profile.district);
    setSeeded(true);
  }, [profileReady, seeded, profile]);

  return (
    <HaatShell title="Service Provider" subtitle="Free listing for rural and town trades" back>
      <form
        className="space-y-3 px-4 pt-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (name.trim().length < 2) return setError("Enter the workshop or your name.");
          if (digits(phone).length < 10) return setError("Enter a 10-digit WhatsApp number.");
          if (place.trim().length < 2) return setError("Enter town or village.");
          if (!isPending && !user) {
            setNeedsAuth(true);
            setError("Sign in to list your trade on the community board.");
            return;
          }
          setBusy(true);
          const nextProfile: Profile = {
            ...profile,
            name: name.trim(),
            phone: digits(phone).slice(-10),
            district,
            place: place.trim(),
            isServiceProvider: true,
            serviceCategory: trade,
          };
          void createProvider({
            data: {
              providerName: nextProfile.name,
              phone: nextProfile.phone,
              serviceCategory: trade,
              areaType: area,
              district,
              townOrVillage: nextProfile.place,
              experienceYears: Math.max(1, Number(years) || 1),
              description: description.trim(),
            },
          })
            .then(async (provider) => {
              addProvider(provider);
              const saved = await saveMyProfile({ data: nextProfile });
              saveProfile(saved);
              await refreshBoard();
              setDone(`Listed. Buyers can WhatsApp ${prettyPhone(provider.phone)}.`);
              setError("");
              window.setTimeout(() => void navigate({ to: "/needs", search: { tab: "providers" } }), 700);
            })
            .catch((err) => {
              const message = explainFailure(err);
              setError(message);
              setNeedsAuth(/sign in/i.test(message));
              setBusy(false);
            });
        }}
      >
        <p className="rounded-2xl bg-mint px-3 py-3 text-xs leading-relaxed text-forest">
          Free for now. A monthly fee may apply later. ShareHaat only introduces you — the job and the payment stay on WhatsApp.
        </p>
        <Field label="Name or workshop">
          <input className={fieldClass} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="WhatsApp">
          <input className={fieldClass} inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </Field>
        <Field label="Trade">
          <select className={fieldClass} value={trade} onChange={(e) => setTrade(e.target.value)}>
            {SERVICE_TRADES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="Years of work">
          <input className={fieldClass} inputMode="numeric" value={years} onChange={(e) => setYears(e.target.value)} />
        </Field>
        <Field label="Where you work">
          <select className={fieldClass} value={area} onChange={(e) => setArea(e.target.value)}>
            {AREA_TYPES.map((a) => (
              <option key={a.key} value={a.key}>
                {a.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Town or village">
          <input className={fieldClass} value={place} onChange={(e) => setPlace(e.target.value)} />
        </Field>
        <Field label="District">
          <select className={fieldClass} value={district} onChange={(e) => setDistrict(e.target.value)}>
            {DISTRICTS.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </Field>
        <Field label="What you take on">
          <textarea className={`${fieldClass} h-24 py-3`} value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        {error ? <p className="text-sm font-semibold text-deal">{error}</p> : null}
        {needsAuth && !isPending && !user ? <HaatSignIn callback="/services" /> : null}
        {done ? <p className="text-sm font-semibold text-haat">{done}</p> : null}
        <button type="submit" disabled={busy} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60">
          {busy ? "Listing…" : "List my trade"}
        </button>
      </form>
    </HaatShell>
  );
}
