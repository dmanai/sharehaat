import { Link } from "@tanstack/react-router";
import { Clock, MapPin, Share2, Star } from "lucide-react";
import { useState, type ReactNode } from "react";
import {
  placeOf,
  prettyPhone,
  qtyLabel,
  rateLabel,
  timeLeft,
  type Listing,
  type Need,
  type Provider,
  type Review,
} from "@/lib/haat/data";
import { useNow } from "./shell";

export function HaatPhoto({ src, alt, className }: { src?: string; alt: string; className?: string }) {
  const [ok, setOk] = useState(Boolean(src));
  if (!src || !ok) {
    return (
      <div className={`grid place-items-center bg-mint text-center text-xs font-bold text-forest ${className ?? ""}`}>
        <span className="px-3">Photo unavailable</span>
      </div>
    );
  }
  return <img src={src} alt={alt || "ShareHaat product photograph"} loading="lazy" className={`object-cover ${className ?? ""}`} onError={() => setOk(false)} />;
}

export function ListingCard({
  listing,
  rating,
  onChat,
  onShare,
}: {
  listing: Listing;
  rating?: { avg: number; count: number };
  onChat: () => void;
  onShare: () => void;
}) {
  const now = useNow();
  const deal = listing.listingKind === "todays_deal";
  return (
    <article className="overflow-hidden rounded-2xl bg-card shadow-card">
      <Link to="/listing/$listingId" params={{ listingId: listing.id }} className="relative block h-44">
        <HaatPhoto src={listing.photoUrl} alt={listing.title} className="h-44 w-full" />
        <span className={`absolute top-2.5 left-2.5 inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-bold text-on-forest ${deal ? "bg-deal" : "bg-forest"}`}>
          <Clock className="size-3" />
          {deal ? "Deal" : "Member"} · {timeLeft(listing.expiresAt, now)}
        </span>
        <span className="absolute top-2.5 right-2.5 rounded-lg bg-scrim/75 px-2 py-1 text-[11px] font-semibold text-on-forest">
          {listing.productCode}
        </span>
      </Link>
      <div className="space-y-2 p-3.5">
        <Link to="/listing/$listingId" params={{ listingId: listing.id }} className="block truncate text-base font-bold text-ink">
          {listing.title}
        </Link>
        <div className="flex items-baseline justify-between gap-2">
          <p className="text-base font-bold text-forest">{rateLabel(listing.priceInr, listing.priceUnit)}</p>
          <p className="text-xs text-muted">Avail: {qtyLabel(listing.qty, listing.qtyUnit)}</p>
        </div>
        <p className="flex items-center gap-1 text-xs text-ink-soft">
          <MapPin className="size-3.5 shrink-0 text-ochre" />
          <span className="truncate">{placeOf(listing.originPlace, listing.district)}</span>
        </p>
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-xs text-muted">
            Listed by {listing.sellerName}
            {listing.sellerType ? ` (${listing.sellerType})` : ""}
          </p>
          {rating && rating.count > 0 ? (
            <span className="inline-flex shrink-0 items-center gap-0.5 rounded bg-star-bg px-1.5 py-0.5 text-[10px] font-bold text-star">
              <Star className="size-3 fill-current" />
              {rating.avg.toFixed(1)} ({rating.count})
            </span>
          ) : null}
        </div>
        <div className="grid grid-cols-[1fr_auto] gap-2 pt-1">
          <button type="button" onClick={onChat} className="h-11 rounded-xl bg-wa text-sm font-bold text-on-forest">
            Contact Seller
          </button>
          <button type="button" onClick={onShare} aria-label="Share storefront" className="grid size-11 place-items-center rounded-xl border border-line text-forest">
            <Share2 className="size-4" />
          </button>
        </div>
      </div>
    </article>
  );
}

export function DealStory({ listing, onOpen }: { listing: Listing; onOpen: () => void }) {
  const now = useNow();
  return (
    <button type="button" onClick={onOpen} className="relative aspect-story w-32 shrink-0 overflow-hidden rounded-2xl text-left shadow-card">
      <HaatPhoto src={listing.photoUrl} alt={listing.title} className="absolute inset-0 h-full w-full" />
      <span className="absolute inset-0 bg-gradient-to-b from-scrim/55 via-transparent to-scrim/80" />
      <span className="absolute top-2 left-2 grid size-7 place-items-center rounded-full border-2 border-deal bg-forest text-[11px] font-bold text-on-forest">
        {listing.sellerName.slice(0, 1).toUpperCase()}
      </span>
      <span className="absolute top-2 right-2 rounded-md bg-deal px-1.5 py-0.5 text-[10px] font-bold text-on-forest">
        {timeLeft(listing.expiresAt, now)}
      </span>
      <span className="absolute inset-x-2 bottom-2 text-on-forest">
        <span className="block text-[11px] font-bold leading-tight">{listing.title}</span>
        <span className="mt-0.5 block text-[11px] font-semibold">{rateLabel(listing.priceInr, listing.priceUnit)}</span>
      </span>
    </button>
  );
}

export function NeedCard({
  need,
  action,
  onAction,
}: {
  need: Need;
  action: string;
  onAction: () => void;
}) {
  const donate = need.kind === "donate";
  const service = need.needCategoryType === "services";
  return (
    <article className="rounded-2xl border border-line bg-card p-3.5 shadow-card">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[11px] font-bold tracking-wide text-deal">{need.needCode}</p>
          <h3 className="text-sm font-bold text-ink">{need.item}</h3>
        </div>
        <span className="shrink-0 rounded-full bg-mint px-2 py-0.5 text-[10px] font-bold text-forest">
          {donate ? "Giveaway" : service ? need.serviceCategory || "Service" : "Looking"}
        </span>
      </div>
      <p className="mt-1 text-xs text-ink-soft">
        {qtyLabel(need.qty, need.qtyUnit)} · {placeOf(need.placeName, need.district)}
      </p>
      <p className="mt-1 text-xs text-muted">
        {need.buyerName} ({need.buyerType}) · {need.neededBy}
        {need.budgetInr ? ` · up to ${rateLabel(need.budgetInr, need.qtyUnit)}` : " · free"}
      </p>
      {need.notes ? <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-ink-soft">{need.notes}</p> : null}
      <button type="button" onClick={onAction} className="mt-3 h-11 w-full rounded-xl bg-forest text-sm font-bold text-on-forest">
        {action}
      </button>
    </article>
  );
}

export function ProviderCard({
  provider,
  reviews,
  onChat,
}: {
  provider: Provider;
  reviews: Review[];
  onChat: () => void;
}) {
  const rated = reviews.filter((r) => r.targetId === provider.phone || r.targetId === provider.id);
  const avg = rated.length ? rated.reduce((s, r) => s + r.rating, 0) / rated.length : 0;
  return (
    <article className="rounded-2xl border border-line bg-card p-3.5">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="text-sm font-bold text-ink">{provider.providerName}</h3>
          <p className="text-xs font-semibold text-haat">
            {provider.serviceCategory} · {provider.experienceYears} yrs
          </p>
        </div>
        {provider.isVerified ? (
          <span className="rounded-full bg-mint px-2 py-0.5 text-[10px] font-bold text-forest">Verified</span>
        ) : null}
      </div>
      <p className="mt-1 text-xs text-ink-soft">
        {provider.townOrVillage}, {provider.district} · {provider.areaType}
      </p>
      <p className="mt-2 text-xs leading-relaxed text-muted">{provider.description}</p>
      {rated.length ? (
        <p className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-star">
          <Star className="size-3 fill-current" /> {avg.toFixed(1)} ({rated.length})
        </p>
      ) : null}
      <button type="button" onClick={onChat} className="mt-3 h-11 w-full rounded-xl bg-wa text-sm font-bold text-on-forest">
        WhatsApp {prettyPhone(provider.phone)}
      </button>
    </article>
  );
}

export function SectionTitle({
  title,
  hint,
  action,
}: {
  title: string;
  hint?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex items-end justify-between gap-3">
      <div>
        <h2 className="text-lg font-bold text-ink">{title}</h2>
        {hint ? <p className="text-xs text-muted">{hint}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function EmptyNote({ children }: { children: ReactNode }) {
  return <p className="rounded-2xl border border-line bg-card px-4 py-6 text-center text-sm text-muted">{children}</p>;
}

export function Banner({
  title,
  hint,
  onClick,
}: {
  title: string;
  hint: string;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className="flex w-full items-center justify-between gap-3 rounded-xl bg-deal px-3.5 py-3 text-left text-on-forest">
      <span>
        <span className="block text-sm font-extrabold">{title}</span>
        <span className="block text-[11px] font-medium text-on-forest/90">{hint}</span>
      </span>
      <span aria-hidden className="text-lg">
        ›
      </span>
    </button>
  );
}
