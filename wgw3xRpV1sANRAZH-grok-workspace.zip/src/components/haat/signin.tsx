import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";

export function HaatSignIn({ callback = "/" }: { callback?: string }) {
  if (!authEnabled) {
    return <p className="text-sm text-muted">Sign-in is not available right now.</p>;
  }
  return (
    <div className="space-y-2">
      {GROK_PROVIDERS.map((provider) => (
        <button
          key={provider.providerId}
          type="button"
          onClick={() => signIn(provider.providerId, { callbackURL: callback })}
          className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest"
        >
          Continue with {provider.label}
        </button>
      ))}
    </div>
  );
}
