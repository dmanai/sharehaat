import { Camera, ImagePlus, SwitchCamera, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { readPhoto } from "@/lib/haat/data";
import { fitPhotoUnder300kb, jpegKilobytes } from "@/lib/haat/photo";
import { HaatPhoto } from "./cards";

export function PhotoField({
  value,
  onChange,
  onError,
}: {
  value: string;
  onChange: (url: string) => void;
  onError: (message: string) => void;
}) {
  const galleryRef = useRef<HTMLInputElement>(null);
  const captureRef = useRef<HTMLInputElement>(null);
  const [cam, setCam] = useState(false);

  async function useFile(file: File | undefined) {
    if (!file) return;
    try {
      onChange(await readPhoto(file));
      onError("");
    } catch (err) {
      onError(err instanceof Error ? err.message : "Could not read that photo.");
    }
  }

  return (
    <div className="space-y-2">
      <div className="overflow-hidden rounded-2xl border border-dashed border-haat bg-mint/40">
        {value ? (
          <HaatPhoto src={value} alt="Your storefront photo" className="h-52 w-full" />
        ) : (
          <div className="grid h-36 place-items-center px-4 text-center text-sm font-semibold text-forest">
            This photo is your storefront. It is kept under 300 KB so WhatsApp can show it.
          </div>
        )}
      </div>
      {value ? (
        <p className="text-center text-xs font-semibold text-haat">Ready for WhatsApp · {jpegKilobytes(value)} KB</p>
      ) : (
        <p className="text-center text-xs text-muted">Photos are resized under 300 KB automatically.</p>
      )}
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => setCam(true)} className="flex h-12 items-center justify-center gap-2 rounded-xl bg-forest text-sm font-bold text-on-forest">
          <Camera className="size-4" />
          Take photo
        </button>
        <button type="button" onClick={() => galleryRef.current?.click()} className="flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-card text-sm font-bold text-forest">
          <ImagePlus className="size-4" />
          Gallery
        </button>
      </div>
      {value ? (
        <button type="button" onClick={() => onChange("")} className="h-10 w-full text-xs font-semibold text-muted">
          Remove photo
        </button>
      ) : null}
      <input
        ref={galleryRef}
        type="file"
        accept="image/*"
        className="sr-only"
        onChange={(e) => {
          void useFile(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
      <input
        ref={captureRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="sr-only"
        onChange={(e) => {
          void useFile(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
      {cam ? (
        <CameraSheet
          onShot={(url) => {
            void fitPhotoUnder300kb(url)
              .then((fitted) => {
                onChange(fitted.dataUrl);
                onError("");
                setCam(false);
              })
              .catch(() => {
                onError("Could not prepare that photo under 300 KB.");
                setCam(false);
              });
          }}
          onClose={() => setCam(false)}
          onSystemCamera={() => {
            setCam(false);
            captureRef.current?.click();
          }}
        />
      ) : null}
    </div>
  );
}

function CameraSheet({
  onShot,
  onClose,
  onSystemCamera,
}: {
  onShot: (url: string) => void;
  onClose: () => void;
  onSystemCamera: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [facing, setFacing] = useState<"environment" | "user">("environment");
  const [ready, setReady] = useState(false);
  const [fail, setFail] = useState("");

  useEffect(() => {
    let cancelled = false;
    setReady(false);
    setFail("");
    const video = videoRef.current;

    async function start() {
      if (!navigator.mediaDevices?.getUserMedia) {
        setFail("This browser cannot open the camera here.");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 960 } },
        });
        if (cancelled) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }
        streamRef.current = stream;
        if (video) {
          video.srcObject = stream;
          await video.play();
        }
        setReady(true);
      } catch {
        if (!cancelled) setFail("Camera permission was blocked. Use the phone camera or your gallery.");
      }
    }

    void start();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      if (video) video.srcObject = null;
    };
  }, [facing]);

  function shoot() {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const max = 1600;
    const scale = Math.min(1, max / Math.max(video.videoWidth, video.videoHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
    canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    onShot(canvas.toDataURL("image/jpeg", 0.9));
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-scrim text-on-forest">
      <div className="flex items-center justify-between px-3 py-2">
        <button type="button" onClick={onClose} aria-label="Close camera" className="grid size-11 place-items-center">
          <X className="size-5" />
        </button>
        <p className="text-sm font-bold">Storefront photo</p>
        <button
          type="button"
          aria-label="Flip camera"
          onClick={() => setFacing((side) => (side === "environment" ? "user" : "environment"))}
          className="grid size-11 place-items-center"
        >
          <SwitchCamera className="size-5" />
        </button>
      </div>
      <div className="relative min-h-0 flex-1 bg-scrim">
        <video ref={videoRef} autoPlay playsInline muted className="h-full w-full object-cover" />
        {fail ? (
          <div className="absolute inset-0 grid place-items-center px-6 text-center">
            <div className="max-w-xs space-y-3">
              <p className="text-sm font-semibold">{fail}</p>
              <button type="button" onClick={onSystemCamera} className="h-11 w-full rounded-xl bg-card text-sm font-bold text-forest">
                Open phone camera
              </button>
            </div>
          </div>
        ) : null}
      </div>
      <div className="grid place-items-center px-4 pt-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]">
        <button
          type="button"
          aria-label="Take photo"
          disabled={!ready}
          onClick={shoot}
          className="grid size-16 place-items-center rounded-full border-4 border-on-forest bg-card disabled:opacity-40"
        >
          <span className="size-12 rounded-full bg-on-forest" />
        </button>
      </div>
    </div>
  );
}
