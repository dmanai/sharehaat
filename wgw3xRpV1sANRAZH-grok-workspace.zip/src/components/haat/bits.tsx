import type { ReactNode } from "react";
import { waLink } from "@/lib/haat/data";

export const fieldClass =
  "h-12 w-full rounded-xl border border-line bg-card px-3 text-sm font-medium text-ink outline-none focus:border-haat";

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold text-ink-soft">{label}</span>
      {children}
    </label>
  );
}

export function MemberFillNote({ filled }: { filled: boolean }) {
  if (!filled) return null;
  return (
    <p className="rounded-2xl bg-mint px-3 py-3 text-xs leading-relaxed text-forest">
      You are a registered member, so your name, WhatsApp and place are filled in. Change anything that is wrong.
    </p>
  );
}

export function origin() {
  if (typeof window === "undefined") return "";
  return window.location.origin;
}

export function openWa(phone: string, message: string) {
  window.open(waLink(phone, message), "_blank", "noopener,noreferrer");
}
