import { useNavigate } from "@tanstack/react-router";
import { ChevronDown, MapPin, Search, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { claimMyListing, createListing, createReview, patchGuestListing, patchMyListing, publishGuestListing, registerWhatsApp, saveMyProfile } from "@/lib/haat/board";
import {
  buyerMessage,
  CATEGORIES,
  consignmentMessage,
  digits,
  DISTRICTS,
  HANDOVER_OPTIONS,
  LISTING_SPANS,
  matchesCategory,
  OPERATOR_WHATSAPP,
  placeOf,
  PRICE_UNITS,
  qtyLabel,
  rateLabel,
  ratingFor,
  SELL_CATEGORIES,
  SELLER_TYPES,
  samePhone,
  timeLeft,
  type Listing,
  type ListingKind,
  type Profile,
} from "@/lib/haat/data";
import { shareResultNote, shareWithFriends } from "@/lib/haat/share-card";
import { fitPhotoUnder300kb } from "@/lib/haat/photo";
import {
  claimedListingIds,
  claimTokenFor,
  manageLink,
  readProfile,
  rememberClaim,
  rememberProfile,
  savePendingClaim,
  savePublishDraft,
  takePendingClaim,
  takePublishDraft,
  tokenFromLocation,
} from "@/lib/haat/guest";
import { useHaat, useHydrated } from "@/lib/haat/store";
import { explainFailure, refreshBoard } from "@/lib/haat/sync";
import { Field, fieldClass, MemberFillNote, openWa } from "./bits";
import { PhotoField } from "./camera";
import { DealStory, EmptyNote, HaatPhoto, ListingCard, SectionTitle } from "./cards";
import { HaatShell, useClock } from "./shell";
import { HaatSignIn } from "./signin";

export function HomeScreen() {
  const listings = useHaat((s) => s.listings);
  const needs = useHaat((s) => s.needs);
  const reviews = useHaat((s) => s.reviews);
  const now = useClock();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("all");
  const [district, setDistrict] = useState<string | null>(null);
  const [districtOpen, setDistrictOpen] = useState(false);
  const [shareNote, setShareNote] = useState("");

  function shareListing(listing: Listing) {
    const door = window.open("about:blank", "_blank");
    setShareNote("");
    void shareWithFriends(listing, door).then((result) => setShareNote(shareResultNote(result)));
  }

  const live = listings.filter((l) => l.status === "active" && l.expiresAt > now);
  const deals = live.filter((l) => l.listingKind === "todays_deal").sort((a, b) => Number(b.featured) - Number(a.featured));
  const members = live
    .filter((l) => matchesCategory(l, category))
    .filter((l) => !district || l.district === district)
    .filter((l) => {
      if (!q.trim()) return true;
      const blob = `${l.title} ${l.district} ${l.originPlace} ${l.productCode} ${l.sellerName}`.toLowerCase();
      return blob.includes(q.trim().toLowerCase());
    })
    .sort((a, b) => b.createdAt - a.createdAt);

  const looking = needs.filter((n) => n.status === "open" && n.kind !== "donate" && n.needCategoryType === "goods").slice(0, 2);

  return (
    <HaatShell subtitle="Photograph it. Share it. Sell it on WhatsApp." tab="home" account>
      <div className="space-y-4 px-4 pt-3">
        <div className="flex h-12 items-center gap-2 rounded-full border border-line bg-card px-3 shadow-card">
          <Search className="size-4 shrink-0 text-forest" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search produce, honey, chillies..."
            className="min-w-0 flex-1 bg-transparent text-sm font-medium text-ink outline-none placeholder:text-muted"
            suppressHydrationWarning
          />
          {q ? (
            <button type="button" aria-label="Clear search" onClick={() => setQ("")} className="text-muted">
              <X className="size-4" />
            </button>
          ) : null}
          <button
            type="button"
            onClick={() => setDistrictOpen(true)}
            className={`inline-flex max-w-28 items-center gap-0.5 rounded-full px-2 py-1 text-[11px] font-semibold ${district ? "bg-mint text-forest" : "bg-canvas text-ink"}`}
          >
            <MapPin className="size-3 shrink-0" />
            <span className="truncate">{district ?? "Nagaland"}</span>
            <ChevronDown className="size-3 shrink-0" />
          </button>
        </div>

        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
          {CATEGORIES.map((c) => {
            const on = category === c.key;
            return (
              <button
                key={c.key}
                type="button"
                onClick={() => setCategory(c.key)}
                className={`h-9 shrink-0 rounded-full border px-3 text-xs font-semibold ${on ? "border-forest bg-forest text-on-forest" : "border-line bg-card text-ink"}`}
              >
                {c.label}
              </button>
            );
          })}
        </div>

        <section>
          <SectionTitle
            title="ShareHaat Deals"
            action={
              <button type="button" onClick={() => void navigate({ to: "/deals" })} className="text-xs font-bold text-forest">
                View all
              </button>
            }
          />
          <span className="mt-1 inline-flex rounded bg-deal-soft px-1.5 py-0.5 text-[10px] font-bold text-deal">24h / 36h / 72h status</span>
          {deals.length === 0 ? (
            <EmptyNote>No active timed deals. Tap Sell to post a lot.</EmptyNote>
          ) : (
            <div className="no-scrollbar -mx-4 mt-2 flex gap-2 overflow-x-auto px-4">
              {deals.map((deal) => (
                <DealStory
                  key={deal.id}
                  listing={deal}
                  onOpen={() => void navigate({ to: "/listing/$listingId", params: { listingId: deal.id } })}
                />
              ))}
            </div>
          )}
        </section>

        <section className="space-y-3">
          <SectionTitle
            title="Community storefronts"
            hint={district ? `Lots in ${district}` : "Every photo on the board is visible to all"}
            action={<span className="rounded-xl bg-mint px-2 py-1 text-[11px] font-bold text-forest">{members.length} items</span>}
          />
          {members.length === 0 ? (
            <EmptyNote>
              No listings match.{" "}
              <button
                type="button"
                className="font-bold text-forest"
                onClick={() => {
                  setQ("");
                  setCategory("all");
                  setDistrict(null);
                }}
              >
                Reset filters
              </button>
            </EmptyNote>
          ) : (
            members.map((listing) => {
              const rating = ratingFor(reviews, [listing.sellerPhone, listing.userId]);
              return (
                <ListingCard
                  key={listing.id}
                  listing={listing}
                  rating={rating}
                  onChat={() => openWa(listing.sellerPhone, buyerMessage(listing))}
                  onShare={() => void shareListing(listing)}
                />
              );
            })
          )}
        </section>

        <button
          type="button"
          onClick={() => void navigate({ to: "/needs", search: { tab: "goods" } })}
          className="flex w-full items-center justify-between rounded-xl bg-deal px-3.5 py-3 text-left text-on-forest"
        >
          <span>
            <span className="block text-sm font-extrabold">Buyer’s Need & Looking For</span>
            <span className="block text-[11px]">Produce, bulk lots, and services such as electrician or mechanic</span>
          </span>
          <span aria-hidden>›</span>
        </button>
        {looking.length === 0 ? null : <p className="text-xs text-muted">Open asks include {looking.map((n) => n.item).join(" · ")}.</p>}

        {shareNote ? <p className="rounded-2xl bg-mint px-3 py-3 text-xs font-semibold text-forest">{shareNote}</p> : null}
        <p className="rounded-2xl border border-line bg-card px-4 py-5 text-center text-sm font-bold leading-snug text-forest">
          Your photo is your storefront. Everyone on ShareHaat can see it, and buyers chat you on WhatsApp.
        </p>
      </div>
      {districtOpen ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-scrim/45" onClick={() => setDistrictOpen(false)}>
          <div className="max-h-[70dvh] w-full max-w-phone overflow-y-auto rounded-t-3xl bg-card p-3" onClick={(e) => e.stopPropagation()}>
            <p className="px-2 py-2 text-sm font-bold text-forest">District</p>
            <button
              type="button"
              className="block w-full rounded-xl px-3 py-3 text-left text-sm font-semibold"
              onClick={() => {
                setDistrict(null);
                setDistrictOpen(false);
              }}
            >
              All of Nagaland
            </button>
            {DISTRICTS.map((d) => (
              <button
                key={d}
                type="button"
                className="block w-full rounded-xl px-3 py-3 text-left text-sm"
                onClick={() => {
                  setDistrict(d);
                  setDistrictOpen(false);
                }}
              >
                {d}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </HaatShell>
  );
}

export function DealsScreen() {
  const ready = useHydrated();
  const listings = useHaat((s) => s.listings);
  const reviews = useHaat((s) => s.reviews);
  const now = useClock();
  const navigate = useNavigate();
  const [shareNote, setShareNote] = useState("");
  const deals = listings
    .filter((l) => l.status === "active" && l.listingKind === "todays_deal" && l.expiresAt > now)
    .sort((a, b) => a.expiresAt - b.expiresAt);

  return (
    <HaatShell title="ShareHaat Deals" subtitle="Timed lots (24, 36 and 72 hours)" back tab="home">
      <div className="space-y-3 px-4 pt-4">
        <div className="flex items-center justify-between gap-3 rounded-2xl bg-deal-soft p-3.5">
          <div>
            <p className="text-sm font-bold text-deal">Today’s flash deals</p>
            <p className="text-xs text-ink-soft">Short lots from fields, kitchens and makers.</p>
          </div>
          <button
            type="button"
            onClick={() => void navigate({ to: "/sell", search: { kind: "deal" } })}
            className="h-10 shrink-0 rounded-lg bg-deal px-3 text-xs font-bold text-on-forest"
          >
            Post deal
          </button>
        </div>
        {!ready ? <p className="text-sm text-muted">Loading deals…</p> : null}
        {ready && deals.length === 0 ? <EmptyNote>No live deals. Post one before the lot moves.</EmptyNote> : null}
        {deals.map((listing) => (
          <ListingCard
            key={listing.id}
            listing={listing}
            rating={ratingFor(reviews, [listing.sellerPhone])}
            onChat={() => openWa(listing.sellerPhone, buyerMessage(listing))}
            onShare={() => {
              const door = window.open("about:blank", "_blank");
              setShareNote("");
              void shareWithFriends(listing, door).then((result) => setShareNote(shareResultNote(result)));
            }}
          />
        ))}
        {shareNote ? <p className="rounded-2xl bg-mint px-3 py-3 text-xs font-semibold text-forest">{shareNote}</p> : null}
      </div>
    </HaatShell>
  );
}

export function SellScreen({ initialKind }: { initialKind: ListingKind }) {
  const profile = useHaat((s) => s.profile);
  const profileReady = useHaat((s) => s.profileReady);
  const saveProfile = useHaat((s) => s.saveProfile);
  const addListing = useHaat((s) => s.addListing);
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("spices");
  const [price, setPrice] = useState("");
  const [unit, setUnit] = useState("kg");
  const [qty, setQty] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [sellerType, setSellerType] = useState("Farmer");
  const [place, setPlace] = useState("");
  const [district, setDistrict] = useState("Dimapur");
  const [handover, setHandover] = useState(HANDOVER_OPTIONS[0]);
  const [landmark, setLandmark] = useState("");
  const [notes, setNotes] = useState("");
  const [photo, setPhoto] = useState("");
  const [hours, setHours] = useState<number>(initialKind === "todays_deal" ? 24 : 24);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [uploadNote, setUploadNote] = useState("");
  const [seeded, setSeeded] = useState(false);
  const [stage, setStage] = useState<"form" | "review" | "account" | "live">("form");
  const [live, setLive] = useState<{ listing: Listing; claimToken: string } | null>(null);
  const resumed = useRef(false);

  function draftBody(photoUrl = photo) {
    return {
      title: title.trim(),
      category,
      priceInr: Number(price),
      priceUnit: unit,
      qty: Number(qty),
      qtyUnit: unit,
      sellerName: name.trim(),
      sellerPhone: digits(phone).slice(-10),
      sellerType,
      district,
      originPlace: place.trim(),
      handover,
      landmark: landmark.trim(),
      notes: notes.trim(),
      photoUrl,
      hours,
    };
  }

  async function publishAccount(body = draftBody()) {
    const listing = await createListing({ data: body });
    const nextProfile: Profile = {
      ...profile,
      name: body.sellerName,
      phone: body.sellerPhone,
      sellerType: body.sellerType,
      district: body.district,
      place: body.originPlace,
    };
    const saved = await saveMyProfile({ data: nextProfile });
    saveProfile(saved);
    return { listing, claimToken: "" };
  }

  async function publishChosen(mode: "account" | "guest" | "profile", profileKey = "", body = draftBody()) {
    setError("");
    setUploadNote("Uploading photo...");
    setBusy(true);
    try {
      const published =
        mode === "account"
          ? await publishAccount(body)
          : await publishGuestListing({ data: { ...body, profileKey } });
      if (published.claimToken) rememberClaim(published.listing.id, published.claimToken);
      addListing(published.listing);
      setLive({ listing: published.listing, claimToken: published.claimToken });
      setUploadNote("ShareHaat listing ready ✓");
      setStage("live");
      await refreshBoard();
    } catch (err) {
      const message = explainFailure(err);
      setUploadNote("");
      setError(message === "Photo is larger than 300 KB" ? message : /photo|upload/i.test(message) ? "Photo upload failed — Please try again." : message);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (!profileReady || seeded || isPending) return;
    setName(profile.name || (user && !user.isDevFallback ? user.displayName || "" : ""));
    setPhone(profile.phone);
    setSellerType(profile.sellerType || "Farmer");
    setPlace(profile.place);
    setDistrict(profile.district || "Dimapur");
    setSeeded(true);
  }, [profileReady, seeded, profile, user, isPending]);

  useEffect(() => {
    if (!user || isPending || resumed.current) return;
    const pending = takePublishDraft<ReturnType<typeof draftBody>>();
    if (!pending?.photoUrl) return;
    resumed.current = true;
    setTitle(pending.title);
    setPhoto(pending.photoUrl);
    void publishChosen("account", "", pending);
  }, [user, isPending]);

  async function submit() {
    if (!photo) return setError("Take a photo or choose one from your gallery.");
    if (title.trim().length < 3) return setError("Name the item.");
    if (!Number(price) || Number(price) <= 0) return setError("Enter a price in rupees.");
    if (!Number(qty) || Number(qty) <= 0) return setError("Enter the quantity available.");
    if (name.trim().length < 2) return setError("Enter the seller name.");
    if (digits(phone).length < 10) return setError("Enter a 10-digit WhatsApp number.");
    if (place.trim().length < 2) return setError("Enter the village, khel, ward or town.");
    setError("");
    setUploadNote("");
    setBusy(true);
    try {
      const fitted = await fitPhotoUnder300kb(photo);
      setPhoto(fitted.dataUrl);
      setStage("review");
    } catch {
      setError("Could not prepare that photo under 300 KB. Take it again.");
    } finally {
      setBusy(false);
    }
  }

  if (stage === "live" && live) {
    const link = live.claimToken ? manageLink(live.listing.id, live.claimToken) : `${window.location.origin}/listing/${live.listing.id}`;
    return (
      <HaatShell title="Community Haat" subtitle={live.listing.productCode} back tab="sell">
        <div className="space-y-3 px-4 pt-4">
          <HaatPhoto src={live.listing.photoUrl} alt="ShareHaat product photograph" className="h-52 w-full rounded-2xl" />
          <h1 className="text-xl font-bold">Your Community Haat listing is live.</h1>
          <p className="text-sm text-muted">
            {live.listing.title} · {rateLabel(live.listing.priceInr, live.listing.priceUnit)} · {qtyLabel(live.listing.qty, live.listing.qtyUnit)}
          </p>
          <button type="button" onClick={() => void navigate({ to: "/listing/$listingId", params: { listingId: live.listing.id } })} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest">
            View My Listing
          </button>
          <button
            type="button"
            onClick={() => {
              const door = window.open("about:blank", "_blank");
              void shareWithFriends(live.listing, door);
            }}
            className="h-12 w-full rounded-xl bg-wa text-sm font-bold text-on-forest"
          >
            Share on WhatsApp
          </button>
          <p className="text-sm text-ink">Save this link to manage your listing later.</p>
          <button
            type="button"
            onClick={() => void navigator.clipboard.writeText(link)}
            className="h-12 w-full rounded-xl border border-forest text-sm font-bold text-forest"
          >
            Copy Listing Link
          </button>
          <p className="text-xs leading-relaxed text-muted">You can create an account later to manage your listings. The lot stays up for the time you chose, even if you close this page.</p>
        </div>
      </HaatShell>
    );
  }

  if (stage === "review" || stage === "account") {
    return (
      <HaatShell title="Review listing" subtitle="Community Haat" back tab="sell">
        <div className="space-y-3 px-4 pt-4">
          <HaatPhoto src={photo} alt="ShareHaat product photograph" className="h-52 w-full rounded-2xl" />
          <div>
            <h1 className="text-xl font-bold">{title.trim()}</h1>
            <p className="text-sm text-muted">
              {rateLabel(Number(price), unit)} · {qtyLabel(Number(qty), unit)} · {place.trim()}
            </p>
            <p className="text-sm text-muted">{handover}</p>
          </div>
          {uploadNote ? <p className="text-sm font-semibold text-forest">{uploadNote}</p> : null}
          {error ? <p className="text-sm font-semibold text-deal">{error}</p> : null}
          {user ? (
            <button type="button" disabled={busy} onClick={() => void publishChosen("account")} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60">
              {busy ? "Uploading photo..." : "Publish to Community Haat"}
            </button>
          ) : stage === "account" ? (
            <form
              className="space-y-3"
              onSubmit={(e) => {
                e.preventDefault();
                if (name.trim().length < 2) return setError("Enter your name.");
                if (digits(phone).length < 10) return setError("Enter a 10-digit WhatsApp number.");
                setBusy(true);
                void registerWhatsApp({ data: { name: name.trim(), phone: digits(phone).slice(-10) } })
                  .then((profile) => {
                    rememberProfile(profile);
                    return publishChosen("profile", profile.key);
                  })
                  .catch((err) => {
                    setError(explainFailure(err));
                    setBusy(false);
                  });
              }}
            >
              <p className="text-sm font-bold">Register with Name + WhatsApp</p>
              <Field label="Name">
                <input className={fieldClass} value={name} onChange={(e) => setName(e.target.value)} />
              </Field>
              <Field label="WhatsApp Number">
                <input className={fieldClass} inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </Field>
              <button type="submit" disabled={busy} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60">
                {busy ? "Uploading photo..." : "Create ShareHaat Profile"}
              </button>
              <button type="button" onClick={() => setStage("review")} className="h-11 w-full text-sm font-bold text-muted">
                Back
              </button>
            </form>
          ) : (
            <div className="space-y-3">
              <p className="text-base font-bold">Ready to publish on Community Haat?</p>
              <p className="text-sm text-muted">You can publish without registering.</p>
              <button type="button" disabled={busy} onClick={() => void publishChosen("guest")} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60">
                {busy ? "Uploading photo..." : "Publish without registration"}
              </button>
              <p className="text-center text-xs font-bold text-muted">OR</p>
              <p className="text-sm font-bold">Create your ShareHaat profile</p>
              <button
                type="button"
                onClick={() => {
                  savePublishDraft(draftBody());
                  void signIn("grok-google", { callbackURL: "/sell" });
                }}
                className="h-12 w-full rounded-xl border border-forest text-sm font-bold text-forest"
              >
                Continue with Google
              </button>
              <button type="button" onClick={() => setStage("account")} className="h-12 w-full rounded-xl border border-line text-sm font-bold text-ink">
                Register with Name + WhatsApp
              </button>
              <p className="text-xs leading-relaxed text-muted">You can create an account later to manage your listings.</p>
            </div>
          )}
          <button type="button" onClick={() => setStage("form")} className="h-11 w-full text-sm font-bold text-muted">
            Edit listing
          </button>
        </div>
      </HaatShell>
    );
  }

  return (
    <HaatShell title="Sell on ShareHaat" subtitle="Photo, rate, WhatsApp. The lot is public." back tab="sell">
      <form
        className="space-y-3 px-4 pt-4"
        onSubmit={(e) => {
          e.preventDefault();
          void submit();
        }}
      >
        <MemberFillNote filled={Boolean(profile.name || profile.phone || profile.place || (user && !user.isDevFallback && user.displayName))} />
        <PhotoField value={photo} onChange={setPhoto} onError={setError} />
        <Field label="Item name">
          <input className={fieldClass} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Fresh King Chilli (Raja Mircha)" />
        </Field>
        <Field label="Category">
          <select className={fieldClass} value={category} onChange={(e) => setCategory(e.target.value)}>
            {SELL_CATEGORIES.map((c) => (
              <option key={c.key} value={c.key}>
                {c.label}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Price in ₹">
            <input className={fieldClass} inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="350" />
          </Field>
          <Field label="Per unit">
            <select className={fieldClass} value={unit} onChange={(e) => setUnit(e.target.value)}>
              {PRICE_UNITS.map((u) => (
                <option key={u}>{u}</option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="Quantity available">
          <input className={fieldClass} inputMode="decimal" value={qty} onChange={(e) => setQty(e.target.value)} placeholder="50" />
        </Field>
        <div>
          <p className="mb-1.5 text-xs font-semibold text-ink-soft">How long it stays on the board</p>
          <div className="flex flex-wrap gap-2">
            {LISTING_SPANS.map((span) => (
              <button
                key={span.hours}
                type="button"
                onClick={() => setHours(span.hours)}
                className={`h-9 rounded-full px-3 text-xs font-bold ${hours === span.hours ? "bg-forest text-on-forest" : "border border-line bg-card text-ink-soft"}`}
              >
                {span.label}
              </button>
            ))}
          </div>
        </div>
        <Field label="Seller name">
          <input className={fieldClass} value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name" />
        </Field>
        <Field label="WhatsApp mobile">
          <input className={fieldClass} inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="10-digit mobile" />
        </Field>
        <Field label="Seller type">
          <select className={fieldClass} value={sellerType} onChange={(e) => setSellerType(e.target.value)}>
            {SELLER_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="Village / khel / ward / town">
          <input className={fieldClass} value={place} onChange={(e) => setPlace(e.target.value)} placeholder="Longkhum village" />
        </Field>
        <Field label="District in Nagaland">
          <select className={fieldClass} value={district} onChange={(e) => setDistrict(e.target.value)}>
            {DISTRICTS.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </Field>
        <Field label="Handover">
          <select className={fieldClass} value={handover} onChange={(e) => setHandover(e.target.value)}>
            {HANDOVER_OPTIONS.map((h) => (
              <option key={h}>{h}</option>
            ))}
          </select>
        </Field>
        <Field label="Landmark / station">
          <input className={fieldClass} value={landmark} onChange={(e) => setLandmark(e.target.value)} placeholder="Mokokchung NST Station" />
        </Field>
        <Field label="Notes">
          <textarea className={`${fieldClass} h-24 py-3`} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Organic harvest, packed in bamboo lots..." />
        </Field>
        {uploadNote ? <p className="text-sm font-semibold text-forest">{uploadNote}</p> : null}
        {error ? <p className="text-sm font-semibold text-deal">{error}</p> : null}
        <button type="submit" disabled={busy} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60">
          {busy ? "Preparing photo..." : "Publish to Community Haat"}
        </button>
        <p className="pb-2 text-center text-[11px] leading-relaxed text-muted">
          Your photo becomes the storefront and the WhatsApp card. ShareHaat never takes money for goods.
        </p>
      </form>
    </HaatShell>
  );
}

export function ListingScreen({ listingId }: { listingId: string }) {
  const ready = useHydrated();
  const listing = useHaat((s) => s.listings.find((l) => l.id === listingId));
  const reviews = useHaat((s) => s.reviews);
  const profile = useHaat((s) => s.profile);
  const addReview = useHaat((s) => s.addReview);
  const now = useClock();
  const [sharing, setSharing] = useState(false);
  const [stars, setStars] = useState(5);
  const [comment, setComment] = useState("");
  const [buyerPlace, setBuyerPlace] = useState("");
  const [preference, setPreference] = useState("Sumo / NST drop");
  const [sent, setSent] = useState("");
  const [shareNote, setShareNote] = useState("");
  const [manageToken, setManageToken] = useState("");
  const [claimMode, setClaimMode] = useState<"closed" | "choices" | "whatsapp">("closed");
  const [claimName, setClaimName] = useState("");
  const [claimPhone, setClaimPhone] = useState("");
  const [claimNote, setClaimNote] = useState("");
  const patchListing = useHaat((s) => s.patchListing);
  const { user } = useCurrentUserState();

  useEffect(() => {
    setManageToken(tokenFromLocation(listingId));
  }, [listingId]);

  useEffect(() => {
    if (!user) return;
    const pending = takePendingClaim();
    if (!pending) return;
    if (pending.listingId !== listingId) {
      savePendingClaim(pending.listingId, pending.token);
      return;
    }
    void claimMyListing({ data: pending })
      .then(() => {
        patchListing(listingId, { userId: user.id });
        setClaimNote("This listing is now on your ShareHaat profile.");
        setClaimMode("closed");
        return refreshBoard();
      })
      .catch((err) => setClaimNote(explainFailure(err)));
  }, [user, listingId, patchListing]);

  const rated = useMemo(
    () => (listing ? ratingFor(reviews, [listing.sellerPhone, listing.userId]) : { avg: 0, count: 0, items: [] }),
    [listing, reviews],
  );

  if (!ready) {
    return (
      <HaatShell title="Listing" back>
        <p className="px-4 py-8 text-sm text-muted">Opening the lot…</p>
      </HaatShell>
    );
  }

  if (!listing || listing.status === "deleted") {
    return (
      <HaatShell title="Listing" back>
        <EmptyNote>This listing is not on the board.</EmptyNote>
      </HaatShell>
    );
  }

  const deal = listing.listingKind === "todays_deal";

  return (
    <HaatShell title="Lot" subtitle={listing.productCode} back>
      <div>
        <div className="relative">
          <HaatPhoto src={listing.photoUrl} alt={listing.title} className="h-72 w-full" />
          <span className={`absolute top-3 left-3 inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-bold text-on-forest ${deal ? "bg-deal" : "bg-forest"}`}>
            {deal ? "Deal" : "Member"} · {timeLeft(listing.expiresAt, now)}
          </span>
          <span className="absolute top-3 right-3 rounded-lg bg-scrim/75 px-2.5 py-1 text-xs font-bold text-on-forest">{listing.productCode}</span>
        </div>
        <div className="space-y-3 px-4 py-4">
          <h1 className="text-2xl font-bold leading-tight text-ink">{listing.title}</h1>
          <div className="flex items-end justify-between rounded-2xl bg-mint/70 px-4 py-3">
            <div>
              <p className="text-xs text-muted">Rate</p>
              <p className="text-xl font-bold text-forest">{rateLabel(listing.priceInr, listing.priceUnit)}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted">Available</p>
              <p className="text-base font-bold">{qtyLabel(listing.qty, listing.qtyUnit)}</p>
            </div>
          </div>
          <button type="button" onClick={() => openWa(listing.sellerPhone, buyerMessage(listing))} className="h-14 w-full rounded-xl bg-wa text-base font-bold text-on-forest">
            Contact Seller on WhatsApp
          </button>
          <button
            type="button"
            disabled={sharing}
            onClick={() => {
              const door = window.open("about:blank", "_blank");
              setSharing(true);
              setShareNote("");
              void shareWithFriends(listing, door)
                .then((result) => setShareNote(shareResultNote(result)))
                .finally(() => setSharing(false));
            }}
            className="h-14 w-full rounded-xl bg-forest text-base font-bold text-on-forest disabled:opacity-60"
          >
            {sharing ? "Opening WhatsApp…" : "Share on WhatsApp"}
          </button>
          {shareNote ? <p className="text-xs font-semibold text-haat">{shareNote}</p> : null}
          {manageToken && listing.userId === "guest" ? (
            <section className="space-y-2 rounded-2xl border border-line bg-card p-3.5">
              <p className="text-sm font-bold">Already published without an account?</p>
              {claimMode === "closed" ? (
                <button type="button" onClick={() => setClaimMode("choices")} className="h-11 w-full rounded-xl bg-forest text-sm font-bold text-on-forest">
                  Claim this listing
                </button>
              ) : null}
              {claimMode === "choices" ? (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      savePendingClaim(listing.id, manageToken);
                      void signIn("grok-google", { callbackURL: `/listing/${listing.id}` });
                    }}
                    className="h-11 w-full rounded-xl border border-forest text-sm font-bold text-forest"
                  >
                    Continue with Google
                  </button>
                  <button type="button" onClick={() => setClaimMode("whatsapp")} className="h-11 w-full rounded-xl border border-line text-sm font-bold text-ink">
                    Register with Name + WhatsApp
                  </button>
                </>
              ) : null}
              {claimMode === "whatsapp" ? (
                <form
                  className="space-y-2"
                  onSubmit={(e) => {
                    e.preventDefault();
                    void registerWhatsApp({
                      data: { name: claimName.trim(), phone: digits(claimPhone).slice(-10), listingId: listing.id, claimToken: manageToken },
                    })
                      .then((profile) => {
                        rememberProfile(profile);
                        patchListing(listing.id, { userId: profile.userId });
                        setClaimNote("This listing is now on your ShareHaat profile.");
                        setClaimMode("closed");
                        return refreshBoard();
                      })
                      .catch((err) => setClaimNote(explainFailure(err)));
                  }}
                >
                  <input className={fieldClass} value={claimName} onChange={(e) => setClaimName(e.target.value)} placeholder="Name" />
                  <input className={fieldClass} inputMode="tel" value={claimPhone} onChange={(e) => setClaimPhone(e.target.value)} placeholder="WhatsApp number" />
                  <button type="submit" className="h-11 w-full rounded-xl bg-forest text-sm font-bold text-on-forest">
                    Create ShareHaat Profile
                  </button>
                </form>
              ) : null}
              {claimNote ? <p className="text-xs font-semibold text-haat">{claimNote}</p> : null}
            </section>
          ) : null}
          {claimNote && listing.userId !== "guest" ? <p className="text-xs font-semibold text-haat">{claimNote}</p> : null}
          <section className="rounded-2xl border border-line bg-card p-3.5">
            <h2 className="text-sm font-bold">Origin & handover</h2>
            <dl className="mt-2 space-y-1.5 text-sm">
              <Row k="Place" v={placeOf(listing.originPlace, listing.district)} />
              <Row k="Handover" v={listing.handover} />
              <Row k="Landmark" v={listing.landmark || "—"} />
              <Row k="Seller" v={`${listing.sellerName} · ${listing.sellerType}`} />
            </dl>
            {listing.notes ? <p className="mt-3 text-sm leading-relaxed text-ink-soft">{listing.notes}</p> : null}
          </section>

          <section className="rounded-2xl border border-line bg-card p-3.5">
            <h2 className="text-sm font-bold">Ask the cooperative to move this lot</h2>
            <p className="mt-1 text-xs text-muted">Existing Sumo, NST or hired truck. Goods money stays with the seller.</p>
            <input className={`${fieldClass} mt-2`} value={buyerPlace} onChange={(e) => setBuyerPlace(e.target.value)} placeholder="Buyer place, town or station" />
            <input className={`${fieldClass} mt-2`} value={preference} onChange={(e) => setPreference(e.target.value)} placeholder="Sumo / NST / hired truck" />
            <button
              type="button"
              onClick={() => openWa(OPERATOR_WHATSAPP, consignmentMessage(listing, buyerPlace || "to confirm", preference))}
              className="mt-2 h-11 w-full rounded-xl bg-ochre text-sm font-bold text-forest"
            >
              Message helpdesk
            </button>
          </section>

          <section>
            <h2 className="text-sm font-bold">Seller word {rated.count ? `· ${rated.avg.toFixed(1)} from ${rated.count}` : ""}</h2>
            <div className="mt-2 space-y-2">
              {rated.items.map((r) => (
                <blockquote key={r.id} className="rounded-xl bg-card px-3 py-2 text-sm">
                  <p className="font-semibold text-star">{"★".repeat(r.rating)}</p>
                  <p className="text-ink-soft">{r.comment}</p>
                  <p className="mt-1 text-xs text-muted">{r.reviewerName}</p>
                </blockquote>
              ))}
            </div>
            <form
              className="mt-3 space-y-2"
              onSubmit={(e) => {
                e.preventDefault();
                if (!profile.name || comment.trim().length < 4) {
                  setSent("Add your name in Seller Profile, and a short note.");
                  return;
                }
                if (samePhone(profile.phone, listing.sellerPhone)) {
                  setSent("Sellers don’t review their own lot.");
                  return;
                }
                void createReview({
                  data: {
                    targetId: listing.sellerPhone,
                    targetType: "seller",
                    targetName: listing.sellerName,
                    reviewerName: profile.name,
                    reviewerPhone: profile.phone,
                    rating: stars,
                    comment: comment.trim(),
                  },
                })
                  .then((review) => {
                    addReview(review);
                    setComment("");
                    setSent("Saved on the community board.");
                    return refreshBoard();
                  })
                  .catch((err) => setSent(explainFailure(err)));
              }}
            >
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setStars(n)}
                    className={`size-9 rounded-lg text-sm font-bold ${n <= stars ? "bg-sand text-star" : "bg-canvas text-muted"}`}
                  >
                    {n}
                  </button>
                ))}
              </div>
              <textarea className={`${fieldClass} h-20 py-2`} value={comment} onChange={(e) => setComment(e.target.value)} placeholder="How was the lot, weight and handover?" />
              <button type="submit" className="h-11 w-full rounded-xl border border-forest text-sm font-bold text-forest">
                Leave a note
              </button>
              {sent ? <p className="text-xs font-semibold text-haat">{sent}</p> : null}
            </form>
          </section>
        </div>
      </div>
    </HaatShell>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-muted">{k}</dt>
      <dd className="text-right font-medium">{v}</dd>
    </div>
  );
}

export function MyHaatScreen() {
  const ready = useHydrated();
  const listings = useHaat((s) => s.listings);
  const patchListing = useHaat((s) => s.patchListing);
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [statusError, setStatusError] = useState("");
  const localProfile = readProfile();
  const guestIds = new Set(claimedListingIds());
  const mine = listings.filter((l) => {
    if (l.status === "deleted") return false;
    if (user && l.userId === user.id) return true;
    if (localProfile && l.userId === localProfile.userId) return true;
    return guestIds.has(l.id);
  });

  async function setStatus(id: string, status: Listing["status"]) {
    const lot = listings.find((item) => item.id === id);
    patchListing(id, { status });
    try {
      if (user && lot?.userId === user.id) await patchMyListing({ data: { id, status } });
      else {
        await patchGuestListing({
          data: { id, status, claimToken: claimTokenFor(id), profileKey: localProfile?.key },
        });
      }
      await refreshBoard();
      setStatusError("");
    } catch (err) {
      setStatusError(explainFailure(err));
    }
  }

  return (
    <HaatShell title="My Haat" subtitle="Your storefront, visible to everyone" back>
      <div className="space-y-3 px-4 pt-4">
        <p className="rounded-2xl bg-mint px-3 py-3 text-xs leading-relaxed text-forest">
          Lots you publish sit on the community board. Any ShareHaat visitor can open the photo, the rate, and your WhatsApp.
        </p>
        {isPending || !ready ? <p className="text-sm text-muted">Opening your storefront…</p> : null}
        {!isPending && ready && mine.length === 0 ? (
          <EmptyNote>Nothing listed yet. You can publish on Community Haat without an account.</EmptyNote>
        ) : null}
        {!isPending && !user && !localProfile ? (
          <div className="space-y-3">
            <p className="text-sm text-muted">Already published without an account? Open the listing link you saved, then choose Claim this listing.</p>
            <HaatSignIn callback="/my-haat" />
          </div>
        ) : null}
        {statusError ? <p className="text-sm font-semibold text-deal">{statusError}</p> : null}
        {mine.map((l) => (
          <article key={l.id} className="flex gap-3 rounded-2xl border border-line bg-card p-3">
            <button type="button" className="shrink-0" onClick={() => void navigate({ to: "/listing/$listingId", params: { listingId: l.id } })}>
              <HaatPhoto src={l.photoUrl} alt="" className="h-16 w-16 rounded-xl" />
            </button>
            <div className="min-w-0 flex-1">
              <button type="button" className="text-left" onClick={() => void navigate({ to: "/listing/$listingId", params: { listingId: l.id } })}>
                <p className="truncate text-sm font-bold">{l.title}</p>
                <p className="text-xs text-muted">
                  {l.productCode} · {l.status} · {rateLabel(l.priceInr, l.priceUnit)}
                </p>
              </button>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  className="h-10 rounded-lg bg-mint text-xs font-bold text-forest"
                  onClick={() => void setStatus(l.id, l.status === "sold" ? "active" : "sold")}
                >
                  {l.status === "sold" ? "Mark active" : "Mark sold"}
                </button>
                <button type="button" className="h-10 rounded-lg border border-line text-xs font-bold text-deal" onClick={() => void setStatus(l.id, "deleted")}>
                  Take down
                </button>
              </div>
            </div>
          </article>
        ))}
        <button type="button" onClick={() => void navigate({ to: "/sell" })} className="h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest">
          Post another lot
        </button>
      </div>
    </HaatShell>
  );
}
