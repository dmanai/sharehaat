const CLAIMS = "sharehaat.claims";
const PROFILE = "sharehaat.profile";
const DRAFT = "sharehaat.publishDraft";
const PENDING = "sharehaat.pendingClaim";

export type LocalProfile = { key: string; userId: string; name: string; phone: string };

function readJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

export function rememberClaim(listingId: string, token: string) {
  if (!listingId || !token) return;
  const all = readJson<Record<string, string>>(CLAIMS, {});
  all[listingId] = token;
  writeJson(CLAIMS, all);
}

export function claimTokenFor(listingId: string) {
  return readJson<Record<string, string>>(CLAIMS, {})[listingId] ?? "";
}

export function claimedListingIds() {
  return Object.keys(readJson<Record<string, string>>(CLAIMS, {}));
}

export function rememberProfile(profile: LocalProfile) {
  writeJson(PROFILE, profile);
}

export function readProfile(): LocalProfile | null {
  const profile = readJson<LocalProfile | null>(PROFILE, null);
  if (!profile?.key || !profile.userId) return null;
  return profile;
}

export function savePublishDraft(draft: unknown) {
  if (typeof window === "undefined") return;
  window.sessionStorage.setItem(DRAFT, JSON.stringify(draft));
}

export function takePublishDraft<T>() {
  if (typeof window === "undefined") return null;
  const raw = window.sessionStorage.getItem(DRAFT);
  if (!raw) return null;
  window.sessionStorage.removeItem(DRAFT);
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function savePendingClaim(listingId: string, token: string) {
  if (typeof window === "undefined") return;
  window.sessionStorage.setItem(PENDING, JSON.stringify({ listingId, token }));
}

export function takePendingClaim() {
  if (typeof window === "undefined") return null;
  const raw = window.sessionStorage.getItem(PENDING);
  if (!raw) return null;
  window.sessionStorage.removeItem(PENDING);
  try {
    const parsed = JSON.parse(raw) as { listingId?: string; token?: string };
    if (!parsed.listingId || !parsed.token) return null;
    return { listingId: parsed.listingId, token: parsed.token };
  } catch {
    return null;
  }
}

export function manageLink(listingId: string, token: string) {
  const origin = typeof window === "undefined" ? "" : window.location.origin;
  return `${origin}/listing/${listingId}#manage=${encodeURIComponent(token)}`;
}

export function tokenFromLocation(listingId: string) {
  if (typeof window === "undefined") return claimTokenFor(listingId);
  const hash = window.location.hash.replace(/^#/, "");
  if (hash.startsWith("manage=")) {
    const token = decodeURIComponent(hash.slice("manage=".length));
    if (token) rememberClaim(listingId, token);
    return token;
  }
  return claimTokenFor(listingId);
}
