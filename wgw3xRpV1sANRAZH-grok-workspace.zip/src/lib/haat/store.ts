import { useEffect, useState } from "react";
import { create } from "zustand";
import { buildSeed, emptyProfile, type Listing, type Need, type Profile, type Provider, type Review } from "./data";

const seed = buildSeed();

type HaatState = {
  listings: Listing[];
  needs: Need[];
  providers: Provider[];
  reviews: Review[];
  profile: Profile;
  profileReady: boolean;
  addListing: (listing: Listing) => void;
  patchListing: (id: string, patch: Partial<Listing>) => void;
  addNeed: (need: Need) => void;
  addProvider: (provider: Provider) => void;
  addReview: (review: Review) => void;
  saveProfile: (profile: Profile) => void;
  setProfileReady: (ready: boolean) => void;
  setBoard: (board: { listings: Listing[]; needs: Need[]; providers: Provider[]; reviews: Review[] }) => void;
};

export const useHaat = create<HaatState>()((set) => ({
  listings: seed.listings,
  needs: seed.needs,
  providers: seed.providers,
  reviews: seed.reviews,
  profile: emptyProfile,
  profileReady: false,
  addListing: (listing) => set((s) => ({ listings: [listing, ...s.listings.filter((item) => item.id !== listing.id)] })),
  patchListing: (id, patch) =>
    set((s) => ({
      listings: s.listings.map((item) => (item.id === id ? { ...item, ...patch } : item)),
    })),
  addNeed: (need) => set((s) => ({ needs: [need, ...s.needs.filter((item) => item.id !== need.id)] })),
  addProvider: (provider) => set((s) => ({ providers: [provider, ...s.providers.filter((item) => item.id !== provider.id)] })),
  addReview: (review) => set((s) => ({ reviews: [review, ...s.reviews] })),
  saveProfile: (profile) => set({ profile }),
  setProfileReady: (profileReady) => set({ profileReady }),
  setBoard: (board) => set(board),
}));

export function useHydrated() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  return ready;
}
