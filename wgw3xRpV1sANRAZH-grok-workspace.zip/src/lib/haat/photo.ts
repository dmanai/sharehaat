/** WhatsApp skips storefront photos above this size. Keep the JPEG under it. */
export const PHOTO_BYTE_LIMIT = 300 * 1024;

export function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    if (/^https?:/i.test(src)) img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not read that photo."));
    img.src = src;
  });
}

export function dataUrlBytes(dataUrl: string) {
  const comma = dataUrl.indexOf(",");
  if (comma < 0) return dataUrl.length;
  const b64 = dataUrl.slice(comma + 1).replace(/\s/g, "");
  const pad = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
  return Math.max(0, Math.floor((b64.length * 3) / 4) - pad);
}

export function jpegKilobytes(dataUrl: string) {
  return Math.max(1, Math.round(dataUrlBytes(dataUrl) / 1024));
}

function blobToDataUrl(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read that photo."));
    reader.readAsDataURL(blob);
  });
}

function toJpeg(canvas: HTMLCanvasElement, quality: number) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("Could not read that photo."))), "image/jpeg", quality);
  });
}

function drawFit(img: HTMLImageElement, edge: number) {
  const scale = Math.min(1, edge / Math.max(img.width, img.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(img.width * scale));
  canvas.height = Math.max(1, Math.round(img.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not read that photo.");
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas;
}

/** Scale the photo down and encode JPEG until the file is under 300 KB. */
export async function fitPhotoUnder300kb(src: string) {
  const img = await loadImage(src);
  let edge = Math.min(1200, Math.max(img.width, img.height, 1));
  let quality = 0.8;
  let last: Blob | null = null;
  for (let attempt = 0; attempt < 14; attempt += 1) {
    const blob = await toJpeg(drawFit(img, edge), quality);
    last = blob;
    if (blob.size <= PHOTO_BYTE_LIMIT) {
      return { dataUrl: await blobToDataUrl(blob), blob, bytes: blob.size };
    }
    if (quality > 0.46) quality = Math.round((quality - 0.12) * 100) / 100;
    else {
      edge = Math.round(edge * 0.78);
      quality = 0.7;
      if (edge < 320) break;
    }
  }
  if (!last) throw new Error("Could not read that photo.");
  return { dataUrl: await blobToDataUrl(last), blob: last, bytes: last.size };
}
