import { readFileSync } from "node:fs";
import { join } from "node:path";
import { PHOTO_BYTE_LIMIT } from "@/lib/haat/photo";

export type StoredPhoto = {
  imageUrl: string;
  imagePath: string;
};

const UPLOAD_FAILED = "Photo upload failed — Please try again.";

function blobToken() {
  const fromEnv = process.env.BLOB_READ_WRITE_TOKEN?.trim();
  if (fromEnv) return fromEnv;
  try {
    const text = readFileSync(join(process.cwd(), ".env.local"), "utf8");
    for (const line of text.split("\n")) {
      if (!line.startsWith("BLOB_READ_WRITE_TOKEN=")) continue;
      return line.slice("BLOB_READ_WRITE_TOKEN=".length).trim().replace(/^"|"$/g, "");
    }
  } catch {
    /* no local secret file */
  }
  return "";
}

export function jpegBytesFromDataUrl(dataUrl: string) {
  const comma = dataUrl.indexOf(",");
  if (comma < 0 || !dataUrl.slice(0, comma).toLowerCase().includes("image/")) {
    throw new Error("Use a photo from the camera or your gallery.");
  }
  const bytes = Buffer.from(dataUrl.slice(comma + 1).replace(/\s/g, ""), "base64");
  if (bytes.byteLength > PHOTO_BYTE_LIMIT) throw new Error("Photo is larger than 300 KB");
  if (bytes.byteLength < 32) throw new Error(UPLOAD_FAILED);
  return bytes;
}

/** Upload one already-compressed JPEG. Callers must not replace the crop step. */
export async function uploadShareHaatPhoto(jpeg: Uint8Array, listingId: string): Promise<StoredPhoto> {
  if (jpeg.byteLength > PHOTO_BYTE_LIMIT) throw new Error("Photo is larger than 300 KB");
  const token = blobToken();
  if (!token) throw new Error(UPLOAD_FAILED);
  const safe = listingId.replace(/[^A-Za-z0-9-]/g, "") || "lot";
  const imagePath = `sharehaat/listings/${safe}.jpg`;
  const { put } = await import("@vercel/blob");
  const result = await put(imagePath, Buffer.from(jpeg), {
    access: "public",
    token,
    contentType: "image/jpeg",
    addRandomSuffix: false,
    allowOverwrite: true,
  });
  if (!result?.url?.startsWith("https://")) throw new Error(UPLOAD_FAILED);
  return { imageUrl: result.url, imagePath: result.pathname || imagePath };
}

export async function promoteDataPhoto(dataUrl: string, listingId: string) {
  return uploadShareHaatPhoto(jpegBytesFromDataUrl(dataUrl), listingId);
}
