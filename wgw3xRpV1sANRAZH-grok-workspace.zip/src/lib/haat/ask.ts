import { createServerFn } from "@tanstack/react-start";

type AskInput = {
  role: "market" | "fast" | "deep";
  message: string;
  board: string;
};

const PROMPTS: Record<AskInput["role"], string> = {
  market: `You are the ShareHaat market advisor for Nagaland, with Tribal Harvest Marketing Cooperative Society Ltd.
Help growers, SHGs and buyers with fair chat-starting rates, packaging, NST and Sumo pickup, and local trades.
Use ONLY the live board below for prices that are actually listed. If a crop is not on the board, say so and give practical seasonal guidance without inventing a seller.
ShareHaat never takes payment. WhatsApp is the chat. Keep answers short, respectful, and concrete.`,
  fast: `You are ShareHaat Fast Helper. Ultra-short answers a farmer can paste into WhatsApp.
Convert units when asked (1 maund ≈ 37 kg in local trade talk — say it is approximate).
Use listed board prices when present. No preamble.`,
  deep: `You are ShareHaat's harvest strategist for Nagaland.
Give a practical plan: lot size, handover point, who to message, and which government scheme might fit.
Do not invent listed prices. Schemes are applied on official portals, not inside ShareHaat.
ShareHaat does not escrow money and does not guarantee perishables in transit.`,
};

export const askHaat = createServerFn({ method: "POST" })
  .validator((input: AskInput) => {
    const message = String(input?.message ?? "").trim().slice(0, 800);
    if (message.length < 2) throw new Error("Ask a fuller question.");
    const role = input?.role === "fast" || input?.role === "deep" ? input.role : "market";
    const board = String(input?.board ?? "").slice(0, 2400);
    return { role, message, board };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "offline" };

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 420,
        temperature: data.role === "fast" ? 0.2 : 0.5,
        messages: [
          {
            role: "system",
            content: `${PROMPTS[data.role === "fast" || data.role === "deep" ? data.role : "market"]}\n\nLIVE BOARD:\n${data.board || "(empty)"}`,
          },
          { role: "user", content: data.message },
        ],
      }),
    });

    if (!res.ok) return { ok: false as const, error: "offline" };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false as const, error: "offline" };
    return { ok: true as const, text };
  });
