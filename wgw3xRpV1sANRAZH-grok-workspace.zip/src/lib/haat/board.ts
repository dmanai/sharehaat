import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  buildSeed,
  digits,
  durableImageUrl,
  emptyProfile,
  nextCode,
  type Listing,
  type ListingKind,
  type ListingStatus,
  type Need,
  type NeedKind,
  type Profile,
  type Provider,
  type Review,
} from "@/lib/haat/data";

const HOURS = new Set([24, 36, 72, 168, 288, 360]);

export type ListingDraft = {
  title: string;
  category: string;
  priceInr: number;
  priceUnit: string;
  qty: number;
  qtyUnit: string;
  sellerName: string;
  sellerPhone: string;
  sellerType: string;
  district: string;
  originPlace: string;
  handover: string;
  landmark: string;
  notes: string;
  photoUrl: string;
  hours: number;
};

export type NeedDraft = {
  kind: "looking" | "donate" | "services";
  item: string;
  qty: number;
  qtyUnit: string;
  district: string;
  placeName: string;
  neededBy: string;
  budgetInr: number;
  buyerType: string;
  buyerName: string;
  buyerPhone: string;
  notes: string;
  trade: string;
  areaType: string;
};

export type ProviderDraft = {
  providerName: string;
  phone: string;
  serviceCategory: string;
  areaType: string;
  district: string;
  townOrVillage: string;
  experienceYears: number;
  description: string;
};

export type ReviewDraft = {
  targetId: string;
  targetType: "seller" | "service_provider";
  targetName: string;
  reviewerName: string;
  reviewerPhone: string;
  rating: number;
  comment: string;
};

export type Board = {
  listings: Listing[];
  needs: Need[];
  providers: Provider[];
  reviews: Review[];
};

function num(value: unknown) {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

function text(value: unknown, max: number) {
  return String(value ?? "").trim().slice(0, max);
}

function phone10(value: unknown) {
  return digits(String(value ?? "")).slice(-10);
}

function validateListing(input: ListingDraft): ListingDraft {
  const hours = num(input?.hours);
  if (!HOURS.has(hours)) throw new Error("Choose 24 hrs, 36 hours, 72 hours, or a longer lot.");
  const title = text(input?.title, 120);
  if (title.length < 3) throw new Error("Name the item.");
  const priceInr = Math.round(num(input?.priceInr));
  if (priceInr <= 0) throw new Error("Enter a price in rupees.");
  const qty = num(input?.qty);
  if (qty <= 0) throw new Error("Enter the quantity available.");
  const sellerName = text(input?.sellerName, 80);
  if (sellerName.length < 2) throw new Error("Enter the seller name.");
  const sellerPhone = phone10(input?.sellerPhone);
  if (sellerPhone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
  const originPlace = text(input?.originPlace, 80);
  if (originPlace.length < 2) throw new Error("Enter the village, khel, ward or town.");
  const photoUrl = photo(input?.photoUrl);
  if (!photoUrl) throw new Error("Add a photo from the camera or your gallery.");
  return {
    title,
    category: text(input?.category, 40) || "vegetables",
    priceInr,
    priceUnit: text(input?.priceUnit, 20) || "kg",
    qty,
    qtyUnit: text(input?.qtyUnit, 20) || text(input?.priceUnit, 20) || "kg",
    sellerName,
    sellerPhone,
    sellerType: text(input?.sellerType, 40) || "Farmer",
    district: text(input?.district, 40) || "Dimapur",
    originPlace,
    handover: text(input?.handover, 40) || "Station pickup",
    landmark: text(input?.landmark, 120),
    notes: text(input?.notes, 500),
    photoUrl,
    hours,
  };
}

function photo(value: unknown) {
  const raw = String(value ?? "").trim();
  if (!raw) return "";
  if (raw.startsWith("blob:") || raw.startsWith("data:application/")) {
    throw new Error("Photo upload failed — Please try again.");
  }
  if (/^https?:\/\//i.test(raw)) {
    if (!durableImageUrl(raw)) throw new Error("Photo upload failed — Please try again.");
    return raw;
  }
  if (!raw.startsWith("data:image/")) throw new Error("Use a photo from the camera or your gallery.");
  const comma = raw.indexOf(",");
  const b64 = raw.slice(comma + 1).replace(/\s/g, "");
  const pad = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
  const bytes = Math.max(0, Math.floor((b64.length * 3) / 4) - pad);
  if (bytes > 300 * 1024) throw new Error("Photo is larger than 300 KB");
  return raw;
}

type ListingRow = {
  id: string;
  user_id: string;
  product_code: string;
  category: string;
  listing_kind: string;
  status: string;
  title: string;
  photo_url: string;
  district: string;
  origin_place: string;
  seller_name: string;
  seller_phone: string;
  seller_type: string;
  price_inr: number | string;
  price_unit: string;
  qty: number | string;
  qty_unit: string;
  handover: string;
  landmark: string;
  notes: string;
  created_at: number | string;
  expires_at: number | string;
  featured: boolean;
};

function mapListing(row: ListingRow): Listing {
  const kind: ListingKind = row.listing_kind === "todays_deal" ? "todays_deal" : "shop_item";
  const status: ListingStatus =
    row.status === "sold" || row.status === "deleted" ? row.status : "active";
  return {
    id: row.id,
    productCode: row.product_code,
    userId: row.user_id,
    category: row.category,
    listingKind: kind,
    status,
    title: row.title,
    photoUrl: row.photo_url,
    district: row.district,
    originPlace: row.origin_place,
    sellerName: row.seller_name,
    sellerPhone: row.seller_phone,
    sellerType: row.seller_type,
    priceInr: num(row.price_inr),
    priceUnit: row.price_unit,
    qty: num(row.qty),
    qtyUnit: row.qty_unit,
    handover: row.handover,
    landmark: row.landmark,
    notes: row.notes,
    createdAt: num(row.created_at),
    expiresAt: num(row.expires_at),
    featured: Boolean(row.featured),
  };
}

type NeedRow = {
  id: string;
  user_id: string;
  need_code: string;
  kind: string;
  item: string;
  qty: number | string;
  qty_unit: string;
  district: string;
  place_name: string;
  needed_by: string;
  budget_inr: number | string;
  buyer_type: string;
  buyer_name: string;
  buyer_phone: string;
  notes: string;
  status: string;
  created_at: number | string;
  photo_url: string;
  need_category_type: string;
  service_category: string;
  area_type: string;
};

function mapNeed(row: NeedRow): Need {
  const kind: NeedKind = row.kind === "donate" ? "donate" : "looking";
  return {
    id: row.id,
    userId: row.user_id,
    needCode: row.need_code,
    kind,
    item: row.item,
    qty: num(row.qty),
    qtyUnit: row.qty_unit,
    district: row.district,
    placeName: row.place_name,
    neededBy: row.needed_by,
    budgetInr: num(row.budget_inr),
    buyerType: row.buyer_type,
    buyerName: row.buyer_name,
    buyerPhone: row.buyer_phone,
    notes: row.notes,
    status: row.status === "filled" || row.status === "taken_down" ? row.status : "open",
    createdAt: num(row.created_at),
    photoUrl: row.photo_url,
    needCategoryType: row.need_category_type === "services" ? "services" : "goods",
    serviceCategory: row.service_category,
    areaType: row.area_type,
  };
}

type ProviderRow = {
  id: string;
  user_id: string;
  provider_name: string;
  phone: string;
  service_category: string;
  area_type: string;
  district: string;
  town_or_village: string;
  experience_years: number | string;
  description: string;
  is_verified: boolean;
  registered_at: number | string;
};

function mapProvider(row: ProviderRow): Provider {
  return {
    id: row.id,
    userId: row.user_id,
    providerName: row.provider_name,
    phone: row.phone,
    serviceCategory: row.service_category,
    areaType: row.area_type,
    district: row.district,
    townOrVillage: row.town_or_village,
    experienceYears: num(row.experience_years),
    description: row.description,
    isVerified: Boolean(row.is_verified),
    registeredAt: num(row.registered_at),
  };
}

type ReviewRow = {
  id: string;
  user_id: string;
  target_id: string;
  target_type: string;
  target_name: string;
  reviewer_name: string;
  reviewer_phone: string;
  rating: number | string;
  comment: string;
  created_at: number | string;
};

function mapReview(row: ReviewRow): Review {
  return {
    id: row.id,
    userId: row.user_id,
    targetId: row.target_id,
    targetType: row.target_type === "service_provider" ? "service_provider" : "seller",
    targetName: row.target_name,
    reviewerName: row.reviewer_name,
    reviewerPhone: row.reviewer_phone,
    rating: Math.min(5, Math.max(1, num(row.rating))),
    comment: row.comment,
    createdAt: num(row.created_at),
  };
}

type ProfileRow = {
  name: string;
  phone: string;
  seller_type: string;
  district: string;
  place: string;
  is_service_provider: boolean;
  service_category: string;
};

function mapProfile(row: ProfileRow): Profile {
  return {
    name: row.name,
    phone: row.phone,
    sellerType: row.seller_type || "Farmer",
    district: row.district || "Dimapur",
    place: row.place,
    isServiceProvider: Boolean(row.is_service_provider),
    serviceCategory: row.service_category,
  };
}

async function sqlClient() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

async function ensureSeed() {
  const sql = await sqlClient();
  const counted = await sql<{ n: number }>`select count(*)::int as n from haat_listings`;
  if (num(counted[0]?.n) > 0) return;
  const seed = buildSeed();
  for (const l of seed.listings) {
    await sql`
      insert into haat_listings (
        id, user_id, product_code, category, listing_kind, status, title, photo_url,
        district, origin_place, seller_name, seller_phone, seller_type, price_inr, price_unit,
        qty, qty_unit, handover, landmark, notes, created_at, expires_at, featured
      ) values (
        ${l.id}, ${"seed"}, ${l.productCode}, ${l.category}, ${l.listingKind}, ${l.status}, ${l.title}, ${l.photoUrl},
        ${l.district}, ${l.originPlace}, ${l.sellerName}, ${l.sellerPhone}, ${l.sellerType}, ${l.priceInr}, ${l.priceUnit},
        ${l.qty}, ${l.qtyUnit}, ${l.handover}, ${l.landmark}, ${l.notes}, ${l.createdAt}, ${l.expiresAt}, ${l.featured}
      )
      on conflict (id) do nothing
    `;
  }
  for (const n of seed.needs) {
    await sql`
      insert into haat_needs (
        id, user_id, need_code, kind, item, qty, qty_unit, district, place_name, needed_by,
        budget_inr, buyer_type, buyer_name, buyer_phone, notes, status, created_at, photo_url,
        need_category_type, service_category, area_type
      ) values (
        ${n.id}, ${"seed"}, ${n.needCode}, ${n.kind}, ${n.item}, ${n.qty}, ${n.qtyUnit}, ${n.district}, ${n.placeName}, ${n.neededBy},
        ${n.budgetInr}, ${n.buyerType}, ${n.buyerName}, ${n.buyerPhone}, ${n.notes}, ${n.status}, ${n.createdAt}, ${n.photoUrl},
        ${n.needCategoryType}, ${n.serviceCategory}, ${n.areaType}
      )
      on conflict (id) do nothing
    `;
  }
  for (const p of seed.providers) {
    await sql`
      insert into haat_providers (
        id, user_id, provider_name, phone, service_category, area_type, district, town_or_village,
        experience_years, description, is_verified, registered_at
      ) values (
        ${p.id}, ${"seed"}, ${p.providerName}, ${p.phone}, ${p.serviceCategory}, ${p.areaType}, ${p.district}, ${p.townOrVillage},
        ${p.experienceYears}, ${p.description}, ${p.isVerified}, ${p.registeredAt}
      )
      on conflict (id) do nothing
    `;
  }
  for (const r of seed.reviews) {
    await sql`
      insert into haat_reviews (
        id, user_id, target_id, target_type, target_name, reviewer_name, reviewer_phone, rating, comment, created_at
      ) values (
        ${r.id}, ${"seed"}, ${r.targetId}, ${r.targetType}, ${r.targetName}, ${r.reviewerName}, ${r.reviewerPhone}, ${r.rating}, ${r.comment}, ${r.createdAt}
      )
      on conflict (id) do nothing
    `;
  }
}

async function storedPhotoUrl(photoUrl: string, listingId: string) {
  const kept = durableImageUrl(photoUrl);
  if (kept) return kept;
  if (!photoUrl.startsWith("data:image/")) throw new Error("Photo upload failed — Please try again.");
  const { promoteDataPhoto } = await import("@/lib/haat/storage.server");
  const saved = await promoteDataPhoto(photoUrl, listingId);
  return saved.imageUrl;
}

async function promoteLegacyPhotos(sql: Awaited<ReturnType<typeof sqlClient>>, rows: ListingRow[]) {
  const pending = rows.filter((row) => row.photo_url.startsWith("data:image/"));
  if (!pending.length) return;
  const { promoteDataPhoto } = await import("@/lib/haat/storage.server");
  for (const row of pending) {
    try {
      const saved = await promoteDataPhoto(row.photo_url, row.product_code || row.id);
      await sql`update haat_listings set photo_url = ${saved.imageUrl} where id = ${row.id}`;
      row.photo_url = saved.imageUrl;
    } catch {
      /* keep the compressed photo visible until the next successful upload */
    }
  }
}

export const getBoard = createServerFn({ method: "GET" }).handler(async (): Promise<Board> => {
  await ensureSeed();
  const sql = await sqlClient();
  const listings = await sql<ListingRow>`select * from haat_listings where status <> 'deleted' order by created_at desc`;
  await promoteLegacyPhotos(sql, listings);
  const needs = await sql<NeedRow>`select * from haat_needs where status <> 'taken_down' order by created_at desc`;
  const providers = await sql<ProviderRow>`select * from haat_providers order by registered_at desc`;
  const reviews = await sql<ReviewRow>`select * from haat_reviews order by created_at desc`;
  return {
    listings: listings.map(mapListing),
    needs: needs.map(mapNeed),
    providers: providers.map(mapProvider),
    reviews: reviews.map(mapReview),
  };
});

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Profile> => {
    const sql = await sqlClient();
    const rows = await sql<ProfileRow>`
      select name, phone, seller_type, district, place, is_service_provider, service_category
      from haat_profiles where user_id = ${context.userId}
    `;
    return rows[0] ? mapProfile(rows[0]) : emptyProfile;
  });

export const saveMyProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: Profile): Profile => ({
    name: text(input?.name, 80),
    phone: phone10(input?.phone),
    sellerType: text(input?.sellerType, 40) || "Farmer",
    district: text(input?.district, 40) || "Dimapur",
    place: text(input?.place, 80),
    isServiceProvider: Boolean(input?.isServiceProvider),
    serviceCategory: text(input?.serviceCategory, 40),
  }))
  .handler(async ({ context, data }) => {
    const sql = await sqlClient();
    await sql`
      insert into haat_profiles (
        user_id, name, phone, seller_type, district, place, is_service_provider, service_category, updated_at
      ) values (
        ${context.userId}, ${data.name}, ${data.phone}, ${data.sellerType}, ${data.district}, ${data.place},
        ${data.isServiceProvider}, ${data.serviceCategory}, now()
      )
      on conflict (user_id) do update set
        name = excluded.name,
        phone = excluded.phone,
        seller_type = excluded.seller_type,
        district = excluded.district,
        place = excluded.place,
        is_service_provider = excluded.is_service_provider,
        service_category = excluded.service_category,
        updated_at = now()
    `;
    return data;
  });

export const deleteMyData = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await sqlClient();
    const id = context.userId;
    await sql`delete from haat_listings where user_id = ${id}`;
    await sql`delete from haat_needs where user_id = ${id}`;
    await sql`delete from haat_providers where user_id = ${id}`;
    await sql`delete from haat_reviews where user_id = ${id}`;
    await sql`delete from haat_profiles where user_id = ${id}`;
    return { ok: true as const };
  });

export const createListing = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: ListingDraft): ListingDraft => validateListing(input))
  .handler(async ({ context, data }): Promise<Listing> => {
    const sql = await sqlClient();
    const now = Date.now();
    const kind: ListingKind = data.hours <= 72 ? "todays_deal" : "shop_item";
    const listing: Listing = {
      id: `list-${now}-${Math.floor(Math.random() * 1000)}`,
      productCode: nextCode(kind === "todays_deal" ? "SH-DEAL" : "SH-LOT"),
      userId: context.userId,
      category: data.category,
      listingKind: kind,
      status: "active",
      title: data.title,
      photoUrl: "",
      district: data.district,
      originPlace: data.originPlace,
      sellerName: data.sellerName,
      sellerPhone: data.sellerPhone,
      sellerType: data.sellerType,
      priceInr: data.priceInr,
      priceUnit: data.priceUnit,
      qty: data.qty,
      qtyUnit: data.qtyUnit,
      handover: data.handover,
      landmark: data.landmark,
      notes: data.notes,
      createdAt: now,
      expiresAt: now + data.hours * 3600 * 1000,
      featured: kind === "todays_deal",
    };
    listing.photoUrl = await storedPhotoUrl(data.photoUrl, listing.productCode);
    await sql`
      insert into haat_listings (
        id, user_id, product_code, category, listing_kind, status, title, photo_url,
        district, origin_place, seller_name, seller_phone, seller_type, price_inr, price_unit,
        qty, qty_unit, handover, landmark, notes, created_at, expires_at, featured
      ) values (
        ${listing.id}, ${listing.userId}, ${listing.productCode}, ${listing.category}, ${listing.listingKind}, ${listing.status},
        ${listing.title}, ${listing.photoUrl}, ${listing.district}, ${listing.originPlace}, ${listing.sellerName}, ${listing.sellerPhone},
        ${listing.sellerType}, ${listing.priceInr}, ${listing.priceUnit}, ${listing.qty}, ${listing.qtyUnit}, ${listing.handover},
        ${listing.landmark}, ${listing.notes}, ${listing.createdAt}, ${listing.expiresAt}, ${listing.featured}
      )
    `;
    return listing;
  });

export const publishGuestListing = createServerFn({ method: "POST" })
  .validator((input: ListingDraft & { profileKey?: string }) => {
    const draft = validateListing(input);
    const profileKey = text(input?.profileKey, 80);
    return profileKey ? { ...draft, profileKey } : draft;
  })
  .handler(async ({ data }) => {
    const { assertSameSiteRequest } = await import("@/lib/auth/isolation.server");
    assertSameSiteRequest();
    const { publishAsGuest } = await import("@/lib/haat/guest.server");
    return publishAsGuest(data);
  });

export const registerWhatsApp = createServerFn({ method: "POST" })
  .validator((input: { name?: string; phone?: string; listingId?: string; claimToken?: string }) => {
    const name = text(input?.name, 80);
    if (name.length < 2) throw new Error("Enter your name.");
    const phone = phone10(input?.phone);
    if (phone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
    return {
      name,
      phone,
      listingId: text(input?.listingId, 80),
      claimToken: text(input?.claimToken, 80),
    };
  })
  .handler(async ({ data }) => {
    const { assertSameSiteRequest } = await import("@/lib/auth/isolation.server");
    assertSameSiteRequest();
    const { registerWhatsAppProfile } = await import("@/lib/haat/guest.server");
    return registerWhatsAppProfile(data);
  });

export const claimMyListing = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { listingId?: string; claimToken?: string }) => {
    const listingId = text(input?.listingId, 80);
    const claimToken = text(input?.claimToken, 80);
    if (!listingId || !claimToken) throw new Error("This listing could not be claimed. Use the link you saved.");
    return { listingId, claimToken };
  })
  .handler(async ({ context, data }) => {
    const { claimListingForUser } = await import("@/lib/haat/guest.server");
    return claimListingForUser(data.listingId, data.claimToken, context.userId);
  });

export const patchGuestListing = createServerFn({ method: "POST" })
  .validator((input: { id?: string; status?: ListingStatus; claimToken?: string; profileKey?: string }) => {
    const id = text(input?.id, 80);
    const status = input?.status;
    if (!id || (status !== "active" && status !== "sold" && status !== "deleted")) {
      throw new Error("Could not update that lot.");
    }
    return {
      id,
      status,
      claimToken: text(input?.claimToken, 80),
      profileKey: text(input?.profileKey, 80),
    };
  })
  .handler(async ({ data }) => {
    const { assertSameSiteRequest } = await import("@/lib/auth/isolation.server");
    assertSameSiteRequest();
    const { patchGuestLot } = await import("@/lib/haat/guest.server");
    return patchGuestLot(data.id, data.status, { claimToken: data.claimToken, profileKey: data.profileKey });
  });

export const patchMyListing = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; status: ListingStatus }) => {
    const id = text(input?.id, 80);
    const status = input?.status;
    if (!id || (status !== "active" && status !== "sold" && status !== "deleted")) {
      throw new Error("Could not update that lot.");
    }
    return { id, status };
  })
  .handler(async ({ context, data }) => {
    const sql = await sqlClient();
    await sql`update haat_listings set status = ${data.status} where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const createNeed = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: NeedDraft): NeedDraft => {
    const kind = input?.kind === "donate" || input?.kind === "services" ? input.kind : "looking";
    const item = text(input?.item, 140);
    if (item.length < 3) throw new Error("Say what you need or are giving.");
    const buyerName = text(input?.buyerName, 80);
    if (buyerName.length < 2) throw new Error("Enter your name.");
    const buyerPhone = phone10(input?.buyerPhone);
    if (buyerPhone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
    const placeName = text(input?.placeName, 80);
    if (placeName.length < 2) throw new Error("Enter the place.");
    return {
      kind,
      item,
      qty: num(input?.qty) || 1,
      qtyUnit: text(input?.qtyUnit, 20) || "kg",
      district: text(input?.district, 40) || "Dimapur",
      placeName,
      neededBy: text(input?.neededBy, 80) || "Within this week",
      budgetInr: kind === "donate" ? 0 : Math.max(0, Math.round(num(input?.budgetInr))),
      buyerType: text(input?.buyerType, 40) || "Household",
      buyerName,
      buyerPhone,
      notes: text(input?.notes, 500),
      trade: text(input?.trade, 40),
      areaType: text(input?.areaType, 20) || "village",
    };
  })
  .handler(async ({ context, data }): Promise<Need> => {
    const sql = await sqlClient();
    const now = Date.now();
    const need: Need = {
      id: `need-${now}`,
      userId: context.userId,
      needCode: nextCode(data.kind === "donate" ? "DN" : data.kind === "services" ? "SR" : "ND"),
      kind: data.kind === "donate" ? "donate" : "looking",
      item: data.item,
      qty: data.qty,
      qtyUnit: data.qtyUnit,
      district: data.district,
      placeName: data.placeName,
      neededBy: data.neededBy,
      budgetInr: data.budgetInr,
      buyerType: data.buyerType,
      buyerName: data.buyerName,
      buyerPhone: data.buyerPhone,
      notes: data.notes,
      status: "open",
      createdAt: now,
      photoUrl: "",
      needCategoryType: data.kind === "services" ? "services" : "goods",
      serviceCategory: data.kind === "services" ? data.trade : "",
      areaType: data.areaType,
    };
    await sql`
      insert into haat_needs (
        id, user_id, need_code, kind, item, qty, qty_unit, district, place_name, needed_by,
        budget_inr, buyer_type, buyer_name, buyer_phone, notes, status, created_at, photo_url,
        need_category_type, service_category, area_type
      ) values (
        ${need.id}, ${need.userId}, ${need.needCode}, ${need.kind}, ${need.item}, ${need.qty}, ${need.qtyUnit},
        ${need.district}, ${need.placeName}, ${need.neededBy}, ${need.budgetInr}, ${need.buyerType}, ${need.buyerName},
        ${need.buyerPhone}, ${need.notes}, ${need.status}, ${need.createdAt}, ${need.photoUrl}, ${need.needCategoryType},
        ${need.serviceCategory}, ${need.areaType}
      )
    `;
    return need;
  });

export const createProvider = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: ProviderDraft): ProviderDraft => {
    const providerName = text(input?.providerName, 80);
    if (providerName.length < 2) throw new Error("Enter the workshop or your name.");
    const phone = phone10(input?.phone);
    if (phone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
    const townOrVillage = text(input?.townOrVillage, 80);
    if (townOrVillage.length < 2) throw new Error("Enter town or village.");
    return {
      providerName,
      phone,
      serviceCategory: text(input?.serviceCategory, 40) || "Electrician",
      areaType: text(input?.areaType, 20) || "village",
      district: text(input?.district, 40) || "Dimapur",
      townOrVillage,
      experienceYears: Math.max(1, Math.round(num(input?.experienceYears) || 1)),
      description: text(input?.description, 500),
    };
  })
  .handler(async ({ context, data }): Promise<Provider> => {
    const sql = await sqlClient();
    const provider: Provider = {
      id: `prov-${Date.now()}`,
      userId: context.userId,
      providerName: data.providerName,
      phone: data.phone,
      serviceCategory: data.serviceCategory,
      areaType: data.areaType,
      district: data.district,
      townOrVillage: data.townOrVillage,
      experienceYears: data.experienceYears,
      description: data.description || `${data.serviceCategory} available around ${data.townOrVillage}.`,
      isVerified: false,
      registeredAt: Date.now(),
    };
    await sql`
      insert into haat_providers (
        id, user_id, provider_name, phone, service_category, area_type, district, town_or_village,
        experience_years, description, is_verified, registered_at
      ) values (
        ${provider.id}, ${provider.userId}, ${provider.providerName}, ${provider.phone}, ${provider.serviceCategory},
        ${provider.areaType}, ${provider.district}, ${provider.townOrVillage}, ${provider.experienceYears},
        ${provider.description}, ${provider.isVerified}, ${provider.registeredAt}
      )
    `;
    return provider;
  });

export const createReview = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: ReviewDraft): ReviewDraft => {
    const comment = text(input?.comment, 400);
    if (comment.length < 4) throw new Error("Add a short note.");
    const reviewerName = text(input?.reviewerName, 80);
    if (reviewerName.length < 2) throw new Error("Add your name in Seller Profile.");
    return {
      targetId: text(input?.targetId, 40),
      targetType: input?.targetType === "service_provider" ? "service_provider" : "seller",
      targetName: text(input?.targetName, 80),
      reviewerName,
      reviewerPhone: phone10(input?.reviewerPhone),
      rating: Math.min(5, Math.max(1, Math.round(num(input?.rating) || 5))),
      comment,
    };
  })
  .handler(async ({ context, data }): Promise<Review> => {
    const sql = await sqlClient();
    const review: Review = {
      id: `rev-${Date.now()}`,
      userId: context.userId,
      targetId: data.targetId,
      targetType: data.targetType,
      targetName: data.targetName,
      reviewerName: data.reviewerName,
      reviewerPhone: data.reviewerPhone,
      rating: data.rating,
      comment: data.comment,
      createdAt: Date.now(),
    };
    await sql`
      insert into haat_reviews (
        id, user_id, target_id, target_type, target_name, reviewer_name, reviewer_phone, rating, comment, created_at
      ) values (
        ${review.id}, ${review.userId}, ${review.targetId}, ${review.targetType}, ${review.targetName},
        ${review.reviewerName}, ${review.reviewerPhone}, ${review.rating}, ${review.comment}, ${review.createdAt}
      )
    `;
    return review;
  });
