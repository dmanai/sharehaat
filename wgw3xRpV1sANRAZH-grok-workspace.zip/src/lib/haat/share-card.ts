import { placeOf, rateLabel, shareText, type Listing } from "@/lib/haat/data";
import { PHOTO_BYTE_LIMIT, loadImage } from "@/lib/haat/photo";

export type ShareResult = "shared" | "copied" | "downloaded" | "whatsapp" | "cancelled";

export function shareResultNote(result: ShareResult) {
  if (result === "copied") return "WhatsApp is open. Paste the photo into that chat — it is copied and under 300 KB.";
  if (result === "downloaded") return "WhatsApp is open. Attach the photo that was just saved so the picture shows.";
  if (result === "whatsapp") return "WhatsApp is open.";
  if (result === "shared") return "WhatsApp is open with your storefront photo.";
  return "";
}

function cover(ctx: CanvasRenderingContext2D, img: HTMLImageElement, x: number, y: number, w: number, h: number) {
  const scale = Math.max(w / img.width, h / img.height);
  const dw = img.width * scale;
  const dh = img.height * scale;
  ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}

function wrap(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, max: number, line: number, lines: number) {
  const words = text.split(" ");
  let row = "";
  let used = 0;
  for (const word of words) {
    const next = row ? `${row} ${word}` : word;
    if (ctx.measureText(next).width > max && row) {
      ctx.fillText(row, x, y + used * line);
      used += 1;
      row = word;
      if (used >= lines) return;
    } else {
      row = next;
    }
  }
  if (row && used < lines) ctx.fillText(row, x, y + used * line);
}

function toJpeg(canvas: HTMLCanvasElement, quality: number) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("photo"))), "image/jpeg", quality);
  });
}

async function jpegUnder(source: HTMLCanvasElement, limit: number) {
  let canvas = source;
  let last = await toJpeg(canvas, 0.72);
  for (let pass = 0; pass < 5; pass += 1) {
    for (const quality of [0.82, 0.7, 0.58, 0.46, 0.34]) {
      last = await toJpeg(canvas, quality);
      if (last.size <= limit) return last;
    }
    const next = document.createElement("canvas");
    next.width = Math.max(420, Math.round(canvas.width * 0.78));
    next.height = Math.max(420, Math.round(canvas.height * 0.78));
    const ctx = next.getContext("2d");
    if (!ctx) break;
    ctx.drawImage(canvas, 0, 0, next.width, next.height);
    canvas = next;
  }
  return last;
}

/** Storefront card: the member's photo on top, lot details under it, file under 300 KB. */
export async function buildStorefrontBlob(listing: Listing) {
  const img = listing.photoUrl ? await loadImage(listing.photoUrl).catch(() => null) : null;
  const width = 840;
  const photoH = img ? 840 : 0;
  const foot = 280;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = photoH + foot;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not prepare the photo.");
  if (typeof document !== "undefined" && document.fonts?.load) {
    await document.fonts.load("800 42px Outfit").catch(() => undefined);
  }
  ctx.fillStyle = "#1b4332";
  ctx.fillRect(0, 0, width, canvas.height);
  if (img) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, width, photoH);
    ctx.clip();
    cover(ctx, img, 0, 0, width, photoH);
    ctx.restore();
  }
  const y0 = photoH;
  ctx.fillStyle = "#1b4332";
  ctx.fillRect(0, y0, width, foot);
  ctx.fillStyle = "#faedcd";
  ctx.font = "700 22px Outfit, sans-serif";
  ctx.fillText("SHAREHAAT STOREFRONT", 36, y0 + 46);
  ctx.fillStyle = "#ffffff";
  ctx.font = "800 40px Outfit, sans-serif";
  wrap(ctx, listing.title, 36, y0 + 98, width - 72, 46, 2);
  ctx.fillStyle = "#d8f3dc";
  ctx.font = "700 30px Outfit, sans-serif";
  ctx.fillText(rateLabel(listing.priceInr, listing.priceUnit), 36, y0 + 204);
  ctx.fillStyle = "#ccd5ae";
  ctx.font = "600 22px Outfit, sans-serif";
  const place = placeOf(listing.originPlace, listing.district);
  if (place) ctx.fillText(place.slice(0, 42), 36, y0 + 240);
  ctx.fillStyle = "#faedcd";
  ctx.font = "600 20px Outfit, sans-serif";
  ctx.fillText(listing.productCode, 36, y0 + 268);
  return jpegUnder(canvas, PHOTO_BYTE_LIMIT);
}

function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

async function copyImage(blob: Blob) {
  if (!navigator.clipboard?.write) return false;
  const url = URL.createObjectURL(blob);
  try {
    const img = await loadImage(url);
    const canvas = document.createElement("canvas");
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return false;
    ctx.drawImage(img, 0, 0);
    const png = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((file) => (file ? resolve(file) : reject(new Error("png"))), "image/png");
    });
    await navigator.clipboard.write([new ClipboardItem({ "image/png": png })]);
    return true;
  } catch {
    try {
      await navigator.clipboard.write([new ClipboardItem({ "image/jpeg": blob })]);
      return true;
    } catch {
      return false;
    }
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function shareWithFriends(listing: Listing, door?: Window | null): Promise<ShareResult> {
  const text = shareText(listing);
  let blob: Blob | null = null;
  try {
    blob = await buildStorefrontBlob(listing);
  } catch {
    blob = null;
  }
  const copied = blob ? await copyImage(blob) : false;
  if (!copied && blob) downloadBlob(blob, `${listing.productCode}-sharehaat.jpg`);
  const href = `https://wa.me/?text=${encodeURIComponent(text)}`;
  if (door && !door.closed) door.location.href = href;
  else window.open(href, "_blank", "noopener,noreferrer");
  if (copied) return "copied";
  if (blob) return "downloaded";
  return "whatsapp";
}
