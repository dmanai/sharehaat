import { useEffect } from "react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getBoard, getMyProfile } from "@/lib/haat/board";
import { emptyProfile } from "@/lib/haat/data";
import { useHaat } from "@/lib/haat/store";

let ticket = 0;
let loadedUser: string | null = null;

export async function refreshBoard() {
  const mine = ++ticket;
  try {
    const board = await getBoard();
    if (mine !== ticket) return false;
    useHaat.getState().setBoard(board);
    return true;
  } catch {
    return false;
  }
}

export function useBoardSync() {
  const { user, isPending } = useCurrentUserState();

  useEffect(() => {
    void refreshBoard();
  }, []);

  useEffect(() => {
    if (isPending) return;
    const id = user?.id ?? "";
    if (loadedUser === id) {
      useHaat.getState().setProfileReady(true);
      return;
    }
    loadedUser = id;
    if (!id) {
      useHaat.getState().saveProfile(emptyProfile);
      useHaat.getState().setProfileReady(true);
      return;
    }
    let live = true;
    getMyProfile()
      .then((profile) => {
        if (!live || loadedUser !== id) return;
        useHaat.getState().saveProfile(profile);
        useHaat.getState().setProfileReady(true);
      })
      .catch(() => {
        if (live) useHaat.getState().setProfileReady(true);
      });
    return () => {
      live = false;
    };
  }, [user?.id, isPending]);
}

export function rememberProfile(profile: ReturnType<typeof useHaat.getState>["profile"]) {
  loadedUser = loadedUser ?? "";
  useHaat.getState().saveProfile(profile);
}

export function explainFailure(err: unknown) {
  const message = err instanceof Error ? err.message : "";
  if (/unauthorized/i.test(message)) return "Sign in to post on the community board.";
  return message || "Could not save that. Try again.";
}
