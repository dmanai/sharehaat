import { createHash, randomBytes } from "node:crypto";
import { nextCode, type Listing, type ListingKind } from "@/lib/haat/data";

type GuestDraft = {
  title: string;
  category: string;
  priceInr: number;
  priceUnit: string;
  qty: number;
  qtyUnit: string;
  sellerName: string;
  sellerPhone: string;
  sellerType: string;
  district: string;
  originPlace: string;
  handover: string;
  landmark: string;
  notes: string;
  photoUrl: string;
  hours: number;
  profileKey?: string;
};

const DAY = 24 * 60 * 60 * 1000;
const GUEST_USER = "guest";

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function newToken() {
  return randomBytes(24).toString("base64url");
}

async function sqlClient() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

async function assertRoom(phone: string) {
  const sql = await sqlClient();
  const since = Date.now() - DAY;
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from haat_listings
    where seller_phone = ${phone} and created_at > ${since} and status <> 'deleted'
  `;
  const n = Number(rows[0]?.n ?? 0);
  if (n >= 8) throw new Error("Too many listings from this number today. Try again tomorrow.");
}

async function storedPhoto(photoUrl: string, productCode: string) {
  const { durableImageUrl } = await import("@/lib/haat/data");
  const kept = durableImageUrl(photoUrl);
  if (kept) return kept;
  if (!photoUrl.startsWith("data:image/")) throw new Error("Photo upload failed — Please try again.");
  const { promoteDataPhoto } = await import("@/lib/haat/storage.server");
  const saved = await promoteDataPhoto(photoUrl, productCode);
  return saved.imageUrl;
}

function buildListing(data: GuestDraft, userId: string): Listing {
  const now = Date.now();
  const kind: ListingKind = data.hours <= 72 ? "todays_deal" : "shop_item";
  return {
    id: `list-${now}-${Math.floor(Math.random() * 1000)}`,
    productCode: nextCode(kind === "todays_deal" ? "SH-DEAL" : "SH-LOT"),
    userId,
    category: data.category,
    listingKind: kind,
    status: "active",
    title: data.title,
    photoUrl: "",
    district: data.district,
    originPlace: data.originPlace,
    sellerName: data.sellerName,
    sellerPhone: data.sellerPhone,
    sellerType: data.sellerType,
    priceInr: data.priceInr,
    priceUnit: data.priceUnit,
    qty: data.qty,
    qtyUnit: data.qtyUnit,
    handover: data.handover,
    landmark: data.landmark,
    notes: data.notes,
    createdAt: now,
    expiresAt: now + data.hours * 3600 * 1000,
    featured: kind === "todays_deal",
  };
}

async function insertListing(listing: Listing, claimStatus: "claimed" | "unclaimed", tokenHash: string) {
  const sql = await sqlClient();
  await sql`
    insert into haat_listings (
      id, user_id, product_code, category, listing_kind, status, title, photo_url,
      district, origin_place, seller_name, seller_phone, seller_type, price_inr, price_unit,
      qty, qty_unit, handover, landmark, notes, created_at, expires_at, featured,
      claim_status, claim_token_hash
    ) values (
      ${listing.id}, ${listing.userId}, ${listing.productCode}, ${listing.category}, ${listing.listingKind}, ${listing.status},
      ${listing.title}, ${listing.photoUrl}, ${listing.district}, ${listing.originPlace}, ${listing.sellerName}, ${listing.sellerPhone},
      ${listing.sellerType}, ${listing.priceInr}, ${listing.priceUnit}, ${listing.qty}, ${listing.qtyUnit}, ${listing.handover},
      ${listing.landmark}, ${listing.notes}, ${listing.createdAt}, ${listing.expiresAt}, ${listing.featured},
      ${claimStatus}, ${tokenHash}
    )
  `;
}

export async function publishAsGuest(data: GuestDraft) {
  await assertRoom(data.sellerPhone);
  let userId = GUEST_USER;
  let claimStatus: "claimed" | "unclaimed" = "unclaimed";
  let claimToken = "";
  let tokenHash = "";
  if (data.profileKey) {
    userId = `wa:${hashToken(data.profileKey).slice(0, 32)}`;
    const sql = await sqlClient();
    const rows = await sql<{ user_id: string }>`select user_id from haat_profiles where user_id = ${userId} limit 1`;
    if (!rows[0]) throw new Error("Create your ShareHaat profile again.");
    claimStatus = "claimed";
  } else {
    claimToken = newToken();
    tokenHash = hashToken(claimToken);
  }
  const listing = buildListing(data, userId);
  listing.photoUrl = await storedPhoto(data.photoUrl, listing.productCode);
  await insertListing(listing, claimStatus, tokenHash);
  return { listing, claimToken };
}

export async function registerWhatsAppProfile(input: {
  name: string;
  phone: string;
  listingId?: string;
  claimToken?: string;
}) {
  const sql = await sqlClient();
  const key = newToken();
  const userId = `wa:${hashToken(key).slice(0, 32)}`;
  await sql`
    insert into haat_profiles (
      user_id, name, phone, seller_type, district, place, is_service_provider, service_category, updated_at
    ) values (
      ${userId}, ${input.name}, ${input.phone}, ${"Farmer"}, ${"Dimapur"}, ${""}, ${false}, ${""}, now()
    )
    on conflict (user_id) do update set name = excluded.name, phone = excluded.phone, updated_at = now()
  `;
  if (input.listingId && input.claimToken) {
    await claimListingForUser(input.listingId, input.claimToken, userId);
  }
  return { key, userId, name: input.name, phone: input.phone };
}

export async function claimListingForUser(listingId: string, claimToken: string, userId: string) {
  const sql = await sqlClient();
  const tokenHash = hashToken(claimToken);
  const rows = await sql<{ id: string; product_code: string }>`
    update haat_listings
    set user_id = ${userId}, claim_status = 'claimed', claim_token_hash = ''
    where id = ${listingId} and claim_status = 'unclaimed' and claim_token_hash = ${tokenHash}
    returning id, product_code
  `;
  if (!rows[0]) throw new Error("This listing could not be claimed. Use the link you saved.");
  return { id: rows[0].id, productCode: rows[0].product_code };
}

export async function patchGuestLot(id: string, status: "active" | "sold" | "deleted", secret: { claimToken?: string; profileKey?: string }) {
  const sql = await sqlClient();
  if (secret.profileKey) {
    const userId = `wa:${hashToken(secret.profileKey).slice(0, 32)}`;
    const rows = await sql<{ id: string }>`
      update haat_listings set status = ${status} where id = ${id} and user_id = ${userId} returning id
    `;
    if (!rows[0]) throw new Error("Could not update that lot.");
    return { ok: true as const };
  }
  const tokenHash = hashToken(secret.claimToken ?? "");
  const rows = await sql<{ id: string }>`
    update haat_listings set status = ${status}
    where id = ${id} and claim_token_hash = ${tokenHash} and claim_token_hash <> ''
    returning id
  `;
  if (!rows[0]) throw new Error("Could not update that lot.");
  return { ok: true as const };
}
