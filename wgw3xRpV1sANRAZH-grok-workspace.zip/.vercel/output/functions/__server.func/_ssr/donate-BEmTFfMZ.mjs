import { t as DonateScreen } from "./community-DKChWjsZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donate-BEmTFfMZ.js
var SplitComponent = DonateScreen;
//#endregion
export { SplitComponent as component };
