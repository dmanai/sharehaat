import { i as SchemesScreen } from "./info-kxYs0b-S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schemes-BItOjECq.js
var SplitComponent = SchemesScreen;
//#endregion
export { SplitComponent as component };
