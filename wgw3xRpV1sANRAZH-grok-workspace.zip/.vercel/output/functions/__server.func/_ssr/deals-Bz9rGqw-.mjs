import { t as DealsScreen } from "./market-BzzKcPZQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/deals-Bz9rGqw-.js
var SplitComponent = DealsScreen;
//#endregion
export { SplitComponent as component };
