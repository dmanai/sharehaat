import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn } from "./client-IWHfIGH2.mjs";
import { t as GROK_PROVIDERS } from "./server-TFxhS46V.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/signin-HxNuRtCI.js
var import_jsx_runtime = require_jsx_runtime();
function HaatSignIn({ callback = "/" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2",
		children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => signIn(provider.providerId, { callbackURL: callback }),
			className: "h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest",
			children: ["Continue with ", provider.label]
		}, provider.providerId))
	});
}
//#endregion
export { HaatSignIn as t };
