import { n as HomeScreen } from "./market-BzzKcPZQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D3jwR824.js
var SplitComponent = HomeScreen;
//#endregion
export { SplitComponent as component };
