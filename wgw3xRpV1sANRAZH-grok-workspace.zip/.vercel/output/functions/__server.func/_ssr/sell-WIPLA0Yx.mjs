import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SellScreen } from "./market-BzzKcPZQ.mjs";
import { r as Route$5 } from "./router-DuSlLXm9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sell-WIPLA0Yx.js
var import_jsx_runtime = require_jsx_runtime();
function SellRoute() {
	const { kind } = Route$5.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SellScreen, { initialKind: kind === "deal" ? "todays_deal" : "shop_item" });
}
//#endregion
export { SellRoute as component };
