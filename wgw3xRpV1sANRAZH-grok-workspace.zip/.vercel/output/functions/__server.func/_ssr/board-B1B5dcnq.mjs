import { r as createServerFn } from "./ssr.mjs";
import { A as nextCode, D as emptyProfile, T as digits, x as buildSeed, y as authMiddleware } from "./data-D2z7szSz.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/board-B1B5dcnq.js
var HOURS = /* @__PURE__ */ new Set([
	24,
	36,
	72,
	168,
	288,
	360
]);
function num(value) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : 0;
}
function text(value, max) {
	return String(value ?? "").trim().slice(0, max);
}
function phone10(value) {
	return digits(String(value ?? "")).slice(-10);
}
function photo(value) {
	const raw = String(value ?? "");
	if (!raw) return "";
	if (raw.startsWith("https://")) return raw;
	if (!raw.startsWith("data:image/")) throw new Error("Use a photo from the camera or your gallery.");
	const comma = raw.indexOf(",");
	const b64 = raw.slice(comma + 1).replace(/\s/g, "");
	const pad = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
	if (Math.max(0, Math.floor(b64.length * 3 / 4) - pad) > 307200) throw new Error("That photo is over 300 KB. Take it again so WhatsApp can show it.");
	return raw;
}
function mapListing(row) {
	const kind = row.listing_kind === "todays_deal" ? "todays_deal" : "shop_item";
	const status = row.status === "sold" || row.status === "deleted" ? row.status : "active";
	return {
		id: row.id,
		productCode: row.product_code,
		userId: row.user_id,
		category: row.category,
		listingKind: kind,
		status,
		title: row.title,
		photoUrl: row.photo_url,
		district: row.district,
		originPlace: row.origin_place,
		sellerName: row.seller_name,
		sellerPhone: row.seller_phone,
		sellerType: row.seller_type,
		priceInr: num(row.price_inr),
		priceUnit: row.price_unit,
		qty: num(row.qty),
		qtyUnit: row.qty_unit,
		handover: row.handover,
		landmark: row.landmark,
		notes: row.notes,
		createdAt: num(row.created_at),
		expiresAt: num(row.expires_at),
		featured: Boolean(row.featured)
	};
}
function mapNeed(row) {
	const kind = row.kind === "donate" ? "donate" : "looking";
	return {
		id: row.id,
		userId: row.user_id,
		needCode: row.need_code,
		kind,
		item: row.item,
		qty: num(row.qty),
		qtyUnit: row.qty_unit,
		district: row.district,
		placeName: row.place_name,
		neededBy: row.needed_by,
		budgetInr: num(row.budget_inr),
		buyerType: row.buyer_type,
		buyerName: row.buyer_name,
		buyerPhone: row.buyer_phone,
		notes: row.notes,
		status: row.status === "filled" || row.status === "taken_down" ? row.status : "open",
		createdAt: num(row.created_at),
		photoUrl: row.photo_url,
		needCategoryType: row.need_category_type === "services" ? "services" : "goods",
		serviceCategory: row.service_category,
		areaType: row.area_type
	};
}
function mapProvider(row) {
	return {
		id: row.id,
		userId: row.user_id,
		providerName: row.provider_name,
		phone: row.phone,
		serviceCategory: row.service_category,
		areaType: row.area_type,
		district: row.district,
		townOrVillage: row.town_or_village,
		experienceYears: num(row.experience_years),
		description: row.description,
		isVerified: Boolean(row.is_verified),
		registeredAt: num(row.registered_at)
	};
}
function mapReview(row) {
	return {
		id: row.id,
		userId: row.user_id,
		targetId: row.target_id,
		targetType: row.target_type === "service_provider" ? "service_provider" : "seller",
		targetName: row.target_name,
		reviewerName: row.reviewer_name,
		reviewerPhone: row.reviewer_phone,
		rating: Math.min(5, Math.max(1, num(row.rating))),
		comment: row.comment,
		createdAt: num(row.created_at)
	};
}
function mapProfile(row) {
	return {
		name: row.name,
		phone: row.phone,
		sellerType: row.seller_type || "Farmer",
		district: row.district || "Dimapur",
		place: row.place,
		isServiceProvider: Boolean(row.is_service_provider),
		serviceCategory: row.service_category
	};
}
async function sqlClient() {
	const { getSql } = await import("./db-GfcRq5Rp.mjs").then((n) => n.t).then((n) => n.t);
	return getSql();
}
async function ensureSeed() {
	const sql = await sqlClient();
	if (num((await sql`select count(*)::int as n from haat_listings`)[0]?.n) > 0) return;
	const seed = buildSeed();
	for (const l of seed.listings) await sql`
      insert into haat_listings (
        id, user_id, product_code, category, listing_kind, status, title, photo_url,
        district, origin_place, seller_name, seller_phone, seller_type, price_inr, price_unit,
        qty, qty_unit, handover, landmark, notes, created_at, expires_at, featured
      ) values (
        ${l.id}, ${"seed"}, ${l.productCode}, ${l.category}, ${l.listingKind}, ${l.status}, ${l.title}, ${l.photoUrl},
        ${l.district}, ${l.originPlace}, ${l.sellerName}, ${l.sellerPhone}, ${l.sellerType}, ${l.priceInr}, ${l.priceUnit},
        ${l.qty}, ${l.qtyUnit}, ${l.handover}, ${l.landmark}, ${l.notes}, ${l.createdAt}, ${l.expiresAt}, ${l.featured}
      )
      on conflict (id) do nothing
    `;
	for (const n of seed.needs) await sql`
      insert into haat_needs (
        id, user_id, need_code, kind, item, qty, qty_unit, district, place_name, needed_by,
        budget_inr, buyer_type, buyer_name, buyer_phone, notes, status, created_at, photo_url,
        need_category_type, service_category, area_type
      ) values (
        ${n.id}, ${"seed"}, ${n.needCode}, ${n.kind}, ${n.item}, ${n.qty}, ${n.qtyUnit}, ${n.district}, ${n.placeName}, ${n.neededBy},
        ${n.budgetInr}, ${n.buyerType}, ${n.buyerName}, ${n.buyerPhone}, ${n.notes}, ${n.status}, ${n.createdAt}, ${n.photoUrl},
        ${n.needCategoryType}, ${n.serviceCategory}, ${n.areaType}
      )
      on conflict (id) do nothing
    `;
	for (const p of seed.providers) await sql`
      insert into haat_providers (
        id, user_id, provider_name, phone, service_category, area_type, district, town_or_village,
        experience_years, description, is_verified, registered_at
      ) values (
        ${p.id}, ${"seed"}, ${p.providerName}, ${p.phone}, ${p.serviceCategory}, ${p.areaType}, ${p.district}, ${p.townOrVillage},
        ${p.experienceYears}, ${p.description}, ${p.isVerified}, ${p.registeredAt}
      )
      on conflict (id) do nothing
    `;
	for (const r of seed.reviews) await sql`
      insert into haat_reviews (
        id, user_id, target_id, target_type, target_name, reviewer_name, reviewer_phone, rating, comment, created_at
      ) values (
        ${r.id}, ${"seed"}, ${r.targetId}, ${r.targetType}, ${r.targetName}, ${r.reviewerName}, ${r.reviewerPhone}, ${r.rating}, ${r.comment}, ${r.createdAt}
      )
      on conflict (id) do nothing
    `;
}
var getBoard_createServerFn_handler = createServerRpc({
	id: "7007c295317ed58f55701b73ac335bbaea2f129c4aa15808423edf8819c91054",
	name: "getBoard",
	filename: "src/lib/haat/board.ts"
}, (opts) => getBoard.__executeServer(opts));
var getBoard = createServerFn({ method: "GET" }).handler(getBoard_createServerFn_handler, async () => {
	await ensureSeed();
	const sql = await sqlClient();
	const listings = await sql`select * from haat_listings where status <> 'deleted' order by created_at desc`;
	const needs = await sql`select * from haat_needs where status <> 'taken_down' order by created_at desc`;
	const providers = await sql`select * from haat_providers order by registered_at desc`;
	const reviews = await sql`select * from haat_reviews order by created_at desc`;
	return {
		listings: listings.map(mapListing),
		needs: needs.map(mapNeed),
		providers: providers.map(mapProvider),
		reviews: reviews.map(mapReview)
	};
});
var getMyProfile_createServerFn_handler = createServerRpc({
	id: "292566192e717f756f668de6ee57264fb23e791492b13aa6d4a3ecad8cd3e994",
	name: "getMyProfile",
	filename: "src/lib/haat/board.ts"
}, (opts) => getMyProfile.__executeServer(opts));
var getMyProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMyProfile_createServerFn_handler, async ({ context }) => {
	const rows = await (await sqlClient())`
      select name, phone, seller_type, district, place, is_service_provider, service_category
      from haat_profiles where user_id = ${context.userId}
    `;
	return rows[0] ? mapProfile(rows[0]) : emptyProfile;
});
var saveMyProfile_createServerFn_handler = createServerRpc({
	id: "c98f80807cea06fcccb4c91dcb724f8e5bbd631f37c8ac8e61e3061b51d10258",
	name: "saveMyProfile",
	filename: "src/lib/haat/board.ts"
}, (opts) => saveMyProfile.__executeServer(opts));
var saveMyProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	name: text(input?.name, 80),
	phone: phone10(input?.phone),
	sellerType: text(input?.sellerType, 40) || "Farmer",
	district: text(input?.district, 40) || "Dimapur",
	place: text(input?.place, 80),
	isServiceProvider: Boolean(input?.isServiceProvider),
	serviceCategory: text(input?.serviceCategory, 40)
})).handler(saveMyProfile_createServerFn_handler, async ({ context, data }) => {
	await (await sqlClient())`
      insert into haat_profiles (
        user_id, name, phone, seller_type, district, place, is_service_provider, service_category, updated_at
      ) values (
        ${context.userId}, ${data.name}, ${data.phone}, ${data.sellerType}, ${data.district}, ${data.place},
        ${data.isServiceProvider}, ${data.serviceCategory}, now()
      )
      on conflict (user_id) do update set
        name = excluded.name,
        phone = excluded.phone,
        seller_type = excluded.seller_type,
        district = excluded.district,
        place = excluded.place,
        is_service_provider = excluded.is_service_provider,
        service_category = excluded.service_category,
        updated_at = now()
    `;
	return data;
});
var deleteMyData_createServerFn_handler = createServerRpc({
	id: "77c860c1f1b5bb999e5747b33771250f43acff334bfab3b25825d3e60ecc3fb2",
	name: "deleteMyData",
	filename: "src/lib/haat/board.ts"
}, (opts) => deleteMyData.__executeServer(opts));
var deleteMyData = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(deleteMyData_createServerFn_handler, async ({ context }) => {
	const sql = await sqlClient();
	const id = context.userId;
	await sql`delete from haat_listings where user_id = ${id}`;
	await sql`delete from haat_needs where user_id = ${id}`;
	await sql`delete from haat_providers where user_id = ${id}`;
	await sql`delete from haat_reviews where user_id = ${id}`;
	await sql`delete from haat_profiles where user_id = ${id}`;
	return { ok: true };
});
var createListing_createServerFn_handler = createServerRpc({
	id: "950992845bd780628a2dcf2ecb558c5eaba5c28fd70b0fb864b2b0b477c09851",
	name: "createListing",
	filename: "src/lib/haat/board.ts"
}, (opts) => createListing.__executeServer(opts));
var createListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const hours = num(input?.hours);
	if (!HOURS.has(hours)) throw new Error("Choose 24 hrs, 36 hours, 72 hours, or a longer lot.");
	const title = text(input?.title, 120);
	if (title.length < 3) throw new Error("Name the item.");
	const priceInr = Math.round(num(input?.priceInr));
	if (priceInr <= 0) throw new Error("Enter a price in rupees.");
	const qty = num(input?.qty);
	if (qty <= 0) throw new Error("Enter the quantity available.");
	const sellerName = text(input?.sellerName, 80);
	if (sellerName.length < 2) throw new Error("Enter the seller name.");
	const sellerPhone = phone10(input?.sellerPhone);
	if (sellerPhone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
	const originPlace = text(input?.originPlace, 80);
	if (originPlace.length < 2) throw new Error("Enter the village, khel, ward or town.");
	const photoUrl = photo(input?.photoUrl);
	if (!photoUrl) throw new Error("Add a photo from the camera or your gallery.");
	return {
		title,
		category: text(input?.category, 40) || "vegetables",
		priceInr,
		priceUnit: text(input?.priceUnit, 20) || "kg",
		qty,
		qtyUnit: text(input?.qtyUnit, 20) || text(input?.priceUnit, 20) || "kg",
		sellerName,
		sellerPhone,
		sellerType: text(input?.sellerType, 40) || "Farmer",
		district: text(input?.district, 40) || "Dimapur",
		originPlace,
		handover: text(input?.handover, 40) || "Station pickup",
		landmark: text(input?.landmark, 120),
		notes: text(input?.notes, 500),
		photoUrl,
		hours
	};
}).handler(createListing_createServerFn_handler, async ({ context, data }) => {
	const sql = await sqlClient();
	const now = Date.now();
	const kind = data.hours <= 72 ? "todays_deal" : "shop_item";
	const listing = {
		id: `list-${now}-${Math.floor(Math.random() * 1e3)}`,
		productCode: nextCode(kind === "todays_deal" ? "SH-DEAL" : "SH-LOT"),
		userId: context.userId,
		category: data.category,
		listingKind: kind,
		status: "active",
		title: data.title,
		photoUrl: data.photoUrl,
		district: data.district,
		originPlace: data.originPlace,
		sellerName: data.sellerName,
		sellerPhone: data.sellerPhone,
		sellerType: data.sellerType,
		priceInr: data.priceInr,
		priceUnit: data.priceUnit,
		qty: data.qty,
		qtyUnit: data.qtyUnit,
		handover: data.handover,
		landmark: data.landmark,
		notes: data.notes,
		createdAt: now,
		expiresAt: now + data.hours * 3600 * 1e3,
		featured: kind === "todays_deal"
	};
	await sql`
      insert into haat_listings (
        id, user_id, product_code, category, listing_kind, status, title, photo_url,
        district, origin_place, seller_name, seller_phone, seller_type, price_inr, price_unit,
        qty, qty_unit, handover, landmark, notes, created_at, expires_at, featured
      ) values (
        ${listing.id}, ${listing.userId}, ${listing.productCode}, ${listing.category}, ${listing.listingKind}, ${listing.status},
        ${listing.title}, ${listing.photoUrl}, ${listing.district}, ${listing.originPlace}, ${listing.sellerName}, ${listing.sellerPhone},
        ${listing.sellerType}, ${listing.priceInr}, ${listing.priceUnit}, ${listing.qty}, ${listing.qtyUnit}, ${listing.handover},
        ${listing.landmark}, ${listing.notes}, ${listing.createdAt}, ${listing.expiresAt}, ${listing.featured}
      )
    `;
	return listing;
});
var patchMyListing_createServerFn_handler = createServerRpc({
	id: "067c480040275ba895d670e67db2d2303cf97c446470a8bb1c7c008927e86c7c",
	name: "patchMyListing",
	filename: "src/lib/haat/board.ts"
}, (opts) => patchMyListing.__executeServer(opts));
var patchMyListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const id = text(input?.id, 80);
	const status = input?.status;
	if (!id || status !== "active" && status !== "sold" && status !== "deleted") throw new Error("Could not update that lot.");
	return {
		id,
		status
	};
}).handler(patchMyListing_createServerFn_handler, async ({ context, data }) => {
	await (await sqlClient())`update haat_listings set status = ${data.status} where id = ${data.id} and user_id = ${context.userId}`;
	return { ok: true };
});
var createNeed_createServerFn_handler = createServerRpc({
	id: "32f3a64082cbf53a1245d45f3ba9b535f8ca68faf21f24422074ace70d8eace5",
	name: "createNeed",
	filename: "src/lib/haat/board.ts"
}, (opts) => createNeed.__executeServer(opts));
var createNeed = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const kind = input?.kind === "donate" || input?.kind === "services" ? input.kind : "looking";
	const item = text(input?.item, 140);
	if (item.length < 3) throw new Error("Say what you need or are giving.");
	const buyerName = text(input?.buyerName, 80);
	if (buyerName.length < 2) throw new Error("Enter your name.");
	const buyerPhone = phone10(input?.buyerPhone);
	if (buyerPhone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
	const placeName = text(input?.placeName, 80);
	if (placeName.length < 2) throw new Error("Enter the place.");
	return {
		kind,
		item,
		qty: num(input?.qty) || 1,
		qtyUnit: text(input?.qtyUnit, 20) || "kg",
		district: text(input?.district, 40) || "Dimapur",
		placeName,
		neededBy: text(input?.neededBy, 80) || "Within this week",
		budgetInr: kind === "donate" ? 0 : Math.max(0, Math.round(num(input?.budgetInr))),
		buyerType: text(input?.buyerType, 40) || "Household",
		buyerName,
		buyerPhone,
		notes: text(input?.notes, 500),
		trade: text(input?.trade, 40),
		areaType: text(input?.areaType, 20) || "village"
	};
}).handler(createNeed_createServerFn_handler, async ({ context, data }) => {
	const sql = await sqlClient();
	const now = Date.now();
	const need = {
		id: `need-${now}`,
		userId: context.userId,
		needCode: nextCode(data.kind === "donate" ? "DN" : data.kind === "services" ? "SR" : "ND"),
		kind: data.kind === "donate" ? "donate" : "looking",
		item: data.item,
		qty: data.qty,
		qtyUnit: data.qtyUnit,
		district: data.district,
		placeName: data.placeName,
		neededBy: data.neededBy,
		budgetInr: data.budgetInr,
		buyerType: data.buyerType,
		buyerName: data.buyerName,
		buyerPhone: data.buyerPhone,
		notes: data.notes,
		status: "open",
		createdAt: now,
		photoUrl: "",
		needCategoryType: data.kind === "services" ? "services" : "goods",
		serviceCategory: data.kind === "services" ? data.trade : "",
		areaType: data.areaType
	};
	await sql`
      insert into haat_needs (
        id, user_id, need_code, kind, item, qty, qty_unit, district, place_name, needed_by,
        budget_inr, buyer_type, buyer_name, buyer_phone, notes, status, created_at, photo_url,
        need_category_type, service_category, area_type
      ) values (
        ${need.id}, ${need.userId}, ${need.needCode}, ${need.kind}, ${need.item}, ${need.qty}, ${need.qtyUnit},
        ${need.district}, ${need.placeName}, ${need.neededBy}, ${need.budgetInr}, ${need.buyerType}, ${need.buyerName},
        ${need.buyerPhone}, ${need.notes}, ${need.status}, ${need.createdAt}, ${need.photoUrl}, ${need.needCategoryType},
        ${need.serviceCategory}, ${need.areaType}
      )
    `;
	return need;
});
var createProvider_createServerFn_handler = createServerRpc({
	id: "dc6716c55f890c1f9033e6ef5d673903047b31a1344fc0a9d1c9429b5adfd0fc",
	name: "createProvider",
	filename: "src/lib/haat/board.ts"
}, (opts) => createProvider.__executeServer(opts));
var createProvider = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const providerName = text(input?.providerName, 80);
	if (providerName.length < 2) throw new Error("Enter the workshop or your name.");
	const phone = phone10(input?.phone);
	if (phone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
	const townOrVillage = text(input?.townOrVillage, 80);
	if (townOrVillage.length < 2) throw new Error("Enter town or village.");
	return {
		providerName,
		phone,
		serviceCategory: text(input?.serviceCategory, 40) || "Electrician",
		areaType: text(input?.areaType, 20) || "village",
		district: text(input?.district, 40) || "Dimapur",
		townOrVillage,
		experienceYears: Math.max(1, Math.round(num(input?.experienceYears) || 1)),
		description: text(input?.description, 500)
	};
}).handler(createProvider_createServerFn_handler, async ({ context, data }) => {
	const sql = await sqlClient();
	const provider = {
		id: `prov-${Date.now()}`,
		userId: context.userId,
		providerName: data.providerName,
		phone: data.phone,
		serviceCategory: data.serviceCategory,
		areaType: data.areaType,
		district: data.district,
		townOrVillage: data.townOrVillage,
		experienceYears: data.experienceYears,
		description: data.description || `${data.serviceCategory} available around ${data.townOrVillage}.`,
		isVerified: false,
		registeredAt: Date.now()
	};
	await sql`
      insert into haat_providers (
        id, user_id, provider_name, phone, service_category, area_type, district, town_or_village,
        experience_years, description, is_verified, registered_at
      ) values (
        ${provider.id}, ${provider.userId}, ${provider.providerName}, ${provider.phone}, ${provider.serviceCategory},
        ${provider.areaType}, ${provider.district}, ${provider.townOrVillage}, ${provider.experienceYears},
        ${provider.description}, ${provider.isVerified}, ${provider.registeredAt}
      )
    `;
	return provider;
});
var createReview_createServerFn_handler = createServerRpc({
	id: "91dfea01f026341e28f06b0bb5237cda642588e0bc13d5746efac5cf598bbd20",
	name: "createReview",
	filename: "src/lib/haat/board.ts"
}, (opts) => createReview.__executeServer(opts));
var createReview = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const comment = text(input?.comment, 400);
	if (comment.length < 4) throw new Error("Add a short note.");
	const reviewerName = text(input?.reviewerName, 80);
	if (reviewerName.length < 2) throw new Error("Add your name in Seller Profile.");
	return {
		targetId: text(input?.targetId, 40),
		targetType: input?.targetType === "service_provider" ? "service_provider" : "seller",
		targetName: text(input?.targetName, 80),
		reviewerName,
		reviewerPhone: phone10(input?.reviewerPhone),
		rating: Math.min(5, Math.max(1, Math.round(num(input?.rating) || 5))),
		comment
	};
}).handler(createReview_createServerFn_handler, async ({ context, data }) => {
	const sql = await sqlClient();
	const review = {
		id: `rev-${Date.now()}`,
		userId: context.userId,
		targetId: data.targetId,
		targetType: data.targetType,
		targetName: data.targetName,
		reviewerName: data.reviewerName,
		reviewerPhone: data.reviewerPhone,
		rating: data.rating,
		comment: data.comment,
		createdAt: Date.now()
	};
	await sql`
      insert into haat_reviews (
        id, user_id, target_id, target_type, target_name, reviewer_name, reviewer_phone, rating, comment, created_at
      ) values (
        ${review.id}, ${review.userId}, ${review.targetId}, ${review.targetType}, ${review.targetName},
        ${review.reviewerName}, ${review.reviewerPhone}, ${review.rating}, ${review.comment}, ${review.createdAt}
      )
    `;
	return review;
});
//#endregion
export { createListing_createServerFn_handler, createNeed_createServerFn_handler, createProvider_createServerFn_handler, createReview_createServerFn_handler, deleteMyData_createServerFn_handler, getBoard_createServerFn_handler, getMyProfile_createServerFn_handler, patchMyListing_createServerFn_handler, saveMyProfile_createServerFn_handler };
