import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as PostNeedScreen } from "./community-DKChWjsZ.mjs";
import { i as Route$7 } from "./router-DuSlLXm9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/post-need-ixZq40qL.js
var import_jsx_runtime = require_jsx_runtime();
function PostRoute() {
	const { kind } = Route$7.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostNeedScreen, { kind: kind ?? "looking" });
}
//#endregion
export { PostRoute as component };
