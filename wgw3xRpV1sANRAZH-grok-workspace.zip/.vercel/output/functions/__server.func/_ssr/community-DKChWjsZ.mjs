import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as donateMessage, M as prettyPhone, R as serviceReply, T as digits, _ as SERVICE_TRADES, a as DISTRICTS, f as PRICE_UNITS, k as needSupplyMessage, n as AREA_TYPES, r as BUYER_TYPES } from "./data-D2z7szSz.mjs";
import { a as createNeed, b as useHaat, d as fieldClass, f as openWa, g as saveMyProfile, h as refreshBoard, n as HaatShell, o as createProvider, r as MemberFillNote, t as Field, u as explainFailure, x as useHydrated, y as useCurrentUserState } from "./shell-CmuEccI4.mjs";
import { t as HaatSignIn } from "./signin-HxNuRtCI.mjs";
import { a as NeedCard, n as EmptyNote, o as ProviderCard } from "./cards-BJlnlTRd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/community-DKChWjsZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NeedsScreen({ tab }) {
	const ready = useHydrated();
	const needs = useHaat((s) => s.needs);
	const providers = useHaat((s) => s.providers);
	const reviews = useHaat((s) => s.reviews);
	const profile = useHaat((s) => s.profile);
	const navigate = useNavigate();
	const open = needs.filter((n) => n.status === "open");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Buyer’s Need",
		subtitle: "Produce, bulk lots and skilled trades",
		back: true,
		tab: "needs",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4",
					children: [
						{
							id: "goods",
							label: "Looking"
						},
						{
							id: "services",
							label: "Services"
						},
						{
							id: "providers",
							label: "Trades"
						}
					].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void navigate({
							to: "/needs",
							search: { tab: t.id }
						}),
						className: `h-9 shrink-0 rounded-full px-3 text-xs font-bold ${tab === t.id ? "bg-forest text-on-forest" : "bg-card text-ink-soft border border-line"}`,
						children: t.label
					}, t.id))
				}),
				!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Loading the board…"
				}) : null,
				tab === "providers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void navigate({ to: "/services" }),
					className: "h-11 w-full rounded-xl bg-mint text-sm font-bold text-forest",
					children: "Register your trade — free listing"
				}), providers.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProviderCard, {
					provider: p,
					reviews,
					onChat: () => openWa(p.phone, `Hello ${p.providerName}, I found you on ShareHaat. I need a ${p.serviceCategory.toLowerCase()} in ${p.district}.`)
				}, p.id))] }) : null,
				tab === "goods" ? open.filter((n) => n.kind !== "donate" && n.needCategoryType === "goods").map((need) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedCard, {
					need,
					action: "I can supply this",
					onAction: () => openWa(need.buyerPhone, needSupplyMessage(need))
				}, need.id)) : null,
				tab === "services" ? open.filter((n) => n.needCategoryType === "services").map((need) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedCard, {
					need,
					action: "I can do this job",
					onAction: () => openWa(need.buyerPhone, serviceReply(need, profile.name || "a ShareHaat provider", profile.serviceCategory || need.serviceCategory))
				}, need.id)) : null,
				tab !== "providers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void navigate({
						to: "/post-need",
						search: { kind: tab === "services" ? "services" : "looking" }
					}),
					className: "h-12 w-full rounded-xl bg-deal text-sm font-bold text-on-forest",
					children: tab === "services" ? "Post a service need" : "Post what you are looking for"
				}) : null
			]
		})
	});
}
function DonateScreen() {
	const ready = useHydrated();
	const needs = useHaat((s) => s.needs);
	const navigate = useNavigate();
	const gifts = needs.filter((n) => n.status === "open" && n.kind === "donate");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Donate",
		subtitle: "Giveaways, separate from buyer needs",
		tab: "donate",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-mint px-3 py-3 text-xs leading-relaxed text-forest",
					children: "Offer books, seeds, tools or a spare lot for free. Collectors chat you on WhatsApp. This is not a buyer need."
				}),
				!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Loading giveaways…"
				}) : null,
				ready && gifts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, { children: "No giveaways yet. Offer one for a school, church or household." }) : null,
				gifts.map((need) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedCard, {
					need,
					action: "I can collect",
					onAction: () => openWa(need.buyerPhone, donateMessage(need))
				}, need.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void navigate({
						to: "/post-need",
						search: { kind: "donate" }
					}),
					className: "h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest",
					children: "Offer a giveaway"
				})
			]
		})
	});
}
function PostNeedScreen({ kind }) {
	const profile = useHaat((s) => s.profile);
	const profileReady = useHaat((s) => s.profileReady);
	const saveProfile = useHaat((s) => s.saveProfile);
	const addNeed = useHaat((s) => s.addNeed);
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [item, setItem] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)("1");
	const [unit, setUnit] = (0, import_react.useState)(kind === "services" ? "job" : "kg");
	const [budget, setBudget] = (0, import_react.useState)(kind === "donate" ? "0" : "");
	const [neededBy, setNeededBy] = (0, import_react.useState)("Within this week");
	const [buyerType, setBuyerType] = (0, import_react.useState)("Household");
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [place, setPlace] = (0, import_react.useState)("");
	const [district, setDistrict] = (0, import_react.useState)("Dimapur");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [trade, setTrade] = (0, import_react.useState)("Electrician");
	const [area, setArea] = (0, import_react.useState)("village");
	const [error, setError] = (0, import_react.useState)("");
	const [needsAuth, setNeedsAuth] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [seeded, setSeeded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!profileReady || seeded || isPending) return;
		setName(profile.name || (user && !user.isDevFallback ? user.displayName || "" : ""));
		setPhone(profile.phone);
		setPlace(profile.place);
		if (profile.district) setDistrict(profile.district);
		if (profile.serviceCategory) setTrade(profile.serviceCategory);
		setSeeded(true);
	}, [
		profileReady,
		seeded,
		profile,
		user,
		isPending
	]);
	const title = kind === "donate" ? "Giveaway details" : kind === "services" ? "Need a trade" : "Need details";
	const memberFilled = Boolean(profile.name || profile.phone || profile.place || user && !user.isDevFallback && user.displayName);
	async function submit() {
		if (item.trim().length < 3) return setError("Say what you need or are giving.");
		if (name.trim().length < 2) return setError("Enter your name.");
		if (digits(phone).length < 10) return setError("Enter a 10-digit WhatsApp number.");
		if (place.trim().length < 2) return setError("Enter the place.");
		if (!isPending && !user) {
			setNeedsAuth(true);
			setError("Sign in so this post is on the community board.");
			return;
		}
		setBusy(true);
		const nextProfile = {
			...profile,
			name: name.trim(),
			phone: digits(phone).slice(-10),
			district,
			place: place.trim(),
			serviceCategory: kind === "services" ? trade : profile.serviceCategory
		};
		try {
			const need = await createNeed({ data: {
				kind,
				item: item.trim(),
				qty: Number(qty) || 1,
				qtyUnit: unit,
				district,
				placeName: place.trim(),
				neededBy,
				budgetInr: kind === "donate" ? 0 : Number(budget) || 0,
				buyerType,
				buyerName: nextProfile.name,
				buyerPhone: nextProfile.phone,
				notes: notes.trim(),
				trade,
				areaType: area
			} });
			addNeed(need);
			const saved = await saveMyProfile({ data: nextProfile });
			saveProfile(saved);
			await refreshBoard();
			if (kind === "donate") {
				navigate({ to: "/donate" });
				return;
			}
			navigate({
				to: "/needs",
				search: { tab: kind === "services" ? "services" : "goods" }
			});
		} catch (err) {
			const message = explainFailure(err);
			setError(message);
			setNeedsAuth(/sign in/i.test(message));
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title,
		subtitle: kind === "donate" ? "Giveaway form. Members are filled in." : "People reply on your WhatsApp",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3 px-4 pt-4",
			onSubmit: (e) => {
				e.preventDefault();
				submit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberFillNote, { filled: memberFilled }),
				kind === "services" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Trade",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: trade,
						onChange: (e) => setTrade(e.target.value),
						children: SERVICE_TRADES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: kind === "donate" ? "What you are giving" : kind === "services" ? "Job to be done" : "What you are looking for",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: item,
						onChange: (e) => setItem(e.target.value),
						placeholder: "Hill ginger, carved table, inverter repair..."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Quantity",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "decimal",
							value: qty,
							onChange: (e) => setQty(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Unit",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: unit,
							onChange: (e) => setUnit(e.target.value),
							children: (kind === "services" ? [
								"job",
								"machine",
								"installation",
								"day"
							] : PRICE_UNITS).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: u }, u))
						})
					})]
				}),
				kind !== "donate" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: kind === "services" ? "Budget in ₹" : "Budget per unit in ₹",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "decimal",
						value: budget,
						onChange: (e) => setBudget(e.target.value),
						placeholder: "Optional"
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Needed by",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: neededBy,
						onChange: (e) => setNeededBy(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "You are a",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: buyerType,
						onChange: (e) => setBuyerType(e.target.value),
						children: BUYER_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Area",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: area,
						onChange: (e) => setArea(e.target.value),
						children: AREA_TYPES.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a.key,
							children: a.label
						}, a.key))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Village / town / colony",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: place,
						onChange: (e) => setPlace(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "District",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: district,
						onChange: (e) => setDistrict(e.target.value),
						children: DISTRICTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Your name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: name,
						onChange: (e) => setName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "WhatsApp mobile",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "tel",
						value: phone,
						onChange: (e) => setPhone(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Details",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} h-24 py-3`,
						value: notes,
						onChange: (e) => setNotes(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-deal",
					children: error
				}) : null,
				needsAuth && !isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatSignIn, { callback: kind === "donate" ? "/donate" : "/needs" }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: busy,
					className: "h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60",
					children: busy ? "Posting…" : "Post on the board"
				})
			]
		})
	});
}
function ServicesScreen() {
	const profile = useHaat((s) => s.profile);
	const profileReady = useHaat((s) => s.profileReady);
	const addProvider = useHaat((s) => s.addProvider);
	const saveProfile = useHaat((s) => s.saveProfile);
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [trade, setTrade] = (0, import_react.useState)("Electrician");
	const [area, setArea] = (0, import_react.useState)("village");
	const [district, setDistrict] = (0, import_react.useState)("Dimapur");
	const [place, setPlace] = (0, import_react.useState)("");
	const [years, setYears] = (0, import_react.useState)("3");
	const [description, setDescription] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	const [needsAuth, setNeedsAuth] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [seeded, setSeeded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!profileReady || seeded) return;
		setName(profile.name);
		setPhone(profile.phone);
		setPlace(profile.place);
		if (profile.serviceCategory) setTrade(profile.serviceCategory);
		if (profile.district) setDistrict(profile.district);
		setSeeded(true);
	}, [
		profileReady,
		seeded,
		profile
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Service Provider",
		subtitle: "Free listing for rural and town trades",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3 px-4 pt-4",
			onSubmit: (e) => {
				e.preventDefault();
				if (name.trim().length < 2) return setError("Enter the workshop or your name.");
				if (digits(phone).length < 10) return setError("Enter a 10-digit WhatsApp number.");
				if (place.trim().length < 2) return setError("Enter town or village.");
				if (!isPending && !user) {
					setNeedsAuth(true);
					setError("Sign in to list your trade on the community board.");
					return;
				}
				setBusy(true);
				const nextProfile = {
					...profile,
					name: name.trim(),
					phone: digits(phone).slice(-10),
					district,
					place: place.trim(),
					isServiceProvider: true,
					serviceCategory: trade
				};
				createProvider({ data: {
					providerName: nextProfile.name,
					phone: nextProfile.phone,
					serviceCategory: trade,
					areaType: area,
					district,
					townOrVillage: nextProfile.place,
					experienceYears: Math.max(1, Number(years) || 1),
					description: description.trim()
				} }).then(async (provider) => {
					addProvider(provider);
					const saved = await saveMyProfile({ data: nextProfile });
					saveProfile(saved);
					await refreshBoard();
					setDone(`Listed. Buyers can WhatsApp ${prettyPhone(provider.phone)}.`);
					setError("");
					window.setTimeout(() => void navigate({
						to: "/needs",
						search: { tab: "providers" }
					}), 700);
				}).catch((err) => {
					const message = explainFailure(err);
					setError(message);
					setNeedsAuth(/sign in/i.test(message));
					setBusy(false);
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-mint px-3 py-3 text-xs leading-relaxed text-forest",
					children: "Free for now. A monthly fee may apply later. ShareHaat only introduces you — the job and the payment stay on WhatsApp."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Name or workshop",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: name,
						onChange: (e) => setName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "WhatsApp",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "tel",
						value: phone,
						onChange: (e) => setPhone(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Trade",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: trade,
						onChange: (e) => setTrade(e.target.value),
						children: SERVICE_TRADES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Years of work",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "numeric",
						value: years,
						onChange: (e) => setYears(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Where you work",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: area,
						onChange: (e) => setArea(e.target.value),
						children: AREA_TYPES.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a.key,
							children: a.label
						}, a.key))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Town or village",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: place,
						onChange: (e) => setPlace(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "District",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: district,
						onChange: (e) => setDistrict(e.target.value),
						children: DISTRICTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "What you take on",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} h-24 py-3`,
						value: description,
						onChange: (e) => setDescription(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-deal",
					children: error
				}) : null,
				needsAuth && !isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatSignIn, { callback: "/services" }) : null,
				done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-haat",
					children: done
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: busy,
					className: "h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60",
					children: busy ? "Listing…" : "List my trade"
				})
			]
		})
	});
}
//#endregion
export { ServicesScreen as i, NeedsScreen as n, PostNeedScreen as r, DonateScreen as t };
