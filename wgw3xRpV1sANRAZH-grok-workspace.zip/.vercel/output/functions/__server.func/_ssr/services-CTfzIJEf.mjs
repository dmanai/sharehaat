import { i as ServicesScreen } from "./community-DKChWjsZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-CTfzIJEf.js
var SplitComponent = ServicesScreen;
//#endregion
export { SplitComponent as component };
