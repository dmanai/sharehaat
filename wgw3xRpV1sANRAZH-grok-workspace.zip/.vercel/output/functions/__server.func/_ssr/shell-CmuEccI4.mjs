import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authClient } from "./client-IWHfIGH2.mjs";
import { D as emptyProfile, T as digits, V as waLink, x as buildSeed, y as authMiddleware } from "./data-D2z7szSz.mjs";
import { S as ArrowLeft, _ as ClipboardList, c as Plus, f as Info, h as Hammer, i as Store, l as Phone, m as HandHeart, t as X, u as Menu, v as CircleUser, x as BookOpen } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-CmuEccI4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var HOURS = /* @__PURE__ */ new Set([
	24,
	36,
	72,
	168,
	288,
	360
]);
function num(value) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : 0;
}
function text(value, max) {
	return String(value ?? "").trim().slice(0, max);
}
function phone10(value) {
	return digits(String(value ?? "")).slice(-10);
}
function photo(value) {
	const raw = String(value ?? "");
	if (!raw) return "";
	if (raw.startsWith("https://")) return raw;
	if (!raw.startsWith("data:image/")) throw new Error("Use a photo from the camera or your gallery.");
	const comma = raw.indexOf(",");
	const b64 = raw.slice(comma + 1).replace(/\s/g, "");
	const pad = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
	if (Math.max(0, Math.floor(b64.length * 3 / 4) - pad) > 307200) throw new Error("That photo is over 300 KB. Take it again so WhatsApp can show it.");
	return raw;
}
var getBoard = createServerFn({ method: "GET" }).handler(createSsrRpc("7007c295317ed58f55701b73ac335bbaea2f129c4aa15808423edf8819c91054"));
var getMyProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("292566192e717f756f668de6ee57264fb23e791492b13aa6d4a3ecad8cd3e994"));
var saveMyProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	name: text(input?.name, 80),
	phone: phone10(input?.phone),
	sellerType: text(input?.sellerType, 40) || "Farmer",
	district: text(input?.district, 40) || "Dimapur",
	place: text(input?.place, 80),
	isServiceProvider: Boolean(input?.isServiceProvider),
	serviceCategory: text(input?.serviceCategory, 40)
})).handler(createSsrRpc("c98f80807cea06fcccb4c91dcb724f8e5bbd631f37c8ac8e61e3061b51d10258"));
var deleteMyData = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("77c860c1f1b5bb999e5747b33771250f43acff334bfab3b25825d3e60ecc3fb2"));
var createListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const hours = num(input?.hours);
	if (!HOURS.has(hours)) throw new Error("Choose 24 hrs, 36 hours, 72 hours, or a longer lot.");
	const title = text(input?.title, 120);
	if (title.length < 3) throw new Error("Name the item.");
	const priceInr = Math.round(num(input?.priceInr));
	if (priceInr <= 0) throw new Error("Enter a price in rupees.");
	const qty = num(input?.qty);
	if (qty <= 0) throw new Error("Enter the quantity available.");
	const sellerName = text(input?.sellerName, 80);
	if (sellerName.length < 2) throw new Error("Enter the seller name.");
	const sellerPhone = phone10(input?.sellerPhone);
	if (sellerPhone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
	const originPlace = text(input?.originPlace, 80);
	if (originPlace.length < 2) throw new Error("Enter the village, khel, ward or town.");
	const photoUrl = photo(input?.photoUrl);
	if (!photoUrl) throw new Error("Add a photo from the camera or your gallery.");
	return {
		title,
		category: text(input?.category, 40) || "vegetables",
		priceInr,
		priceUnit: text(input?.priceUnit, 20) || "kg",
		qty,
		qtyUnit: text(input?.qtyUnit, 20) || text(input?.priceUnit, 20) || "kg",
		sellerName,
		sellerPhone,
		sellerType: text(input?.sellerType, 40) || "Farmer",
		district: text(input?.district, 40) || "Dimapur",
		originPlace,
		handover: text(input?.handover, 40) || "Station pickup",
		landmark: text(input?.landmark, 120),
		notes: text(input?.notes, 500),
		photoUrl,
		hours
	};
}).handler(createSsrRpc("950992845bd780628a2dcf2ecb558c5eaba5c28fd70b0fb864b2b0b477c09851"));
var patchMyListing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const id = text(input?.id, 80);
	const status = input?.status;
	if (!id || status !== "active" && status !== "sold" && status !== "deleted") throw new Error("Could not update that lot.");
	return {
		id,
		status
	};
}).handler(createSsrRpc("067c480040275ba895d670e67db2d2303cf97c446470a8bb1c7c008927e86c7c"));
var createNeed = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const kind = input?.kind === "donate" || input?.kind === "services" ? input.kind : "looking";
	const item = text(input?.item, 140);
	if (item.length < 3) throw new Error("Say what you need or are giving.");
	const buyerName = text(input?.buyerName, 80);
	if (buyerName.length < 2) throw new Error("Enter your name.");
	const buyerPhone = phone10(input?.buyerPhone);
	if (buyerPhone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
	const placeName = text(input?.placeName, 80);
	if (placeName.length < 2) throw new Error("Enter the place.");
	return {
		kind,
		item,
		qty: num(input?.qty) || 1,
		qtyUnit: text(input?.qtyUnit, 20) || "kg",
		district: text(input?.district, 40) || "Dimapur",
		placeName,
		neededBy: text(input?.neededBy, 80) || "Within this week",
		budgetInr: kind === "donate" ? 0 : Math.max(0, Math.round(num(input?.budgetInr))),
		buyerType: text(input?.buyerType, 40) || "Household",
		buyerName,
		buyerPhone,
		notes: text(input?.notes, 500),
		trade: text(input?.trade, 40),
		areaType: text(input?.areaType, 20) || "village"
	};
}).handler(createSsrRpc("32f3a64082cbf53a1245d45f3ba9b535f8ca68faf21f24422074ace70d8eace5"));
var createProvider = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const providerName = text(input?.providerName, 80);
	if (providerName.length < 2) throw new Error("Enter the workshop or your name.");
	const phone = phone10(input?.phone);
	if (phone.length < 10) throw new Error("Enter a 10-digit WhatsApp number.");
	const townOrVillage = text(input?.townOrVillage, 80);
	if (townOrVillage.length < 2) throw new Error("Enter town or village.");
	return {
		providerName,
		phone,
		serviceCategory: text(input?.serviceCategory, 40) || "Electrician",
		areaType: text(input?.areaType, 20) || "village",
		district: text(input?.district, 40) || "Dimapur",
		townOrVillage,
		experienceYears: Math.max(1, Math.round(num(input?.experienceYears) || 1)),
		description: text(input?.description, 500)
	};
}).handler(createSsrRpc("dc6716c55f890c1f9033e6ef5d673903047b31a1344fc0a9d1c9429b5adfd0fc"));
var createReview = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const comment = text(input?.comment, 400);
	if (comment.length < 4) throw new Error("Add a short note.");
	const reviewerName = text(input?.reviewerName, 80);
	if (reviewerName.length < 2) throw new Error("Add your name in Seller Profile.");
	return {
		targetId: text(input?.targetId, 40),
		targetType: input?.targetType === "service_provider" ? "service_provider" : "seller",
		targetName: text(input?.targetName, 80),
		reviewerName,
		reviewerPhone: phone10(input?.reviewerPhone),
		rating: Math.min(5, Math.max(1, Math.round(num(input?.rating) || 5))),
		comment
	};
}).handler(createSsrRpc("91dfea01f026341e28f06b0bb5237cda642588e0bc13d5746efac5cf598bbd20"));
var seed = buildSeed();
var useHaat = create()((set) => ({
	listings: seed.listings,
	needs: seed.needs,
	providers: seed.providers,
	reviews: seed.reviews,
	profile: emptyProfile,
	profileReady: false,
	addListing: (listing) => set((s) => ({ listings: [listing, ...s.listings.filter((item) => item.id !== listing.id)] })),
	patchListing: (id, patch) => set((s) => ({ listings: s.listings.map((item) => item.id === id ? {
		...item,
		...patch
	} : item) })),
	addNeed: (need) => set((s) => ({ needs: [need, ...s.needs.filter((item) => item.id !== need.id)] })),
	addProvider: (provider) => set((s) => ({ providers: [provider, ...s.providers.filter((item) => item.id !== provider.id)] })),
	addReview: (review) => set((s) => ({ reviews: [review, ...s.reviews] })),
	saveProfile: (profile) => set({ profile }),
	setProfileReady: (profileReady) => set({ profileReady }),
	setBoard: (board) => set(board)
}));
function useHydrated() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	return ready;
}
var ticket = 0;
var loadedUser = null;
async function refreshBoard() {
	const mine = ++ticket;
	try {
		const board = await getBoard();
		if (mine !== ticket) return false;
		useHaat.getState().setBoard(board);
		return true;
	} catch {
		return false;
	}
}
function useBoardSync() {
	const { user, isPending } = useCurrentUserState();
	(0, import_react.useEffect)(() => {
		refreshBoard();
	}, []);
	(0, import_react.useEffect)(() => {
		if (isPending) return;
		const id = user?.id ?? "";
		if (loadedUser === id) {
			useHaat.getState().setProfileReady(true);
			return;
		}
		loadedUser = id;
		if (!id) {
			useHaat.getState().saveProfile(emptyProfile);
			useHaat.getState().setProfileReady(true);
			return;
		}
		let live = true;
		getMyProfile().then((profile) => {
			if (!live || loadedUser !== id) return;
			useHaat.getState().saveProfile(profile);
			useHaat.getState().setProfileReady(true);
		}).catch(() => {
			if (live) useHaat.getState().setProfileReady(true);
		});
		return () => {
			live = false;
		};
	}, [user?.id, isPending]);
}
function explainFailure(err) {
	const message = err instanceof Error ? err.message : "";
	if (/unauthorized/i.test(message)) return "Sign in to post on the community board.";
	return message || "Could not save that. Try again.";
}
var fieldClass = "h-12 w-full rounded-xl border border-line bg-card px-3 text-sm font-medium text-ink outline-none focus:border-haat";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-semibold text-ink-soft",
			children: label
		}), children]
	});
}
function MemberFillNote({ filled }) {
	if (!filled) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl bg-mint px-3 py-3 text-xs leading-relaxed text-forest",
		children: "You are a registered member, so your name, WhatsApp and place are filled in. Change anything that is wrong."
	});
}
function origin() {
	if (typeof window === "undefined") return "";
	return window.location.origin;
}
function openWa(phone, message) {
	window.open(waLink(phone, message), "_blank", "noopener,noreferrer");
}
var NowContext = (0, import_react.createContext)(Date.now());
function useNow() {
	return (0, import_react.useContext)(NowContext);
}
function useClock() {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 3e4);
		return () => window.clearInterval(id);
	}, []);
	return now;
}
function HaatShell({ title = "ShareHaat", subtitle, back = false, tab = null, account = false, children }) {
	const router = useRouter();
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [post, setPost] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	useBoardSync();
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 3e4);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NowContext.Provider, {
		value: now,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-phone flex-col bg-surface shadow-[0_0_0_1px_var(--color-line)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "sticky top-0 z-30 border-b border-line bg-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 px-3 py-2.5",
						children: [
							back ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Back",
								onClick: () => {
									if (window.history.length > 1) router.history.back();
									else router.navigate({ to: "/" });
								},
								className: "grid size-11 shrink-0 place-items-center rounded-full text-forest",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-9 shrink-0 place-items-center rounded-full bg-mint text-forest",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-lg font-extrabold leading-tight tracking-tight text-forest",
									children: title
								}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs font-semibold text-haat",
									children: subtitle
								}) : null]
							}),
							account ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/account",
								"aria-label": "Your seller profile",
								className: "grid size-11 place-items-center rounded-full text-forest",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleUser, { className: "size-6" })
							}) : null
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: tab === "home" ? post ? "flex-1 pb-64" : "flex-1 pb-40" : tab ? "flex-1 pb-24" : "flex-1 pb-8",
					children
				}),
				tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fixed bottom-[calc(4.35rem+env(safe-area-inset-bottom))] left-1/2 z-30 w-full max-w-phone -translate-x-1/2 px-3",
					children: [post ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 rounded-2xl border border-line bg-card p-2 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-1 pb-2 text-xs font-semibold text-muted",
							children: "Post on ShareHaat. Members get the form filled in."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/post-need",
									search: { kind: "donate" },
									onClick: () => setPost(false),
									className: "flex h-14 items-center justify-center rounded-xl bg-mint text-sm font-bold text-forest",
									children: "Donate"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/sell",
									onClick: () => setPost(false),
									className: "flex h-14 items-center justify-center rounded-xl bg-forest text-sm font-bold text-on-forest",
									children: "Sell"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/post-need",
									search: { kind: "looking" },
									onClick: () => setPost(false),
									className: "flex h-14 items-center justify-center rounded-xl bg-sand text-sm font-bold text-forest",
									children: "Needs"
								})
							]
						})]
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-expanded": post,
							onClick: () => setPost((open) => !open),
							className: `flex h-11 items-center justify-center rounded-xl text-sm font-bold text-on-forest shadow-card ${post ? "bg-haat" : "bg-forest"}`,
							children: "ShareHaat"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/chat",
							className: "flex h-11 items-center justify-center rounded-xl bg-ash text-sm font-bold text-ink-soft shadow-card",
							children: "Ask ShareHaat"
						})]
					})]
				}) : null,
				tab ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "fixed bottom-0 left-1/2 z-40 w-full max-w-phone -translate-x-1/2 border-t border-line bg-card pb-[env(safe-area-inset-bottom)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "grid grid-cols-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
								to: "/",
								label: "Market",
								active: tab === "home"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
								to: "/donate",
								label: "Donate",
								active: tab === "donate"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/sell",
								className: "flex flex-col items-center gap-0.5 px-1 pt-1.5 pb-2 text-forest",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-9 place-items-center rounded-full bg-forest text-on-forest",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold",
									children: "Sell"
								})]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
								to: "/needs",
								label: "Needs",
								active: tab === "needs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setMenu(true),
								className: "flex w-full flex-col items-center gap-0.5 px-1 pt-2 pb-2 text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-medium",
									children: "Menu"
								})]
							}) })
						]
					})
				}) : null,
				menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSheet, { onClose: () => setMenu(false) }) : null
			]
		})
	});
}
function NavItem({ to, label, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: `flex flex-col items-center gap-0.5 px-1 pt-2.5 pb-2 ${active ? "text-forest" : "text-muted"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `grid h-8 place-items-center rounded-full px-3 ${active ? "bg-mint" : ""}`,
			children: label === "Market" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-5" }) : label === "Donate" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHeart, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `text-[11px] ${active ? "font-bold" : "font-medium"}`,
			children: label
		})]
	}) });
}
function MenuSheet({ onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-scrim/45",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": "ShareHaat menu",
			className: "max-h-[88dvh] w-full max-w-phone overflow-y-auto rounded-t-3xl bg-card px-4 pt-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-card",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xl font-bold text-forest",
					children: "ShareHaat Menu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Nagaland cooperative marketplace"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close menu",
					onClick: onClose,
					className: "grid size-11 place-items-center text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuLink, {
						to: "/account",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleUser, { className: "size-5" }),
						tint: "bg-sage text-forest",
						title: "Seller Profile",
						subtitle: "Name and WhatsApp, saved on your account",
						badge: "You",
						onClick: onClose
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuLink, {
						to: "/my-haat",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-5" }),
						tint: "bg-mint text-forest",
						title: "My Haat",
						subtitle: "Your storefront on the community board",
						badge: "Store",
						onClick: onClose
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuLink, {
						to: "/contact",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" }),
						tint: "bg-mint text-haat",
						title: "I don't know how to sell",
						subtitle: "Send a photo or voice note on WhatsApp",
						badge: "Help",
						onClick: onClose
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuLink, {
						to: "/services",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, { className: "size-5" }),
						tint: "bg-mint text-forest",
						title: "Register as Service Provider",
						subtitle: "Electricians, plumbers, mechanics",
						badge: "Free",
						onClick: onClose
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuLink, {
						to: "/schemes",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5" }),
						tint: "bg-sand text-forest",
						title: "Government Schemes",
						subtitle: "PM-KISAN, PMFME, MOVCD-NER, FPOs",
						badge: "Schemes",
						onClick: onClose
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuLink, {
						to: "/terms",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5" }),
						tint: "bg-canvas text-ink-soft",
						title: "About & Community Terms",
						subtitle: "No escrow, FSSAI, community rules",
						badge: "Info",
						onClick: onClose
					})
				]
			})]
		})
	});
}
function MenuLink({ to, icon, tint, title, subtitle, badge, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		onClick,
		className: "flex items-center gap-3 rounded-xl bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `grid size-10 shrink-0 place-items-center rounded-full ${tint}`,
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate text-sm font-bold text-ink",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded bg-mint px-1.5 py-0.5 text-[10px] font-bold text-forest",
					children: badge
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate text-xs text-muted",
				children: subtitle
			})]
		})]
	});
}
//#endregion
export { useNow as S, useClock as _, createNeed as a, useHaat as b, createSsrRpc as c, fieldClass as d, openWa as f, saveMyProfile as g, refreshBoard as h, createListing as i, deleteMyData as l, patchMyListing as m, HaatShell as n, createProvider as o, origin as p, MemberFillNote as r, createReview as s, Field as t, explainFailure as u, useCurrentUser as v, useHydrated as x, useCurrentUserState as y };
