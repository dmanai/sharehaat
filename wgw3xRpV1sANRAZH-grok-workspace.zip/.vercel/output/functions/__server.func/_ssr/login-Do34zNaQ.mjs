import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as HaatSignIn } from "./signin-HxNuRtCI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-Do34zNaQ.js
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-phone flex-col justify-center bg-surface px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-bold tracking-widest text-haat",
				children: "SHAREHAAT"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-extrabold text-forest",
				children: "Sign in to your haat"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-ink-soft",
				children: "Your seller details stay on your account. Lots you post are on the community board for everyone."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatSignIn, { callback: "/" })
			})
		]
	});
}
//#endregion
export { LoginPage as component };
