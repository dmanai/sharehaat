import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as timeLeft, C as consignmentMessage, F as ratingFor, I as readPhoto, L as samePhone, N as qtyLabel, O as matchesCategory, P as rateLabel, S as buyerMessage, T as digits, a as DISTRICTS, d as OPERATOR_WHATSAPP, f as PRICE_UNITS, g as SELL_CATEGORIES, h as SELLER_TYPES, i as CATEGORIES, j as placeOf, l as LISTING_SPANS, s as HANDOVER_OPTIONS, z as shareText } from "./data-D2z7szSz.mjs";
import { b as Camera, d as MapPin, p as ImagePlus, r as SwitchCamera, s as Search, t as X, y as ChevronDown } from "../_libs/lucide-react.mjs";
import { _ as useClock, b as useHaat, d as fieldClass, f as openWa, g as saveMyProfile, h as refreshBoard, i as createListing, m as patchMyListing, n as HaatShell, p as origin, r as MemberFillNote, s as createReview, t as Field, u as explainFailure, x as useHydrated, y as useCurrentUserState } from "./shell-CmuEccI4.mjs";
import { t as HaatSignIn } from "./signin-HxNuRtCI.mjs";
import { i as loadImage, n as fitPhotoUnder300kb, r as jpegKilobytes, t as PHOTO_BYTE_LIMIT } from "./photo-z9DeWH38.mjs";
import { i as ListingCard, n as EmptyNote, r as HaatPhoto, s as SectionTitle, t as DealStory } from "./cards-BJlnlTRd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-BzzKcPZQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function shareResultNote(result) {
	if (result === "shared") return "Shared. Friends get your photo with the lot, under 300 KB.";
	if (result === "copied") return "Photo copied (under 300 KB). Paste it into the WhatsApp chat that just opened.";
	if (result === "downloaded") return "Photo saved (under 300 KB). Attach that image in the WhatsApp chat that opened.";
	if (result === "whatsapp") return "WhatsApp opened. The last link is your storefront photo.";
	return "";
}
function cover(ctx, img, x, y, w, h) {
	const scale = Math.max(w / img.width, h / img.height);
	const dw = img.width * scale;
	const dh = img.height * scale;
	ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}
function wrap(ctx, text, x, y, max, line, lines) {
	const words = text.split(" ");
	let row = "";
	let used = 0;
	for (const word of words) {
		const next = row ? `${row} ${word}` : word;
		if (ctx.measureText(next).width > max && row) {
			ctx.fillText(row, x, y + used * line);
			used += 1;
			row = word;
			if (used >= lines) return;
		} else row = next;
	}
	if (row && used < lines) ctx.fillText(row, x, y + used * line);
}
function toJpeg(canvas, quality) {
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => blob ? resolve(blob) : reject(/* @__PURE__ */ new Error("photo")), "image/jpeg", quality);
	});
}
async function jpegUnder(source, limit) {
	let canvas = source;
	let last = await toJpeg(canvas, .72);
	for (let pass = 0; pass < 5; pass += 1) {
		for (const quality of [
			.82,
			.7,
			.58,
			.46,
			.34
		]) {
			last = await toJpeg(canvas, quality);
			if (last.size <= limit) return last;
		}
		const next = document.createElement("canvas");
		next.width = Math.max(420, Math.round(canvas.width * .78));
		next.height = Math.max(420, Math.round(canvas.height * .78));
		const ctx = next.getContext("2d");
		if (!ctx) break;
		ctx.drawImage(canvas, 0, 0, next.width, next.height);
		canvas = next;
	}
	return last;
}
/** Storefront card: the member's photo on top, lot details under it, file under 300 KB. */
async function buildStorefrontBlob(listing) {
	const img = listing.photoUrl ? await loadImage(listing.photoUrl).catch(() => null) : null;
	const width = 840;
	const photoH = img ? 840 : 0;
	const foot = 280;
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = photoH + foot;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not prepare the photo.");
	if (typeof document !== "undefined" && document.fonts?.load) await document.fonts.load("800 42px Outfit").catch(() => void 0);
	ctx.fillStyle = "#1b4332";
	ctx.fillRect(0, 0, width, canvas.height);
	if (img) {
		ctx.save();
		ctx.beginPath();
		ctx.rect(0, 0, width, photoH);
		ctx.clip();
		cover(ctx, img, 0, 0, width, photoH);
		ctx.restore();
	}
	const y0 = photoH;
	ctx.fillStyle = "#1b4332";
	ctx.fillRect(0, y0, width, foot);
	ctx.fillStyle = "#faedcd";
	ctx.font = "700 22px Outfit, sans-serif";
	ctx.fillText("SHAREHAAT STOREFRONT", 36, y0 + 46);
	ctx.fillStyle = "#ffffff";
	ctx.font = "800 40px Outfit, sans-serif";
	wrap(ctx, listing.title, 36, y0 + 98, 768, 46, 2);
	ctx.fillStyle = "#d8f3dc";
	ctx.font = "700 30px Outfit, sans-serif";
	ctx.fillText(rateLabel(listing.priceInr, listing.priceUnit), 36, y0 + 204);
	ctx.fillStyle = "#ccd5ae";
	ctx.font = "600 22px Outfit, sans-serif";
	const place = placeOf(listing.originPlace, listing.district);
	if (place) ctx.fillText(place.slice(0, 42), 36, y0 + 240);
	ctx.fillStyle = "#faedcd";
	ctx.font = "600 20px Outfit, sans-serif";
	ctx.fillText(listing.productCode, 36, y0 + 268);
	return jpegUnder(canvas, PHOTO_BYTE_LIMIT);
}
function downloadBlob(blob, name) {
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = name;
	link.click();
	URL.revokeObjectURL(url);
}
async function copyImage(blob) {
	if (!navigator.clipboard?.write) return false;
	const url = URL.createObjectURL(blob);
	try {
		const img = await loadImage(url);
		const canvas = document.createElement("canvas");
		canvas.width = img.width;
		canvas.height = img.height;
		const ctx = canvas.getContext("2d");
		if (!ctx) return false;
		ctx.drawImage(img, 0, 0);
		const png = await new Promise((resolve, reject) => {
			canvas.toBlob((file) => file ? resolve(file) : reject(/* @__PURE__ */ new Error("png")), "image/png");
		});
		await navigator.clipboard.write([new ClipboardItem({ "image/png": png })]);
		return true;
	} catch {
		try {
			await navigator.clipboard.write([new ClipboardItem({ "image/jpeg": blob })]);
			return true;
		} catch {
			return false;
		}
	} finally {
		URL.revokeObjectURL(url);
	}
}
function photoPage(listing, origin) {
	if (!origin) return "";
	return `${origin}/api/photo/${encodeURIComponent(listing.id)}/storefront.jpg`;
}
async function shareWithFriends(listing) {
	const origin = typeof window === "undefined" ? "" : window.location.origin;
	const text = shareText(listing, origin, photoPage(listing, origin));
	let blob = null;
	try {
		blob = await buildStorefrontBlob(listing);
	} catch {
		blob = null;
	}
	const file = blob ? new File([blob], `${listing.productCode}.jpg`, { type: "image/jpeg" }) : null;
	const handheld = typeof navigator !== "undefined" && /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
	if (file && handheld && navigator.canShare?.({ files: [file] })) try {
		await navigator.share({
			files: [file],
			title: listing.title,
			text
		});
		return "shared";
	} catch (err) {
		if (err instanceof DOMException && err.name === "AbortError") return "cancelled";
	}
	const copied = blob ? await copyImage(blob) : false;
	if (!copied && blob) downloadBlob(blob, `${listing.productCode}-sharehaat.jpg`);
	window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
	if (copied) return "copied";
	if (blob) return "downloaded";
	return "whatsapp";
}
function PhotoField({ value, onChange, onError }) {
	const galleryRef = (0, import_react.useRef)(null);
	const captureRef = (0, import_react.useRef)(null);
	const [cam, setCam] = (0, import_react.useState)(false);
	async function useFile(file) {
		if (!file) return;
		try {
			onChange(await readPhoto(file));
			onError("");
		} catch (err) {
			onError(err instanceof Error ? err.message : "Could not read that photo.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-2xl border border-dashed border-haat bg-mint/40",
				children: value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatPhoto, {
					src: value,
					alt: "Your storefront photo",
					className: "h-52 w-full"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-36 place-items-center px-4 text-center text-sm font-semibold text-forest",
					children: "This photo is your storefront. It is kept under 300 KB so WhatsApp can show it."
				})
			}),
			value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-xs font-semibold text-haat",
				children: [
					"Ready for WhatsApp · ",
					jpegKilobytes(value),
					" KB"
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-muted",
				children: "Photos are resized under 300 KB automatically."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setCam(true),
					className: "flex h-12 items-center justify-center gap-2 rounded-xl bg-forest text-sm font-bold text-on-forest",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }), "Take photo"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => galleryRef.current?.click(),
					className: "flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-card text-sm font-bold text-forest",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), "Gallery"]
				})]
			}),
			value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(""),
				className: "h-10 w-full text-xs font-semibold text-muted",
				children: "Remove photo"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: galleryRef,
				type: "file",
				accept: "image/*",
				className: "sr-only",
				onChange: (e) => {
					useFile(e.target.files?.[0]);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: captureRef,
				type: "file",
				accept: "image/*",
				capture: "environment",
				className: "sr-only",
				onChange: (e) => {
					useFile(e.target.files?.[0]);
					e.target.value = "";
				}
			}),
			cam ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraSheet, {
				onShot: (url) => {
					fitPhotoUnder300kb(url).then((fitted) => {
						onChange(fitted.dataUrl);
						onError("");
						setCam(false);
					}).catch(() => {
						onError("Could not prepare that photo under 300 KB.");
						setCam(false);
					});
				},
				onClose: () => setCam(false),
				onSystemCamera: () => {
					setCam(false);
					captureRef.current?.click();
				}
			}) : null
		]
	});
}
function CameraSheet({ onShot, onClose, onSystemCamera }) {
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const [facing, setFacing] = (0, import_react.useState)("environment");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [fail, setFail] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setReady(false);
		setFail("");
		const video = videoRef.current;
		async function start() {
			if (!navigator.mediaDevices?.getUserMedia) {
				setFail("This browser cannot open the camera here.");
				return;
			}
			try {
				const stream = await navigator.mediaDevices.getUserMedia({
					audio: false,
					video: {
						facingMode: facing,
						width: { ideal: 1280 },
						height: { ideal: 960 }
					}
				});
				if (cancelled) {
					stream.getTracks().forEach((track) => track.stop());
					return;
				}
				streamRef.current = stream;
				if (video) {
					video.srcObject = stream;
					await video.play();
				}
				setReady(true);
			} catch {
				if (!cancelled) setFail("Camera permission was blocked. Use the phone camera or your gallery.");
			}
		}
		start();
		return () => {
			cancelled = true;
			streamRef.current?.getTracks().forEach((track) => track.stop());
			streamRef.current = null;
			if (video) video.srcObject = null;
		};
	}, [facing]);
	function shoot() {
		const video = videoRef.current;
		if (!video || !video.videoWidth) return;
		const scale = Math.min(1, 1600 / Math.max(video.videoWidth, video.videoHeight));
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
		canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
		onShot(canvas.toDataURL("image/jpeg", .9));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-scrim text-on-forest",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "Close camera",
						className: "grid size-11 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold",
						children: "Storefront photo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Flip camera",
						onClick: () => setFacing((side) => side === "environment" ? "user" : "environment"),
						className: "grid size-11 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchCamera, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-0 flex-1 bg-scrim",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					ref: videoRef,
					autoPlay: true,
					playsInline: true,
					muted: true,
					className: "h-full w-full object-cover"
				}), fail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 grid place-items-center px-6 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-xs space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: fail
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onSystemCamera,
							className: "h-11 w-full rounded-xl bg-card text-sm font-bold text-forest",
							children: "Open phone camera"
						})]
					})
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid place-items-center px-4 pt-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Take photo",
					disabled: !ready,
					onClick: shoot,
					className: "grid size-16 place-items-center rounded-full border-4 border-on-forest bg-card disabled:opacity-40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-12 rounded-full bg-on-forest" })
				})
			})
		]
	});
}
function HomeScreen() {
	const listings = useHaat((s) => s.listings);
	const needs = useHaat((s) => s.needs);
	const reviews = useHaat((s) => s.reviews);
	const now = useClock();
	const navigate = useNavigate();
	const [q, setQ] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	const [district, setDistrict] = (0, import_react.useState)(null);
	const [districtOpen, setDistrictOpen] = (0, import_react.useState)(false);
	const [shareNote, setShareNote] = (0, import_react.useState)("");
	async function shareListing(listing) {
		setShareNote("Preparing your photo…");
		const result = await shareWithFriends(listing);
		setShareNote(shareResultNote(result));
	}
	const live = listings.filter((l) => l.status === "active" && l.expiresAt > now);
	const deals = live.filter((l) => l.listingKind === "todays_deal").sort((a, b) => Number(b.featured) - Number(a.featured));
	const members = live.filter((l) => matchesCategory(l, category)).filter((l) => !district || l.district === district).filter((l) => {
		if (!q.trim()) return true;
		return `${l.title} ${l.district} ${l.originPlace} ${l.productCode} ${l.sellerName}`.toLowerCase().includes(q.trim().toLowerCase());
	}).sort((a, b) => b.createdAt - a.createdAt);
	const looking = needs.filter((n) => n.status === "open" && n.kind !== "donate" && n.needCategoryType === "goods").slice(0, 2);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HaatShell, {
		subtitle: "Photograph it. Share it. Sell it on WhatsApp.",
		tab: "home",
		account: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 px-4 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-12 items-center gap-2 rounded-full border border-line bg-card px-3 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 shrink-0 text-forest" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Search produce, honey, chillies...",
							className: "min-w-0 flex-1 bg-transparent text-sm font-medium text-ink outline-none placeholder:text-muted",
							suppressHydrationWarning: true
						}),
						q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Clear search",
							onClick: () => setQ(""),
							className: "text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setDistrictOpen(true),
							className: `inline-flex max-w-28 items-center gap-0.5 rounded-full px-2 py-1 text-[11px] font-semibold ${district ? "bg-mint text-forest" : "bg-canvas text-ink"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3 shrink-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: district ?? "Nagaland"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3 shrink-0" })
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1",
					children: CATEGORIES.map((c) => {
						const on = category === c.key;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCategory(c.key),
							className: `h-9 shrink-0 rounded-full border px-3 text-xs font-semibold ${on ? "border-forest bg-forest text-on-forest" : "border-line bg-card text-ink"}`,
							children: c.label
						}, c.key);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						title: "ShareHaat Deals",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void navigate({ to: "/deals" }),
							className: "text-xs font-bold text-forest",
							children: "View all"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 inline-flex rounded bg-deal-soft px-1.5 py-0.5 text-[10px] font-bold text-deal",
						children: "24h / 36h / 72h status"
					}),
					deals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, { children: "No active timed deals. Tap Sell to post a lot." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "no-scrollbar -mx-4 mt-2 flex gap-2 overflow-x-auto px-4",
						children: deals.map((deal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DealStory, {
							listing: deal,
							onOpen: () => void navigate({
								to: "/listing/$listingId",
								params: { listingId: deal.id }
							})
						}, deal.id))
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						title: "Community storefronts",
						hint: district ? `Lots in ${district}` : "Every photo on the board is visible to all",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-xl bg-mint px-2 py-1 text-[11px] font-bold text-forest",
							children: [members.length, " items"]
						})
					}), members.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyNote, { children: [
						"No listings match.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "font-bold text-forest",
							onClick: () => {
								setQ("");
								setCategory("all");
								setDistrict(null);
							},
							children: "Reset filters"
						})
					] }) : members.map((listing) => {
						const rating = ratingFor(reviews, [listing.sellerPhone, listing.userId]);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCard, {
							listing,
							rating,
							onChat: () => openWa(listing.sellerPhone, buyerMessage(listing, origin())),
							onShare: () => void shareListing(listing)
						}, listing.id);
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void navigate({
						to: "/needs",
						search: { tab: "goods" }
					}),
					className: "flex w-full items-center justify-between rounded-xl bg-deal px-3.5 py-3 text-left text-on-forest",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-extrabold",
						children: "Buyer’s Need & Looking For"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[11px]",
						children: "Produce, bulk lots, and services such as electrician or mechanic"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "›"
					})]
				}),
				looking.length === 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						"Open asks include ",
						looking.map((n) => n.item).join(" · "),
						"."
					]
				}),
				shareNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-mint px-3 py-3 text-xs font-semibold text-forest",
					children: shareNote
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl border border-line bg-card px-4 py-5 text-center text-sm font-bold leading-snug text-forest",
					children: "Your photo is your storefront. Everyone on ShareHaat can see it, and buyers chat you on WhatsApp."
				})
			]
		}), districtOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex items-end justify-center bg-scrim/45",
			onClick: () => setDistrictOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-h-[70dvh] w-full max-w-phone overflow-y-auto rounded-t-3xl bg-card p-3",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 py-2 text-sm font-bold text-forest",
						children: "District"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "block w-full rounded-xl px-3 py-3 text-left text-sm font-semibold",
						onClick: () => {
							setDistrict(null);
							setDistrictOpen(false);
						},
						children: "All of Nagaland"
					}),
					DISTRICTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "block w-full rounded-xl px-3 py-3 text-left text-sm",
						onClick: () => {
							setDistrict(d);
							setDistrictOpen(false);
						},
						children: d
					}, d))
				]
			})
		}) : null]
	});
}
function DealsScreen() {
	const ready = useHydrated();
	const listings = useHaat((s) => s.listings);
	const reviews = useHaat((s) => s.reviews);
	const now = useClock();
	const navigate = useNavigate();
	const [shareNote, setShareNote] = (0, import_react.useState)("");
	const deals = listings.filter((l) => l.status === "active" && l.listingKind === "todays_deal" && l.expiresAt > now).sort((a, b) => a.expiresAt - b.expiresAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "ShareHaat Deals",
		subtitle: "Timed lots (24, 36 and 72 hours)",
		back: true,
		tab: "home",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-2xl bg-deal-soft p-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold text-deal",
						children: "Today’s flash deals"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-ink-soft",
						children: "Short lots from fields, kitchens and makers."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void navigate({
							to: "/sell",
							search: { kind: "deal" }
						}),
						className: "h-10 shrink-0 rounded-lg bg-deal px-3 text-xs font-bold text-on-forest",
						children: "Post deal"
					})]
				}),
				!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Loading deals…"
				}) : null,
				ready && deals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, { children: "No live deals. Post one before the lot moves." }) : null,
				deals.map((listing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCard, {
					listing,
					rating: ratingFor(reviews, [listing.sellerPhone]),
					onChat: () => openWa(listing.sellerPhone, buyerMessage(listing, origin())),
					onShare: () => {
						setShareNote("Preparing your photo…");
						shareWithFriends(listing).then((result) => setShareNote(shareResultNote(result)));
					}
				}, listing.id)),
				shareNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-mint px-3 py-3 text-xs font-semibold text-forest",
					children: shareNote
				}) : null
			]
		})
	});
}
function SellScreen({ initialKind }) {
	const profile = useHaat((s) => s.profile);
	const profileReady = useHaat((s) => s.profileReady);
	const saveProfile = useHaat((s) => s.saveProfile);
	const addListing = useHaat((s) => s.addListing);
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [title, setTitle] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("spices");
	const [price, setPrice] = (0, import_react.useState)("");
	const [unit, setUnit] = (0, import_react.useState)("kg");
	const [qty, setQty] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [sellerType, setSellerType] = (0, import_react.useState)("Farmer");
	const [place, setPlace] = (0, import_react.useState)("");
	const [district, setDistrict] = (0, import_react.useState)("Dimapur");
	const [handover, setHandover] = (0, import_react.useState)(HANDOVER_OPTIONS[0]);
	const [landmark, setLandmark] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [photo, setPhoto] = (0, import_react.useState)("");
	const [hours, setHours] = (0, import_react.useState)(initialKind === "todays_deal" ? 24 : 24);
	const [error, setError] = (0, import_react.useState)("");
	const [needsAuth, setNeedsAuth] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [seeded, setSeeded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!profileReady || seeded || isPending) return;
		setName(profile.name || (user && !user.isDevFallback ? user.displayName || "" : ""));
		setPhone(profile.phone);
		setSellerType(profile.sellerType || "Farmer");
		setPlace(profile.place);
		setDistrict(profile.district || "Dimapur");
		setSeeded(true);
	}, [
		profileReady,
		seeded,
		profile,
		user,
		isPending
	]);
	async function submit() {
		if (!photo) return setError("Take a photo or choose one from your gallery.");
		if (title.trim().length < 3) return setError("Name the item.");
		if (!Number(price) || Number(price) <= 0) return setError("Enter a price in rupees.");
		if (!Number(qty) || Number(qty) <= 0) return setError("Enter the quantity available.");
		if (name.trim().length < 2) return setError("Enter the seller name.");
		if (digits(phone).length < 10) return setError("Enter a 10-digit WhatsApp number.");
		if (place.trim().length < 2) return setError("Enter the village, khel, ward or town.");
		if (!isPending && !user) {
			setNeedsAuth(true);
			setError("Sign in so this lot is saved to your account and shown to everyone.");
			return;
		}
		setError("");
		setBusy(true);
		let photoUrl = photo;
		try {
			photoUrl = (await fitPhotoUnder300kb(photo)).dataUrl;
		} catch {
			setBusy(false);
			return setError("Could not prepare that photo under 300 KB. Take it again.");
		}
		const nextProfile = {
			...profile,
			name: name.trim(),
			phone: digits(phone).slice(-10),
			sellerType,
			district,
			place: place.trim()
		};
		try {
			const listing = await createListing({ data: {
				title: title.trim(),
				category,
				priceInr: Number(price),
				priceUnit: unit,
				qty: Number(qty),
				qtyUnit: unit,
				sellerName: nextProfile.name,
				sellerPhone: nextProfile.phone,
				sellerType,
				district,
				originPlace: nextProfile.place,
				handover,
				landmark: landmark.trim(),
				notes: notes.trim(),
				photoUrl,
				hours
			} });
			addListing(listing);
			const saved = await saveMyProfile({ data: nextProfile });
			saveProfile(saved);
			await refreshBoard();
			navigate({
				to: "/listing/$listingId",
				params: { listingId: listing.id }
			});
		} catch (err) {
			const message = explainFailure(err);
			setError(message);
			setNeedsAuth(/sign in/i.test(message));
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Sell on ShareHaat",
		subtitle: "Photo, rate, WhatsApp. The lot is public.",
		back: true,
		tab: "sell",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3 px-4 pt-4",
			onSubmit: (e) => {
				e.preventDefault();
				submit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberFillNote, { filled: Boolean(profile.name || profile.phone || profile.place || user && !user.isDevFallback && user.displayName) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoField, {
					value: photo,
					onChange: setPhoto,
					onError: setError
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Item name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: title,
						onChange: (e) => setTitle(e.target.value),
						placeholder: "Fresh King Chilli (Raja Mircha)"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Category",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: category,
						onChange: (e) => setCategory(e.target.value),
						children: SELL_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.key,
							children: c.label
						}, c.key))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Price in ₹",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "decimal",
							value: price,
							onChange: (e) => setPrice(e.target.value),
							placeholder: "350"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Per unit",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: unit,
							onChange: (e) => setUnit(e.target.value),
							children: PRICE_UNITS.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: u }, u))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Quantity available",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "decimal",
						value: qty,
						onChange: (e) => setQty(e.target.value),
						placeholder: "50"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1.5 text-xs font-semibold text-ink-soft",
					children: "How long it stays on the board"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: LISTING_SPANS.map((span) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setHours(span.hours),
						className: `h-9 rounded-full px-3 text-xs font-bold ${hours === span.hours ? "bg-forest text-on-forest" : "border border-line bg-card text-ink-soft"}`,
						children: span.label
					}, span.hours))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Seller name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Your full name"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "WhatsApp mobile",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "tel",
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						placeholder: "10-digit mobile"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Seller type",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: sellerType,
						onChange: (e) => setSellerType(e.target.value),
						children: SELLER_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Village / khel / ward / town",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: place,
						onChange: (e) => setPlace(e.target.value),
						placeholder: "Longkhum village"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "District in Nagaland",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: district,
						onChange: (e) => setDistrict(e.target.value),
						children: DISTRICTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Handover",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: handover,
						onChange: (e) => setHandover(e.target.value),
						children: HANDOVER_OPTIONS.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: h }, h))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Landmark / station",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: landmark,
						onChange: (e) => setLandmark(e.target.value),
						placeholder: "Mokokchung NST Station"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notes",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${fieldClass} h-24 py-3`,
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						placeholder: "Organic harvest, packed in bamboo lots..."
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-deal",
					children: error
				}) : null,
				needsAuth && !isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatSignIn, { callback: "/sell" }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: busy,
					className: "h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60",
					children: busy ? "Publishing…" : "Publish on the community haat"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pb-2 text-center text-[11px] leading-relaxed text-muted",
					children: "Your photo becomes the storefront and the WhatsApp card. ShareHaat never takes money for goods."
				})
			]
		})
	});
}
function ListingScreen({ listingId }) {
	const ready = useHydrated();
	const listing = useHaat((s) => s.listings.find((l) => l.id === listingId));
	const reviews = useHaat((s) => s.reviews);
	const profile = useHaat((s) => s.profile);
	const addReview = useHaat((s) => s.addReview);
	const now = useClock();
	const [sharing, setSharing] = (0, import_react.useState)(false);
	const [stars, setStars] = (0, import_react.useState)(5);
	const [comment, setComment] = (0, import_react.useState)("");
	const [buyerPlace, setBuyerPlace] = (0, import_react.useState)("");
	const [preference, setPreference] = (0, import_react.useState)("Sumo / NST drop");
	const [sent, setSent] = (0, import_react.useState)("");
	const [shareNote, setShareNote] = (0, import_react.useState)("");
	const rated = (0, import_react.useMemo)(() => listing ? ratingFor(reviews, [listing.sellerPhone, listing.userId]) : {
		avg: 0,
		count: 0,
		items: []
	}, [listing, reviews]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Listing",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 py-8 text-sm text-muted",
			children: "Opening the lot…"
		})
	});
	if (!listing || listing.status === "deleted") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Listing",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, { children: "This listing is not on the board." })
	});
	const deal = listing.listingKind === "todays_deal";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Lot",
		subtitle: listing.productCode,
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatPhoto, {
					src: listing.photoUrl,
					alt: listing.title,
					className: "h-72 w-full"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: `absolute top-3 left-3 inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-bold text-on-forest ${deal ? "bg-deal" : "bg-forest"}`,
					children: [
						deal ? "Deal" : "Member",
						" · ",
						timeLeft(listing.expiresAt, now)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-3 right-3 rounded-lg bg-scrim/75 px-2.5 py-1 text-xs font-bold text-on-forest",
					children: listing.productCode
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold leading-tight text-ink",
					children: listing.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between rounded-2xl bg-mint/70 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Rate"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xl font-bold text-forest",
						children: rateLabel(listing.priceInr, listing.priceUnit)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Available"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base font-bold",
							children: qtyLabel(listing.qty, listing.qtyUnit)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => openWa(listing.sellerPhone, buyerMessage(listing, origin())),
					className: "h-14 w-full rounded-xl bg-wa text-base font-bold text-on-forest",
					children: "Chat with seller on WhatsApp"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: sharing,
					onClick: () => {
						setSharing(true);
						setShareNote("Preparing your photo…");
						shareWithFriends(listing).then((result) => setShareNote(shareResultNote(result))).finally(() => setSharing(false));
					},
					className: "h-14 w-full rounded-xl bg-forest text-base font-bold text-on-forest disabled:opacity-60",
					children: sharing ? "Preparing photo…" : "Share this item with friends"
				}),
				shareNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold text-haat",
					children: shareNote
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-card p-3.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-bold",
							children: "Origin & handover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-2 space-y-1.5 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Place",
									v: placeOf(listing.originPlace, listing.district)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Handover",
									v: listing.handover
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Landmark",
									v: listing.landmark || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Seller",
									v: `${listing.sellerName} · ${listing.sellerType}`
								})
							]
						}),
						listing.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-ink-soft",
							children: listing.notes
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-card p-3.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-bold",
							children: "Ask the cooperative to move this lot"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Existing Sumo, NST or hired truck. Goods money stays with the seller."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} mt-2`,
							value: buyerPlace,
							onChange: (e) => setBuyerPlace(e.target.value),
							placeholder: "Buyer place, town or station"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} mt-2`,
							value: preference,
							onChange: (e) => setPreference(e.target.value),
							placeholder: "Sumo / NST / hired truck"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => openWa(OPERATOR_WHATSAPP, consignmentMessage(listing, buyerPlace || "to confirm", preference)),
							className: "mt-2 h-11 w-full rounded-xl bg-ochre text-sm font-bold text-forest",
							children: "Message helpdesk"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-sm font-bold",
						children: ["Seller word ", rated.count ? `· ${rated.avg.toFixed(1)} from ${rated.count}` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 space-y-2",
						children: rated.items.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "rounded-xl bg-card px-3 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold text-star",
									children: "★".repeat(r.rating)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-ink-soft",
									children: r.comment
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted",
									children: r.reviewerName
								})
							]
						}, r.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 space-y-2",
						onSubmit: (e) => {
							e.preventDefault();
							if (!profile.name || comment.trim().length < 4) {
								setSent("Add your name in Seller Profile, and a short note.");
								return;
							}
							if (samePhone(profile.phone, listing.sellerPhone)) {
								setSent("Sellers don’t review their own lot.");
								return;
							}
							createReview({ data: {
								targetId: listing.sellerPhone,
								targetType: "seller",
								targetName: listing.sellerName,
								reviewerName: profile.name,
								reviewerPhone: profile.phone,
								rating: stars,
								comment: comment.trim()
							} }).then((review) => {
								addReview(review);
								setComment("");
								setSent("Saved on the community board.");
								return refreshBoard();
							}).catch((err) => setSent(explainFailure(err)));
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-1",
								children: [
									1,
									2,
									3,
									4,
									5
								].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setStars(n),
									className: `size-9 rounded-lg text-sm font-bold ${n <= stars ? "bg-sand text-star" : "bg-canvas text-muted"}`,
									children: n
								}, n))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: `${fieldClass} h-20 py-2`,
								value: comment,
								onChange: (e) => setComment(e.target.value),
								placeholder: "How was the lot, weight and handover?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "h-11 w-full rounded-xl border border-forest text-sm font-bold text-forest",
								children: "Leave a note"
							}),
							sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-haat",
								children: sent
							}) : null
						]
					})
				] })
			]
		})] })
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-right font-medium",
			children: v
		})]
	});
}
function MyHaatScreen() {
	const ready = useHydrated();
	const listings = useHaat((s) => s.listings);
	const patchListing = useHaat((s) => s.patchListing);
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [statusError, setStatusError] = (0, import_react.useState)("");
	const mine = listings.filter((l) => l.status !== "deleted" && user && l.userId === user.id);
	async function setStatus(id, status) {
		patchListing(id, { status });
		try {
			await patchMyListing({ data: {
				id,
				status
			} });
			await refreshBoard();
			setStatusError("");
		} catch (err) {
			setStatusError(explainFailure(err));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "My Haat",
		subtitle: "Your storefront, visible to everyone",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-mint px-3 py-3 text-xs leading-relaxed text-forest",
					children: "Lots you publish sit on the community board. Any ShareHaat visitor can open the photo, the rate, and your WhatsApp."
				}),
				isPending || !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Opening your storefront…"
				}) : null,
				!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, { children: "Sign in to see and manage the lots on your storefront." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatSignIn, { callback: "/my-haat" })]
				}) : null,
				!isPending && user && mine.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, { children: "Nothing listed from your account yet. A new lot shows here and on the market." }) : null,
				statusError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-deal",
					children: statusError
				}) : null,
				mine.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "flex gap-3 rounded-2xl border border-line bg-card p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "shrink-0",
						onClick: () => void navigate({
							to: "/listing/$listingId",
							params: { listingId: l.id }
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatPhoto, {
							src: l.photoUrl,
							alt: "",
							className: "h-16 w-16 rounded-xl"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "text-left",
							onClick: () => void navigate({
								to: "/listing/$listingId",
								params: { listingId: l.id }
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-bold",
								children: l.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									l.productCode,
									" · ",
									l.status,
									" · ",
									rateLabel(l.priceInr, l.priceUnit)
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-10 rounded-lg bg-mint text-xs font-bold text-forest",
								onClick: () => void setStatus(l.id, l.status === "sold" ? "active" : "sold"),
								children: l.status === "sold" ? "Mark active" : "Mark sold"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-10 rounded-lg border border-line text-xs font-bold text-deal",
								onClick: () => void setStatus(l.id, "deleted"),
								children: "Take down"
							})]
						})]
					})]
				}, l.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void navigate({ to: "/sell" }),
					className: "h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest",
					children: "Post another lot"
				})
			]
		})
	});
}
//#endregion
export { SellScreen as a, MyHaatScreen as i, HomeScreen as n, ListingScreen as r, DealsScreen as t };
