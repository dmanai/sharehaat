import { i as MyHaatScreen } from "./market-BzzKcPZQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/my-haat-UjpWmOoq.js
var SplitComponent = MyHaatScreen;
//#endregion
export { SplitComponent as component };
