import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { i as signOut } from "./client-IWHfIGH2.mjs";
import { a as hasGateSessionMarker } from "./server-TFxhS46V.mjs";
import { D as emptyProfile, M as prettyPhone, _ as SERVICE_TRADES, a as DISTRICTS, b as boardBrief, c as LEGAL_NOTICE, d as OPERATOR_WHATSAPP, h as SELLER_TYPES, m as SCHEMES, o as FSSAI_DUTY, p as PROHIBITED_NOTICE, t as APP_BLURB, u as OPERATOR_NAME, v as advise, w as contactMessage } from "./data-D2z7szSz.mjs";
import { b as useHaat, c as createSsrRpc, d as fieldClass, f as openWa, g as saveMyProfile, h as refreshBoard, l as deleteMyData, n as HaatShell, t as Field, u as explainFailure, v as useCurrentUser, y as useCurrentUserState } from "./shell-CmuEccI4.mjs";
import { t as HaatSignIn } from "./signin-HxNuRtCI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/info-kxYs0b-S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var askHaat = createServerFn({ method: "POST" }).validator((input) => {
	const message = String(input?.message ?? "").trim().slice(0, 800);
	if (message.length < 2) throw new Error("Ask a fuller question.");
	return {
		role: input?.role === "fast" || input?.role === "deep" ? input.role : "market",
		message,
		board: String(input?.board ?? "").slice(0, 2400)
	};
}).handler(createSsrRpc("84551e55bd5030d9504f230c472fd76df8f548af218c8e28264d57da3b110414"));
function SchemesScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Schemes",
		subtitle: "Official desks. ShareHaat does not apply for you.",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3 px-4 pt-4",
			children: SCHEMES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-bold tracking-wide text-haat",
						children: s.who
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-bold text-forest",
						children: s.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-ink-soft",
						children: s.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: s.href,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex h-10 items-center rounded-lg bg-forest px-3 text-xs font-bold text-on-forest",
							children: "Official site"
						}), s.extraHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: s.extraHref,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex h-10 items-center rounded-lg border border-line px-3 text-xs font-bold text-forest",
							children: s.extraLabel ?? "State page"
						}) : null]
					})
				]
			}, s.id))
		})
	});
}
function TermsScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "About & Terms",
		subtitle: "How the haat works",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4 pt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold text-muted",
				children: OPERATOR_NAME
			}), [
				{
					title: "What ShareHaat is",
					body: APP_BLURB
				},
				{
					title: "1. WhatsApp is the chat. ShareHaat is the board.",
					body: LEGAL_NOTICE
				},
				{
					title: "2. A simple storefront",
					body: "A listing is a name, photo, category, mobile, village or ward, district, and a rate. No PIN. No OTP. Lots can stay up 24 hrs, 36 hours, 72 hours, or 7, 12 or 15 days."
				},
				{
					title: "3. Food and FSSAI",
					body: FSSAI_DUTY
				},
				{
					title: "4. Consignments and the road",
					body: "For a full harvest lot, the cooperative can help book an existing Sumo, town drop, or hired truck. Weight loss and spoilage in transit are not guaranteed. Goods money stays between buyer and seller."
				},
				{
					title: "5. Prohibited items",
					body: PROHIBITED_NOTICE
				}
			].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-line bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-bold text-forest",
					children: c.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-sm leading-relaxed text-ink-soft",
					children: c.body
				})]
			}, c.title))]
		})
	});
}
function ContactScreen() {
	const [voice, setVoice] = (0, import_react.useState)(false);
	const [sellerName, setSellerName] = (0, import_react.useState)("");
	const [itemName, setItemName] = (0, import_react.useState)("");
	const [rate, setRate] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)("");
	const [mobile, setMobile] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "I don't know how to sell",
		subtitle: "We can list it for you on WhatsApp",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3 px-4 pt-4",
			onSubmit: (e) => {
				e.preventDefault();
				if (!sellerName.trim() || !itemName.trim() || digitsOk(mobile) === false) {
					setError("Name, item and a 10-digit mobile are required.");
					return;
				}
				openWa(OPERATOR_WHATSAPP, contactMessage({
					sellerName,
					itemName,
					rate,
					qty,
					mobile,
					voice
				}));
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-mint/60 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold text-forest",
						children: "Need help listing a harvest?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs leading-relaxed text-ink-soft",
						children: [
							"Send a photo or a voice note on WhatsApp (+91 ",
							prettyPhone(OPERATOR_WHATSAPP),
							"). ",
							OPERATOR_NAME,
							" can put it on the board for you."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setVoice(false),
						className: `h-11 rounded-xl text-sm font-bold ${!voice ? "bg-forest text-on-forest" : "border border-line bg-card"}`,
						children: "Fill details"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setVoice(true),
						className: `h-11 rounded-xl text-sm font-bold ${voice ? "bg-wa text-on-forest" : "border border-line bg-card"}`,
						children: "Voice note"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Seller’s name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: sellerName,
						onChange: (e) => setSellerName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Item name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: itemName,
						onChange: (e) => setItemName(e.target.value)
					})
				}),
				!voice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Rate",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: rate,
						onChange: (e) => setRate(e.target.value),
						placeholder: "₹350/kg"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Quantity",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: qty,
						onChange: (e) => setQty(e.target.value)
					})
				})] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mobile",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "tel",
						value: mobile,
						onChange: (e) => setMobile(e.target.value)
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-deal",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-12 w-full rounded-xl bg-wa text-sm font-bold text-on-forest",
					children: "Open WhatsApp"
				})
			]
		})
	});
}
function digitsOk(value) {
	return value.replace(/\D/g, "").length >= 10;
}
function AccountScreen() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Seller Profile",
		subtitle: "Your particulars",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 py-8 text-sm text-muted",
			children: "Opening your profile…"
		})
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Seller Profile",
		subtitle: "Your particulars",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4 pt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-ink-soft",
				children: "Sign in once. Sell, donate and buyer needs will fill your name, WhatsApp and village. You can edit or clear them any time."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatSignIn, { callback: "/account" })]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountForm, {});
}
function AccountForm() {
	const profile = useHaat((s) => s.profile);
	const profileReady = useHaat((s) => s.profileReady);
	const saveProfile = useHaat((s) => s.saveProfile);
	const [draft, setDraft] = (0, import_react.useState)(profile);
	const [primed, setPrimed] = (0, import_react.useState)(false);
	const [saved, setSaved] = (0, import_react.useState)("");
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!profileReady || primed) return;
		setDraft(profile);
		setPrimed(true);
	}, [
		profileReady,
		primed,
		profile
	]);
	async function persist(next = draft) {
		setBusy(true);
		setSaved("");
		try {
			const savedProfile = await saveMyProfile({ data: {
				...next,
				phone: next.phone.replace(/\D/g, "").slice(-10),
				name: next.name.trim(),
				place: next.place.trim()
			} });
			saveProfile(savedProfile);
			setDraft(savedProfile);
			setSaved("Saved. Sell, donate and needs will use these details.");
		} catch (err) {
			setSaved(explainFailure(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Seller Profile",
		subtitle: "Used whenever you sell, donate or post a need",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-3 px-4 pt-4",
			onSubmit: (e) => {
				e.preventDefault();
				persist();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-ink-soft",
					children: "These particulars fill in on Sell, Donate and Buyer’s Need. Change them here, or edit them on a post. Clear a field to remove it."
				}),
				!profileReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Loading your saved details…"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: draft.name,
						onChange: (e) => setDraft({
							...draft,
							name: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "WhatsApp",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						inputMode: "tel",
						value: draft.phone,
						onChange: (e) => setDraft({
							...draft,
							phone: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "You usually sell as",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: draft.sellerType,
						onChange: (e) => setDraft({
							...draft,
							sellerType: e.target.value
						}),
						children: SELLER_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "District",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: draft.district,
						onChange: (e) => setDraft({
							...draft,
							district: e.target.value
						}),
						children: DISTRICTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Village or ward",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: draft.place,
						onChange: (e) => setDraft({
							...draft,
							place: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: draft.isServiceProvider,
						onChange: (e) => setDraft({
							...draft,
							isServiceProvider: e.target.checked
						})
					}), "I also take service jobs"]
				}),
				draft.isServiceProvider ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Trade",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: draft.serviceCategory,
						onChange: (e) => setDraft({
							...draft,
							serviceCategory: e.target.value
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Choose"
						}), SERVICE_TRADES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))]
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: busy,
					className: "h-12 w-full rounded-xl bg-forest text-sm font-bold text-on-forest disabled:opacity-60",
					children: "Save particulars"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => {
						const cleared = {
							...draft,
							name: "",
							phone: "",
							place: "",
							serviceCategory: "",
							isServiceProvider: false
						};
						setDraft(cleared);
						persist(cleared);
					},
					className: "h-11 w-full rounded-xl border border-line text-sm font-bold text-ink-soft",
					children: "Clear my details"
				}),
				confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => {
						setBusy(true);
						deleteMyData().then(async () => {
							const cleared = {
								...emptyProfile,
								district: draft.district,
								sellerType: draft.sellerType
							};
							saveProfile(cleared);
							setDraft(cleared);
							await refreshBoard();
							setSaved("Your lots, needs and profile were deleted.");
							setConfirmDelete(false);
						}).catch((err) => setSaved(explainFailure(err))).finally(() => setBusy(false));
					},
					className: "h-11 w-full rounded-xl bg-deal text-sm font-bold text-on-forest",
					children: "Yes, delete my data"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setConfirmDelete(true),
					className: "h-11 w-full text-sm font-semibold text-deal",
					children: "Delete my data"
				}),
				saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-sm font-semibold text-haat",
					children: saved
				}) : null
			]
		})
	});
}
function ChatScreen() {
	const listings = useHaat((s) => s.listings);
	const needs = useHaat((s) => s.needs);
	const providers = useHaat((s) => s.providers);
	const [role, setRole] = (0, import_react.useState)("market");
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [messages, setMessages] = (0, import_react.useState)([{
		id: "welcome",
		from: "bot",
		tag: "Ask ShareHaat",
		text: "Hello. Ask ShareHaat about a lot on the board, a district, a trade, packing, road drop, or a scheme such as PMFME."
	}]);
	const prompts = [
		"Raja mircha rate today",
		"Electrician near Dimapur",
		"How do I post a deal?",
		"PM-KISAN in short"
	];
	async function send(raw) {
		const message = raw.trim();
		if (message.length < 2 || busy) return;
		const id = `m-${Date.now()}`;
		setMessages((m) => [...m, {
			id,
			from: "user",
			text: message,
			tag: ""
		}]);
		setText("");
		setBusy(true);
		const ctx = {
			listings,
			needs,
			providers
		};
		const local = advise(message, role, ctx);
		let reply = local;
		let tag = "Haat board";
		try {
			const res = await askHaat({ data: {
				role,
				message,
				board: boardBrief(ctx)
			} });
			if (res.ok && res.text) {
				reply = res.text;
				tag = "Grok";
			}
		} catch {
			reply = local;
		}
		setMessages((m) => [...m, {
			id: `${id}-a`,
			from: "bot",
			text: reply,
			tag
		}]);
		setBusy(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatShell, {
		title: "Ask ShareHaat",
		subtitle: role === "fast" ? "Short answers" : role === "deep" ? "Harvest plan" : "Market & services",
		back: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-[70dvh] flex-col px-4 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-1 rounded-xl bg-canvas p-1",
					children: [
						["market", "Market"],
						["fast", "Fast"],
						["deep", "Plan"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setRole(id),
						className: `h-9 rounded-lg text-xs font-bold ${role === id ? "bg-card text-forest shadow-card" : "text-muted"}`,
						children: label
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex-1 space-y-2",
					children: [messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `max-w-[92%] rounded-2xl px-3 py-2 text-sm leading-relaxed whitespace-pre-wrap ${m.from === "user" ? "ml-auto bg-forest text-on-forest" : "bg-card text-ink border border-line"}`,
						children: [m.tag ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mb-1 text-[10px] font-bold ${m.from === "user" ? "text-sand" : "text-haat"}`,
							children: m.tag
						}) : null, m.text]
					}, m.id)), busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Checking the board…"
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-scrollbar mt-3 flex gap-2 overflow-x-auto",
					children: prompts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void send(p),
						className: "h-8 shrink-0 rounded-full border border-line bg-card px-3 text-[11px] font-semibold text-forest",
						children: p
					}, p))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-2 flex gap-2 pb-2",
					onSubmit: (e) => {
						e.preventDefault();
						send(text);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: text,
						onChange: (e) => setText(e.target.value),
						placeholder: "Ask about a lot, a trade, a scheme…"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: busy,
						className: "h-12 shrink-0 rounded-xl bg-forest px-4 text-sm font-bold text-on-forest disabled:opacity-60",
						children: "Send"
					})]
				})
			]
		})
	});
}
//#endregion
export { TermsScreen as a, SchemesScreen as i, ChatScreen as n, ContactScreen as r, AccountScreen as t };
