import { n as ChatScreen } from "./info-kxYs0b-S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-CGuXG396.js
var SplitComponent = ChatScreen;
//#endregion
export { SplitComponent as component };
