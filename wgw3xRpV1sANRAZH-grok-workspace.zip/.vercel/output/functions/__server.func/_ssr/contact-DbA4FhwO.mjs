import { r as ContactScreen } from "./info-kxYs0b-S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-DbA4FhwO.js
var SplitComponent = ContactScreen;
//#endregion
export { SplitComponent as component };
