import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as ListingScreen } from "./market-BzzKcPZQ.mjs";
import { n as Route$2 } from "./router-DuSlLXm9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/listing._listingId-CHKTnKPJ.js
var import_jsx_runtime = require_jsx_runtime();
function ListingRoute() {
	const { listingId } = Route$2.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingScreen, { listingId });
}
//#endregion
export { ListingRoute as component };
