import { t as AccountScreen } from "./info-kxYs0b-S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-fxrUwDHj.js
var SplitComponent = AccountScreen;
//#endregion
export { SplitComponent as component };
