import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as timeLeft, M as prettyPhone, N as qtyLabel, P as rateLabel, j as placeOf } from "./data-D2z7szSz.mjs";
import { a as Star, d as MapPin, g as Clock, o as Share2 } from "../_libs/lucide-react.mjs";
import { S as useNow } from "./shell-CmuEccI4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cards-BJlnlTRd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HaatPhoto({ src, alt, className }) {
	const [ok, setOk] = (0, import_react.useState)(Boolean(src));
	if (!src || !ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `grid place-items-center bg-mint text-center text-xs font-bold text-forest ${className ?? ""}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "px-3",
			children: "Photo on the haat"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt,
		className: `object-cover ${className ?? ""}`,
		onError: () => setOk(false)
	});
}
function ListingCard({ listing, rating, onChat, onShare }) {
	const now = useNow();
	const deal = listing.listingKind === "todays_deal";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "overflow-hidden rounded-2xl bg-card shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/listing/$listingId",
			params: { listingId: listing.id },
			className: "relative block h-44",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatPhoto, {
					src: listing.photoUrl,
					alt: listing.title,
					className: "h-44 w-full"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: `absolute top-2.5 left-2.5 inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-bold text-on-forest ${deal ? "bg-deal" : "bg-forest"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }),
						deal ? "Deal" : "Member",
						" · ",
						timeLeft(listing.expiresAt, now)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-2.5 right-2.5 rounded-lg bg-scrim/75 px-2 py-1 text-[11px] font-semibold text-on-forest",
					children: listing.productCode
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 p-3.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/listing/$listingId",
					params: { listingId: listing.id },
					className: "block truncate text-base font-bold text-ink",
					children: listing.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base font-bold text-forest",
						children: rateLabel(listing.priceInr, listing.priceUnit)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: ["Avail: ", qtyLabel(listing.qty, listing.qtyUnit)]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-1 text-xs text-ink-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 shrink-0 text-ochre" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: placeOf(listing.originPlace, listing.district)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-muted",
						children: [
							"Listed by ",
							listing.sellerName,
							listing.sellerType ? ` (${listing.sellerType})` : ""
						]
					}), rating && rating.count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex shrink-0 items-center gap-0.5 rounded bg-star-bg px-1.5 py-0.5 text-[10px] font-bold text-star",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3 fill-current" }),
							rating.avg.toFixed(1),
							" (",
							rating.count,
							")"
						]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_auto] gap-2 pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onChat,
						className: "h-11 rounded-xl bg-wa text-sm font-bold text-on-forest",
						children: "Chat on WhatsApp"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onShare,
						"aria-label": "Share storefront",
						className: "grid size-11 place-items-center rounded-xl border border-line text-forest",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" })
					})]
				})
			]
		})]
	});
}
function DealStory({ listing, onOpen }) {
	const now = useNow();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: "relative aspect-story w-32 shrink-0 overflow-hidden rounded-2xl text-left shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaatPhoto, {
				src: listing.photoUrl,
				alt: listing.title,
				className: "absolute inset-0 h-full w-full"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 bg-gradient-to-b from-scrim/55 via-transparent to-scrim/80" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute top-2 left-2 grid size-7 place-items-center rounded-full border-2 border-deal bg-forest text-[11px] font-bold text-on-forest",
				children: listing.sellerName.slice(0, 1).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute top-2 right-2 rounded-md bg-deal px-1.5 py-0.5 text-[10px] font-bold text-on-forest",
				children: timeLeft(listing.expiresAt, now)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "absolute inset-x-2 bottom-2 text-on-forest",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-[11px] font-bold leading-tight",
					children: listing.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-[11px] font-semibold",
					children: rateLabel(listing.priceInr, listing.priceUnit)
				})]
			})
		]
	});
}
function NeedCard({ need, action, onAction }) {
	const donate = need.kind === "donate";
	const service = need.needCategoryType === "services";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-line bg-card p-3.5 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-bold tracking-wide text-deal",
						children: need.needCode
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-bold text-ink",
						children: need.item
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 rounded-full bg-mint px-2 py-0.5 text-[10px] font-bold text-forest",
					children: donate ? "Giveaway" : service ? need.serviceCategory || "Service" : "Looking"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-ink-soft",
				children: [
					qtyLabel(need.qty, need.qtyUnit),
					" · ",
					placeOf(need.placeName, need.district)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted",
				children: [
					need.buyerName,
					" (",
					need.buyerType,
					") · ",
					need.neededBy,
					need.budgetInr ? ` · up to ${rateLabel(need.budgetInr, need.qtyUnit)}` : " · free"
				]
			}),
			need.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 line-clamp-2 text-xs leading-relaxed text-ink-soft",
				children: need.notes
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onAction,
				className: "mt-3 h-11 w-full rounded-xl bg-forest text-sm font-bold text-on-forest",
				children: action
			})
		]
	});
}
function ProviderCard({ provider, reviews, onChat }) {
	const rated = reviews.filter((r) => r.targetId === provider.phone || r.targetId === provider.id);
	const avg = rated.length ? rated.reduce((s, r) => s + r.rating, 0) / rated.length : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-line bg-card p-3.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-bold text-ink",
					children: provider.providerName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold text-haat",
					children: [
						provider.serviceCategory,
						" · ",
						provider.experienceYears,
						" yrs"
					]
				})] }), provider.isVerified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-mint px-2 py-0.5 text-[10px] font-bold text-forest",
					children: "Verified"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-ink-soft",
				children: [
					provider.townOrVillage,
					", ",
					provider.district,
					" · ",
					provider.areaType
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs leading-relaxed text-muted",
				children: provider.description
			}),
			rated.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-star",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3 fill-current" }),
					" ",
					avg.toFixed(1),
					" (",
					rated.length,
					")"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onChat,
				className: "mt-3 h-11 w-full rounded-xl bg-wa text-sm font-bold text-on-forest",
				children: ["WhatsApp ", prettyPhone(provider.phone)]
			})
		]
	});
}
function SectionTitle({ title, hint, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-bold text-ink",
			children: title
		}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: hint
		}) : null] }), action]
	});
}
function EmptyNote({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border border-line bg-card px-4 py-6 text-center text-sm text-muted",
		children
	});
}
//#endregion
export { NeedCard as a, ListingCard as i, EmptyNote as n, ProviderCard as o, HaatPhoto as r, SectionTitle as s, DealStory as t };
