import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-D2z7szSz.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-IWHfIGH2.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-rOiX3EQj.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var APP_BLURB = "ShareHaat is the local haat for Nagaland. Photograph it, update your storefront, and share. A buyer taps Chat with the Seller on WhatsApp. Price, qty, pickup, and pay happen there. ShareHaat never takes money for goods.";
var OPERATOR_NAME = "Tribal Harvest Marketing Cooperative Society Ltd.";
var OPERATOR_WHATSAPP = "7005653988";
var LEGAL_NOTICE = "ShareHaat never takes money for goods. WhatsApp is the chat. ShareHaat is the board. UPI or cash is payment. Pickup is fulfilment.";
var FSSAI_DUTY = "ShareHaat only lists. Sellers are responsible for their own FSSAI if they sell processed or packed food.";
var PROHIBITED_NOTICE = "Illegal goods and services are strictly prohibited on ShareHaat. Listings must comply with applicable laws.";
var DISTRICTS = [
	"Dimapur",
	"Kohima",
	"Chümoukedima",
	"Wokha",
	"Zunheboto",
	"Mokokchung",
	"Mon",
	"Phek",
	"Peren",
	"Kiphire",
	"Tuensang",
	"Longleng",
	"Noklak",
	"Tseminyu",
	"Niuland",
	"Shamator"
];
var CATEGORIES = [
	{
		key: "all",
		label: "All Produce",
		short: "All"
	},
	{
		key: "vegetables",
		label: "Vegetables",
		short: "Veg"
	},
	{
		key: "fruits",
		label: "Fruits",
		short: "Fruits"
	},
	{
		key: "grains",
		label: "Grains & Pulses",
		short: "Grains"
	},
	{
		key: "spices",
		label: "Spices & Chillies",
		short: "Spices"
	},
	{
		key: "honey",
		label: "Forest Honey",
		short: "Honey"
	},
	{
		key: "livestock",
		label: "Livestock & Fish",
		short: "Livestock"
	},
	{
		key: "craft",
		label: "Handloom & Crafts",
		short: "Crafts"
	},
	{
		key: "food",
		label: "Traditional Food",
		short: "Food"
	}
];
var SELL_CATEGORIES = [
	{
		key: "vegetables",
		label: "Vegetables"
	},
	{
		key: "fruits",
		label: "Fruits"
	},
	{
		key: "grains",
		label: "Grains & Pulses"
	},
	{
		key: "spices",
		label: "Spices & Chillies"
	},
	{
		key: "honey",
		label: "Forest Honey"
	},
	{
		key: "livestock",
		label: "Livestock & Fish"
	},
	{
		key: "craft",
		label: "Handloom & Crafts"
	},
	{
		key: "food",
		label: "Traditional Food"
	},
	{
		key: "attire",
		label: "Attire & Weaving"
	}
];
var PRICE_UNITS = [
	"kg",
	"gm",
	"liter",
	"ml",
	"piece",
	"pack",
	"bunch",
	"bag",
	"dozen",
	"lot",
	"jar"
];
var SELLER_TYPES = [
	"Farmer",
	"Society",
	"FPO",
	"SHG",
	"Artisan",
	"Vendor",
	"Household",
	"Owner"
];
var HANDOVER_OPTIONS = [
	"Station pickup",
	"Home delivery",
	"Pickup point",
	"Pickup at farm"
];
var LISTING_SPANS = [
	{
		hours: 24,
		label: "24 hrs"
	},
	{
		hours: 36,
		label: "36 hours"
	},
	{
		hours: 72,
		label: "72 hours"
	},
	{
		hours: 168,
		label: "7 days"
	},
	{
		hours: 288,
		label: "12 days"
	},
	{
		hours: 360,
		label: "15 days"
	}
];
var SERVICE_TRADES = [
	"Electrician",
	"Plumber",
	"Mechanic",
	"Carpenter",
	"Mason",
	"Welder"
];
var AREA_TYPES = [
	{
		key: "village",
		label: "Village"
	},
	{
		key: "rural",
		label: "Rural"
	},
	{
		key: "town",
		label: "Town"
	},
	{
		key: "all",
		label: "All areas"
	}
];
var BUYER_TYPES = [
	"Shop",
	"Hotel",
	"Home",
	"Household",
	"Farmer",
	"Grower",
	"Cooperative Member"
];
var emptyProfile = {
	name: "",
	phone: "",
	sellerType: "Farmer",
	district: "Dimapur",
	place: "",
	isServiceProvider: false,
	serviceCategory: ""
};
var h = (hours) => hours * 3600 * 1e3;
var d = (days) => days * 86400 * 1e3;
function buildSeed(now = Date.now()) {
	const listings = [
		{
			id: "list-chilli-1",
			productCode: "SH-CHILLI-014",
			userId: "9862001122",
			category: "spices",
			listingKind: "todays_deal",
			status: "active",
			title: "Fresh Naga King Chilli (Raja Mircha)",
			photoUrl: "https://images.unsplash.com/photo-1588252303782-cb80119abd6d?auto=format&fit=crop&w=900&q=80",
			district: "Mokokchung",
			originPlace: "Longkhum village",
			sellerName: "Along Jamir",
			sellerPhone: "9862001122",
			sellerType: "Farmer",
			priceInr: 350,
			priceUnit: "kg",
			qty: 50,
			qtyUnit: "kg",
			handover: "Station pickup",
			landmark: "Mokokchung NST Station",
			notes: "Freshly harvested organic hill King Chilli. Extra fiery, sorted and packed in bamboo baskets.",
			createdAt: now - h(2),
			expiresAt: now + h(34),
			featured: true
		},
		{
			id: "list-axone-2",
			productCode: "SH-AXONE-002",
			userId: "9436003344",
			category: "food",
			listingKind: "shop_item",
			status: "active",
			title: "Organic Hill Axone (Fermented Soybean)",
			photoUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=900&q=80",
			district: "Wokha",
			originPlace: "Longsa village",
			sellerName: "Zuchobeni Lotha",
			sellerPhone: "9436003344",
			sellerType: "SHG",
			priceInr: 200,
			priceUnit: "kg",
			qty: 25,
			qtyUnit: "kg",
			handover: "Home delivery",
			landmark: "Wokha town bazaar",
			notes: "Traditional smoked axone cakes wrapped in banana leaf. Intense natural aroma for authentic curry.",
			createdAt: now - h(6),
			expiresAt: now + h(160),
			featured: true
		},
		{
			id: "list-mekhala-3",
			productCode: "SH-MEKHALA-008",
			userId: "9856005566",
			category: "attire",
			listingKind: "shop_item",
			status: "active",
			title: "Handwoven Ao Naga Mekhala & Shawl Set",
			photoUrl: "https://images.unsplash.com/photo-1607344645866-009c320c5ab8?auto=format&fit=crop&w=900&q=80",
			district: "Mokokchung",
			originPlace: "Ungma village",
			sellerName: "Chubala Lemtur",
			sellerPhone: "9856005566",
			sellerType: "Artisan",
			priceInr: 2800,
			priceUnit: "piece",
			qty: 4,
			qtyUnit: "piece",
			handover: "Pickup point",
			landmark: "Near Ungma Town Hall",
			notes: "Traditional loin loom handwoven design. Vibrant natural cotton dyes, premium ceremony wear.",
			createdAt: now - h(12),
			expiresAt: now + h(220),
			featured: false
		},
		{
			id: "list-rice-4",
			productCode: "SH-RICE-021",
			userId: "9612007788",
			category: "grains",
			listingKind: "todays_deal",
			status: "active",
			title: "Fresh Sticky Red Rice (Phek Terrace Harvest)",
			photoUrl: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=900&q=80",
			district: "Phek",
			originPlace: "Zhavame village",
			sellerName: "Veprasu Keyho",
			sellerPhone: "9612007788",
			sellerType: "Farmer",
			priceInr: 95,
			priceUnit: "kg",
			qty: 150,
			qtyUnit: "kg",
			handover: "Station pickup",
			landmark: "Kohima ISBT drop",
			notes: "High-altitude organic terrace red rice. Highly aromatic and nutritious staple.",
			createdAt: now - h(4),
			expiresAt: now + h(68),
			featured: true
		},
		{
			id: "list-basket-5",
			productCode: "SH-BASKET-011",
			userId: "9402008899",
			category: "craft",
			listingKind: "shop_item",
			status: "active",
			title: "Handcrafted Bamboo Storage Baskets",
			photoUrl: "https://images.unsplash.com/photo-1590402494682-cd3fb53b1f70?auto=format&fit=crop&w=900&q=80",
			district: "Mon",
			originPlace: "Mon town",
			sellerName: "Nyei Konyak",
			sellerPhone: "9402008899",
			sellerType: "Artisan",
			priceInr: 650,
			priceUnit: "piece",
			qty: 10,
			qtyUnit: "piece",
			handover: "Station pickup",
			landmark: "Mon Bazaar junction",
			notes: "Finely woven mountain cane and bamboo crafts. Heavy duty, smoke treated for long life.",
			createdAt: now - d(1),
			expiresAt: now + h(210),
			featured: false
		},
		{
			id: "list-honey-6",
			productCode: "SH-HONEY-003",
			userId: "9863001234",
			category: "honey",
			listingKind: "shop_item",
			status: "active",
			title: "Raw Wild Hill Honey (Unfiltered)",
			photoUrl: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=900&q=80",
			district: "Kohima",
			originPlace: "Khonoma village",
			sellerName: "Neikhrietuolie",
			sellerPhone: "9863001234",
			sellerType: "Household",
			priceInr: 450,
			priceUnit: "jar",
			qty: 20,
			qtyUnit: "jar",
			handover: "Pickup point",
			landmark: "Kohima High School junction",
			notes: "Collected from Khonoma forests. 500g glass jar, unfiltered, with natural pollen.",
			createdAt: now - h(18),
			expiresAt: now + h(180),
			featured: true
		},
		{
			id: "list-bazaar-7",
			productCode: "SH-SMOKED-019",
			userId: "9774005678",
			category: "food",
			listingKind: "shop_item",
			status: "active",
			title: "Smoked Pork with Dry Bamboo Shoots",
			photoUrl: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=900&q=80",
			district: "Dimapur",
			originPlace: "Super Market",
			sellerName: "Sentila Ao",
			sellerPhone: "9774005678",
			sellerType: "Vendor",
			priceInr: 420,
			priceUnit: "kg",
			qty: 30,
			qtyUnit: "kg",
			handover: "Pickup point",
			landmark: "Dimapur Super Market Stall #14",
			notes: "Wood smoke cured local pork with hill tender bamboo shoots.",
			createdAt: now - h(8),
			expiresAt: now + h(150),
			featured: false
		},
		{
			id: "list-pot-755",
			productCode: "SH-POT-755",
			userId: "9862551755",
			category: "craft",
			listingKind: "shop_item",
			status: "active",
			title: "Traditional Naga Clay Cooking Pots",
			photoUrl: "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=900&q=80",
			district: "Dimapur",
			originPlace: "Ward No. 6",
			sellerName: "Kezha Terhuja",
			sellerPhone: "9862551755",
			sellerType: "Artisan",
			priceInr: 200,
			priceUnit: "piece",
			qty: 40,
			qtyUnit: "piece",
			handover: "Pickup point",
			landmark: "Ward No. 6 Market, Dimapur",
			notes: "Handcrafted clay and terracotta pots. Excellent for natural water cooling and cooking.",
			createdAt: now - h(1),
			expiresAt: now + h(120),
			featured: true
		},
		{
			id: "list-pineapple-9",
			productCode: "SH-PINE-009",
			userId: "9436117788",
			category: "fruits",
			listingKind: "shop_item",
			status: "active",
			title: "Sweet Molvom Pineapple",
			photoUrl: "https://images.unsplash.com/photo-1550258987-190a2d41a8ba?auto=format&fit=crop&w=900&q=80",
			district: "Chümoukedima",
			originPlace: "Molvom",
			sellerName: "Akumla Jamir",
			sellerPhone: "9436117788",
			sellerType: "Farmer",
			priceInr: 40,
			priceUnit: "piece",
			qty: 80,
			qtyUnit: "piece",
			handover: "Station pickup",
			landmark: "Chümoukedima junction",
			notes: "Ripe field pineapple, cut the morning of pickup. Best eaten within two days.",
			createdAt: now - h(9),
			expiresAt: now + d(7),
			featured: false
		},
		{
			id: "list-cabbage-10",
			productCode: "SH-CABB-010",
			userId: "9862440099",
			category: "vegetables",
			listingKind: "todays_deal",
			status: "active",
			title: "Hill Cabbage, Morning Cut",
			photoUrl: "https://images.unsplash.com/photo-1594282486552-05b4d80fbb9f?auto=format&fit=crop&w=900&q=80",
			district: "Kohima",
			originPlace: "Jakhama",
			sellerName: "Kevichütuo",
			sellerPhone: "9862440099",
			sellerType: "Farmer",
			priceInr: 25,
			priceUnit: "kg",
			qty: 120,
			qtyUnit: "kg",
			handover: "Station pickup",
			landmark: "Kohima NST",
			notes: "Cool-night cabbage, unwashed, packed in jute sacks. Deal lot for shops.",
			createdAt: now - h(3),
			expiresAt: now + h(21),
			featured: true
		}
	];
	const needs = [
		{
			id: "need-ginger-1",
			needCode: "ND-GINGER-001",
			kind: "looking",
			item: "Organic Hill Ginger (Fresh)",
			qty: 500,
			qtyUnit: "kg",
			district: "Dimapur",
			placeName: "Dimapur New Market",
			neededBy: "Within this week",
			budgetInr: 45,
			buyerType: "Shop",
			buyerName: "Imtitemjen",
			buyerPhone: "9436123456",
			notes: "Looking for fresh unwashed hill ginger lots. Can pick up at Dimapur station or yard.",
			status: "open",
			createdAt: now - h(5),
			photoUrl: "",
			needCategoryType: "goods",
			serviceCategory: "",
			areaType: "town"
		},
		{
			id: "need-table-2",
			needCode: "ND-WOOD-004",
			kind: "looking",
			item: "Traditional Naga Wood Carved Table",
			qty: 2,
			qtyUnit: "piece",
			district: "Kohima",
			placeName: "Kohima BOC",
			neededBy: "By end of month",
			budgetInr: 9e3,
			buyerType: "Hotel",
			buyerName: "Kezhavituo",
			buyerPhone: "9862345678",
			notes: "Solid wood ethnic table with mithun or tribal pattern carving for a restaurant foyer.",
			status: "open",
			createdAt: now - h(15),
			photoUrl: "",
			needCategoryType: "goods",
			serviceCategory: "",
			areaType: "town"
		},
		{
			id: "need-donate-1",
			needCode: "DN-BOOKS-002",
			kind: "donate",
			item: "Children Story Books & School Bags",
			qty: 1,
			qtyUnit: "lot",
			district: "Dimapur",
			placeName: "Diphupar",
			neededBy: "Any daylight hour",
			budgetInr: 0,
			buyerType: "Home",
			buyerName: "Aienla",
			buyerPhone: "9774123890",
			notes: "Gently used illustrated children books and sturdy school bags. Free for any village school.",
			status: "open",
			createdAt: now - h(20),
			photoUrl: "",
			needCategoryType: "goods",
			serviceCategory: "",
			areaType: "town"
		},
		{
			id: "need-donate-2",
			needCode: "DN-SEEDS-005",
			kind: "donate",
			item: "Organic Squash & King Chilli Seeds",
			qty: 25,
			qtyUnit: "pack",
			district: "Chümoukedima",
			placeName: "Medziphema",
			neededBy: "Immediate",
			budgetInr: 0,
			buyerType: "Household",
			buyerName: "Rovikotuo",
			buyerPhone: "9612987654",
			notes: "Sun-dried heirloom seeds from last harvest. Free for a community vegetable garden.",
			status: "open",
			createdAt: now - h(28),
			photoUrl: "",
			needCategoryType: "goods",
			serviceCategory: "",
			areaType: "village"
		},
		{
			id: "need-service-1",
			needCode: "SR-ELEC-007",
			kind: "looking",
			item: "Farm Solar & Inverter Wiring Repair",
			qty: 1,
			qtyUnit: "job",
			district: "Dimapur",
			placeName: "Padumpukhuri Village",
			neededBy: "Within 2 days",
			budgetInr: 1200,
			buyerType: "Farmer",
			buyerName: "Tiatemsu",
			buyerPhone: "9436001234",
			notes: "Need an electrician to inspect a 3kVA solar inverter and battery wiring at a poultry shed.",
			status: "open",
			createdAt: now - h(2),
			photoUrl: "",
			needCategoryType: "services",
			serviceCategory: "Electrician",
			areaType: "village"
		},
		{
			id: "need-service-2",
			needCode: "SR-MECH-012",
			kind: "looking",
			item: "Power Tiller Engine Overhaul",
			qty: 1,
			qtyUnit: "machine",
			district: "Kohima",
			placeName: "Meriema Village",
			neededBy: "Immediate",
			budgetInr: 2500,
			buyerType: "Grower",
			buyerName: "Vilie Kire",
			buyerPhone: "9862112233",
			notes: "Kubota power tiller not starting before terracing season. Mechanic needed with spares on-site.",
			status: "open",
			createdAt: now - h(7),
			photoUrl: "",
			needCategoryType: "services",
			serviceCategory: "Mechanic",
			areaType: "rural"
		},
		{
			id: "need-service-3",
			needCode: "SR-PLUMB-019",
			kind: "looking",
			item: "Polyhouse Drip Line & Tank Fitting",
			qty: 1,
			qtyUnit: "installation",
			district: "Mokokchung",
			placeName: "Ungma Village",
			neededBy: "This weekend",
			budgetInr: 3e3,
			buyerType: "Cooperative Member",
			buyerName: "Bendang Jamir",
			buyerPhone: "9774334455",
			notes: "Connecting a 1000L tank to a 2-inch PVC mainline for a tomato greenhouse.",
			status: "open",
			createdAt: now - h(14),
			photoUrl: "",
			needCategoryType: "services",
			serviceCategory: "Plumber",
			areaType: "village"
		}
	];
	const providers = [
		{
			id: "prov-elec-1",
			providerName: "Longkumer Electricals (Bendang)",
			phone: "9862110022",
			serviceCategory: "Electrician",
			areaType: "all",
			district: "Dimapur",
			townOrVillage: "Purana Bazaar",
			experienceYears: 8,
			description: "Domestic, commercial, cold storage and agricultural solar inverter work across village and town.",
			isVerified: true,
			registeredAt: now - d(40)
		},
		{
			id: "prov-plumb-2",
			providerName: "Neizo Angami Plumbing Solutions",
			phone: "9436129988",
			serviceCategory: "Plumber",
			areaType: "town",
			district: "Kohima",
			townOrVillage: "High School Colony",
			experienceYears: 6,
			description: "Borewell pumps, polyhouse drip lines, fixtures, drainage and rainwater harvesting.",
			isVerified: true,
			registeredAt: now - d(20)
		},
		{
			id: "prov-mech-3",
			providerName: "Lotha Agro Machinery & Motors",
			phone: "9612003344",
			serviceCategory: "Mechanic",
			areaType: "rural",
			district: "Wokha",
			townOrVillage: "Wokha Village",
			experienceYears: 10,
			description: "Power tillers, mini tractors, diesel pumps, chainsaws and brush cutters.",
			isVerified: true,
			registeredAt: now - d(12)
		}
	];
	const reviews = [
		{
			id: "rev-along-1",
			targetId: "9862001122",
			targetType: "seller",
			targetName: "Along Jamir",
			reviewerName: "Sentila Longchar",
			reviewerPhone: "9436112233",
			rating: 5,
			comment: "Super fresh and fiery raja mircha. Arrived safely at NST, packed in bamboo lots.",
			createdAt: now - d(1)
		},
		{
			id: "rev-along-2",
			targetId: "9862001122",
			targetType: "seller",
			targetName: "Along Jamir",
			reviewerName: "Temjen Ao",
			reviewerPhone: "9862334411",
			rating: 5,
			comment: "Honest farmer. Weight was exact and the chillies had no spoilage.",
			createdAt: now - d(3)
		},
		{
			id: "rev-zucho-1",
			targetId: "9436003344",
			targetType: "seller",
			targetName: "Zuchobeni Lotha",
			reviewerName: "Renbon Lotha",
			reviewerPhone: "9436887766",
			rating: 5,
			comment: "Authentic smoked axone from Longsa. Deep aroma, perfect for pork curry.",
			createdAt: now - d(2)
		},
		{
			id: "rev-veprasu-1",
			targetId: "9612007788",
			targetType: "seller",
			targetName: "Veprasu Keyho",
			reviewerName: "Keviletuo Angami",
			reviewerPhone: "9856332211",
			rating: 5,
			comment: "Organic Phek sticky red rice. Clean, fragrant, and a wholesome staple.",
			createdAt: now - d(4)
		},
		{
			id: "rev-neikh-1",
			targetId: "9863001234",
			targetType: "seller",
			targetName: "Neikhrietuolie",
			reviewerName: "Imliwati Jamir",
			reviewerPhone: "9402554433",
			rating: 5,
			comment: "Pure wild forest honey from Khonoma. Thick and raw.",
			createdAt: now - d(5)
		},
		{
			id: "rev-prov-elec-1",
			targetId: "9862110022",
			targetType: "service_provider",
			targetName: "Longkumer Electricals (Bendang)",
			reviewerName: "Tiatemsu",
			reviewerPhone: "9436001234",
			rating: 5,
			comment: "Repaired the poultry-shed solar inverter promptly. Clear about the wiring.",
			createdAt: now - d(1)
		},
		{
			id: "rev-prov-plumb-1",
			targetId: "9436129988",
			targetType: "service_provider",
			targetName: "Neizo Angami Plumbing Solutions",
			reviewerName: "Bendang Jamir",
			reviewerPhone: "9774334455",
			rating: 5,
			comment: "Fitted the polyhouse drip mainline and tank connections. No leaks.",
			createdAt: now - d(2)
		}
	];
	return {
		listings: listings.map((item) => ({
			...item,
			userId: "seed"
		})),
		needs: needs.map((item) => ({
			...item,
			userId: "seed"
		})),
		providers: providers.map((item) => ({
			...item,
			userId: "seed"
		})),
		reviews: reviews.map((item) => ({
			...item,
			userId: "seed"
		}))
	};
}
var SCHEMES = [
	{
		id: "pm-kisan",
		name: "PM-KISAN",
		summary: "Income support of Rs 6,000 a year to eligible landholding farm families, in three equal instalments. eKYC is required.",
		who: "Farmers",
		href: "https://pmkisan.gov.in/"
	},
	{
		id: "pmfme",
		name: "PMFME Nagaland",
		summary: "Help for micro food processors: seed capital, credit-linked subsidies, training, and branding. Nagaland runs a dedicated state PMFME desk.",
		who: "SHGs, micro food processors",
		href: "https://pmfme.mofpi.gov.in/",
		extraHref: "https://pmfme.nagaland.gov.in/",
		extraLabel: "Nagaland PMFME Portal"
	},
	{
		id: "midh",
		name: "MIDH",
		summary: "Planting material, nurseries, cold storage, and post-harvest support for spices, fruits and vegetables in hill states.",
		who: "Horticulture growers",
		href: "https://midh.gov.in/"
	},
	{
		id: "movcd-ner",
		name: "MOVCD-NER",
		summary: "Mission Organic Value Chain Development for the North Eastern Region. FPOs, organic inputs, certification, and market links.",
		who: "Organic growers, FPOs",
		href: "https://nmsa.dac.gov.in/"
	},
	{
		id: "fpo-10000",
		name: "10,000 FPOs Scheme",
		summary: "Central scheme to form Farmer Producer Organisations, with management cost, equity grant, and credit guarantee.",
		who: "Farmers, FPO cooperatives",
		href: "https://www.sfacindia.com/"
	},
	{
		id: "aif",
		name: "Agriculture Infrastructure Fund",
		summary: "Financing for post-harvest infrastructure and community farming assets. Can converge with MIDH and PMFME.",
		who: "FPOs, societies, agri-entrepreneurs",
		href: "https://agriinfra.dac.gov.in/"
	},
	{
		id: "nsrlm",
		name: "NSRLM / SHG Support",
		summary: "Self-help group formation, revolving fund, community investment fund, and livelihood training for rural women.",
		who: "SHGs, rural women",
		href: "https://nrlm.gov.in/"
	}
];
function digits(raw) {
	return raw.replace(/\D/g, "");
}
function normalizePhone(raw) {
	const dgt = digits(raw);
	if (dgt.length === 10) return `91${dgt}`;
	if (dgt.length === 12 && dgt.startsWith("91")) return dgt;
	if (dgt.startsWith("0") && dgt.length === 11) return `91${dgt.slice(1)}`;
	return dgt;
}
function prettyPhone(phone) {
	const clean = digits(phone);
	const local = clean.length === 12 && clean.startsWith("91") ? clean.slice(2) : clean;
	if (local.length === 10) return `${local.slice(0, 5)} ${local.slice(5)}`;
	return phone;
}
function samePhone(a, b) {
	const da = digits(a);
	const db = digits(b);
	if (!da || !db) return false;
	return da.endsWith(db) || db.endsWith(da);
}
function inr(amount) {
	return `₹${Math.round(amount).toLocaleString("en-IN")}`;
}
function rateLabel(price, unit) {
	if (!price) return "Rate on chat";
	return `${inr(price)}${unit ? `/${unit}` : ""}`;
}
function qtyLabel(qty, unit) {
	return `${Number.isInteger(qty) ? qty : qty} ${unit}`.trim();
}
function timeLeft(expiresAt, now) {
	const diff = expiresAt - now;
	if (diff <= 0) return "Expired";
	const hours = Math.floor(diff / 36e5);
	if (hours < 48) return `${Math.max(hours, 1)}h left`;
	return `${Math.floor(hours / 24)}d left`;
}
function placeOf(origin, district) {
	return [origin, district].filter(Boolean).join(", ");
}
function matchesCategory(listing, key) {
	if (key === "all") return true;
	const blob = `${listing.category} ${listing.title} ${listing.notes}`.toLowerCase();
	const table = {
		vegetables: [
			"vegetable",
			"cabbage",
			"leaf",
			"bamboo shoot"
		],
		fruits: [
			"fruit",
			"pineapple",
			"banana",
			"orange",
			"apple",
			"passion"
		],
		grains: [
			"grain",
			"rice",
			"millet",
			"pulse",
			"dal",
			"soy"
		],
		spices: [
			"spice",
			"chilli",
			"chili",
			"ginger",
			"garlic",
			"turmeric",
			"mircha"
		],
		honey: ["honey", "bee"],
		livestock: [
			"livestock",
			"chicken",
			"fish",
			"duck",
			"pork",
			"egg",
			"pig"
		],
		craft: [
			"craft",
			"shawl",
			"mekhala",
			"basket",
			"wood",
			"pot",
			"loom",
			"bamboo"
		],
		food: [
			"food",
			"axone",
			"pickle",
			"smoked",
			"fermented"
		],
		attire: [
			"attire",
			"mekhala",
			"shawl",
			"weave"
		]
	};
	if (listing.category === key) return true;
	return (table[key] ?? [key]).some((word) => blob.includes(word));
}
function waLink(phone, message) {
	return `https://wa.me/${normalizePhone(phone)}?text=${encodeURIComponent(message)}`;
}
function buyerMessage(listing, origin = "") {
	const where = placeOf(listing.originPlace, listing.district);
	const url = origin ? `${origin}/listing/${listing.id}` : `/listing/${listing.id}`;
	return `Hello from ShareHaat. I want ${listing.title}, ${qtyLabel(listing.qty, listing.qtyUnit)}, ${rateLabel(listing.priceInr, listing.priceUnit)}. Product ID: ${listing.productCode}.${where ? ` Location: ${where}.` : ""} View listing: ${url}`;
}
function shareText(listing, origin = "", photoUrl = "") {
	const where = placeOf(listing.originPlace, listing.district);
	const url = origin ? `${origin}/listing/${listing.id}` : `/listing/${listing.id}`;
	const lines = [
		"ShareHaat Storefront",
		"",
		listing.title,
		"",
		`Product ID: ${listing.productCode}`,
		`Price: ${rateLabel(listing.priceInr, listing.priceUnit)}`,
		`Available: ${qtyLabel(listing.qty, listing.qtyUnit)}`
	];
	if (where) lines.push(`Location: ${where}`);
	if (listing.handover) lines.push(`Handover: ${listing.handover}`);
	lines.push("", "View this ShareHaat listing:", url, "", "ShareHaat — Photograph it. Share it. Sell it on WhatsApp.");
	if (photoUrl) lines.push("", photoUrl);
	return lines.join("\n");
}
function needSupplyMessage(need) {
	const where = placeOf(need.placeName, need.district);
	return `Hello, Need ID ${need.needCode}. I can supply your ${need.item} in ${where}, needed ${need.neededBy} on ShareHaat. I have it. Let's talk.`;
}
function donateMessage(need) {
	const where = placeOf(need.placeName, need.district);
	return `Hello, Donate ID ${need.needCode}. I saw your giveaway (${need.item}) in ${where} on ShareHaat. I can collect. Let's talk.`;
}
function serviceReply(need, providerName, trade) {
	const where = placeOf(need.placeName, need.district);
	return `Hello, Service Req ID ${need.needCode}. I am ${providerName || "a ShareHaat provider"}, a ${trade || need.serviceCategory} on ShareHaat. I saw your request for '${need.item}' in ${where}. I am available. Let's discuss timing.`;
}
function contactMessage(input) {
	if (input.voice) return `Hello ShareHaat. I will send a voice note.\n\nSeller's Name: ${input.sellerName}\nItems Name: ${input.itemName}\nMobile Number: ${input.mobile}`;
	return `Hello ShareHaat,\n\nSeller's Name: ${input.sellerName}\nItems Name: ${input.itemName}\nPer Price: ${input.rate}\nQuantity available: ${input.qty}\nMobile Number: ${input.mobile}\n\nI am sending the item photo in this chat.`;
}
function consignmentMessage(listing, buyerPlace, preference) {
	return `Ask ShareHaat to arrange this consignment.\n\nLot: ${listing.title}\nQty: ${qtyLabel(listing.qty, listing.qtyUnit)}\nVillage: ${placeOf(listing.originPlace, listing.district)}\nSeller handover: ${listing.handover}\nLandmark: ${listing.landmark}\nBuyer place: ${buyerPlace}\nBuyer wants: ${preference}\n\nPlease confirm the seller still has the lot, then book existing road transport. Do not move a vehicle until both sides confirm. Goods money stays seller to buyer.`;
}
function ratingFor(reviews, ids) {
	const set = new Set(ids.filter(Boolean));
	const items = reviews.filter((r) => set.has(r.targetId)).sort((a, b) => b.createdAt - a.createdAt);
	if (!items.length) return {
		avg: 0,
		count: 0,
		items
	};
	return {
		avg: items.reduce((sum, r) => sum + r.rating, 0) / items.length,
		count: items.length,
		items
	};
}
function readPhoto(file) {
	const url = URL.createObjectURL(file);
	return import("./photo-z9DeWH38.mjs").then((n) => n.a).then((n) => n.a).then(({ fitPhotoUnder300kb }) => fitPhotoUnder300kb(url)).then((fitted) => fitted.dataUrl).finally(() => URL.revokeObjectURL(url));
}
function nextCode(prefix) {
	return `${prefix}-${Math.floor(100 + Math.random() * 900)}`;
}
function advise(query, role, ctx, now = Date.now()) {
	const q = query.toLowerCase();
	const live = ctx.listings.filter((l) => l.status === "active" && l.expiresAt > now);
	const openNeeds = ctx.needs.filter((n) => n.status === "open");
	const words = q.split(/[^a-z0-9ü]+/).filter((w) => w.length > 2);
	const listingHits = live.filter((l) => {
		const blob = `${l.title} ${l.district} ${l.originPlace} ${l.category} ${l.sellerName} ${l.notes}`.toLowerCase();
		return words.some((w) => blob.includes(w));
	});
	const schemeHits = SCHEMES.filter((s) => {
		const blob = `${s.name} ${s.summary} ${s.who}`.toLowerCase();
		return words.some((w) => blob.includes(w)) || q.includes(s.name.toLowerCase().slice(0, 6));
	});
	const providerHits = ctx.providers.filter((p) => {
		const blob = `${p.providerName} ${p.serviceCategory} ${p.district} ${p.description}`.toLowerCase();
		return words.some((w) => blob.includes(w));
	});
	const lines = [];
	if (/(how|sell|list|post|whatsapp|storefront)/.test(q) && listingHits.length === 0) {
		lines.push("To list: open Sell, take a photo or pick one from your gallery, then add the name, rate, quantity and village. The lot can stay up 24 hrs, 36 hours, 72 hours, or 7, 12 or 15 days. It goes on the community board for everyone.");
		lines.push("ShareHaat does not take the money. The buyer chats you on WhatsApp. UPI or cash is between you.");
	}
	if (listingHits.length) {
		lines.push(role === "fast" ? "On the board now:" : "Matching lots on the ShareHaat board:");
		listingHits.slice(0, role === "fast" ? 3 : 5).forEach((l) => {
			lines.push(`• ${l.title} — ${rateLabel(l.priceInr, l.priceUnit)}, ${qtyLabel(l.qty, l.qtyUnit)}, ${placeOf(l.originPlace, l.district)} (${l.sellerName}).`);
		});
	}
	if (providerHits.length || /electric|plumb|mechanic|solar|tiller|repair/.test(q)) {
		const pool = providerHits.length ? providerHits : ctx.providers;
		lines.push("Service providers on the free list:");
		pool.slice(0, 3).forEach((p) => {
			lines.push(`• ${p.providerName}, ${p.serviceCategory}, ${p.townOrVillage}, ${p.district}. ${p.experienceYears} years. WhatsApp ${prettyPhone(p.phone)}.`);
		});
	}
	const needHits = openNeeds.filter((n) => {
		const blob = `${n.item} ${n.district} ${n.serviceCategory} ${n.notes}`.toLowerCase();
		return words.some((w) => blob.includes(w));
	});
	if (needHits.length) {
		lines.push("Buyers and households asking:");
		needHits.slice(0, 3).forEach((n) => {
			const budget = n.budgetInr ? ` around ${inr(n.budgetInr)}` : "";
			lines.push(`• ${n.item} in ${placeOf(n.placeName, n.district)}${budget}. ${n.neededBy}.`);
		});
	}
	if (schemeHits.length || /scheme|subsidy|pm-kisan|pmfme|fpo|organic/.test(q)) {
		const pool = schemeHits.length ? schemeHits : SCHEMES.slice(0, role === "deep" ? 4 : 2);
		lines.push("Schemes worth opening (apply on the official site, not inside ShareHaat):");
		pool.forEach((s) => lines.push(`• ${s.name} — ${s.who}. ${s.summary}`));
	}
	if (/transport|sumo|nst|consign|truck|dimapur/.test(q)) lines.push("For a full lot, message the cooperative on WhatsApp and ask them to book an existing Sumo, NST drop, or hired truck. Confirm kilos with the seller before a vehicle moves. ShareHaat does not guarantee weight or that perishables will not spoil.");
	if (!lines.length) {
		const deals = live.filter((l) => l.listingKind === "todays_deal").length;
		lines.push(`The board has ${live.length} live lots (${deals} timed deals) and ${openNeeds.length} open needs across Nagaland.`);
		lines.push("Ask for a crop (king chilli, axone, red rice, honey), a district, a trade (electrician, plumber, mechanic), or a scheme such as PMFME or PM-KISAN.");
	}
	if (role === "deep") lines.push("Fair rates move with the week and the road. Use the listed rate as a starting chat, not a government price. Packed food still needs the seller’s own FSSAI where the law asks for it.");
	return lines.join("\n");
}
function boardBrief(ctx, now = Date.now()) {
	return [
		...ctx.listings.filter((l) => l.status === "active" && l.expiresAt > now).slice(0, 12).map((l) => `${l.title} | ${rateLabel(l.priceInr, l.priceUnit)} | ${qtyLabel(l.qty, l.qtyUnit)} | ${l.district} | ${l.sellerName} | ${l.listingKind}`),
		...ctx.needs.filter((n) => n.status === "open").slice(0, 8).map((n) => `NEED ${n.item} | ${n.district} | ${n.neededBy} | budget ${n.budgetInr || "free"}`),
		...ctx.providers.slice(0, 6).map((p) => `PROVIDER ${p.providerName} | ${p.serviceCategory} | ${p.district} | ${prettyPhone(p.phone)}`)
	].join("\n").slice(0, 2200);
}
//#endregion
export { nextCode as A, timeLeft as B, consignmentMessage as C, emptyProfile as D, donateMessage as E, ratingFor as F, readPhoto as I, samePhone as L, prettyPhone as M, qtyLabel as N, matchesCategory as O, rateLabel as P, serviceReply as R, buyerMessage as S, digits as T, waLink as V, SERVICE_TRADES as _, DISTRICTS as a, boardBrief as b, LEGAL_NOTICE as c, OPERATOR_WHATSAPP as d, PRICE_UNITS as f, SELL_CATEGORIES as g, SELLER_TYPES as h, CATEGORIES as i, placeOf as j, needSupplyMessage as k, LISTING_SPANS as l, SCHEMES as m, AREA_TYPES as n, FSSAI_DUTY as o, PROHIBITED_NOTICE as p, BUYER_TYPES as r, HANDOVER_OPTIONS as s, APP_BLURB as t, OPERATOR_NAME as u, advise as v, contactMessage as w, buildSeed as x, authMiddleware as y, shareText as z };
