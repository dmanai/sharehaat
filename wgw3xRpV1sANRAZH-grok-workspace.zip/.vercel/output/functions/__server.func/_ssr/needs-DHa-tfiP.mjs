import { C as require_jsx_runtime, b as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as NeedsScreen } from "./community-DKChWjsZ.mjs";
import { a as Route$8 } from "./router-DuSlLXm9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/needs-DHa-tfiP.js
var import_jsx_runtime = require_jsx_runtime();
function NeedsRoute() {
	const { tab } = Route$8.useSearch();
	if (tab === "give") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/donate" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedsScreen, { tab: tab ?? "goods" });
}
//#endregion
export { NeedsRoute as component };
