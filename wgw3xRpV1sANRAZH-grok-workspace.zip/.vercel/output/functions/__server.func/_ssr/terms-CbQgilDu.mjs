import { a as TermsScreen } from "./info-kxYs0b-S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-CbQgilDu.js
var SplitComponent = TermsScreen;
//#endregion
export { SplitComponent as component };
