import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/photo-z9DeWH38.js
var photo_z9DeWH38_exports = /* @__PURE__ */ __exportAll({
	a: () => photo_exports,
	i: () => loadImage,
	n: () => fitPhotoUnder300kb,
	r: () => jpegKilobytes,
	t: () => PHOTO_BYTE_LIMIT
});
var photo_exports = /* @__PURE__ */ __exportAll$1({
	PHOTO_BYTE_LIMIT: () => PHOTO_BYTE_LIMIT,
	dataUrlBytes: () => dataUrlBytes,
	fitPhotoUnder300kb: () => fitPhotoUnder300kb,
	jpegKilobytes: () => jpegKilobytes,
	loadImage: () => loadImage
});
/** WhatsApp skips storefront photos above this size. Keep the JPEG under it. */
var PHOTO_BYTE_LIMIT = 307200;
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		if (/^https?:/i.test(src)) img.crossOrigin = "anonymous";
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that photo."));
		img.src = src;
	});
}
function dataUrlBytes(dataUrl) {
	const comma = dataUrl.indexOf(",");
	if (comma < 0) return dataUrl.length;
	const b64 = dataUrl.slice(comma + 1).replace(/\s/g, "");
	const pad = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
	return Math.max(0, Math.floor(b64.length * 3 / 4) - pad);
}
function jpegKilobytes(dataUrl) {
	return Math.max(1, Math.round(dataUrlBytes(dataUrl) / 1024));
}
function blobToDataUrl(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that photo."));
		reader.readAsDataURL(blob);
	});
}
function toJpeg(canvas, quality) {
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => blob ? resolve(blob) : reject(/* @__PURE__ */ new Error("Could not read that photo.")), "image/jpeg", quality);
	});
}
function drawFit(img, edge) {
	const scale = Math.min(1, edge / Math.max(img.width, img.height));
	const canvas = document.createElement("canvas");
	canvas.width = Math.max(1, Math.round(img.width * scale));
	canvas.height = Math.max(1, Math.round(img.height * scale));
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not read that photo.");
	ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
	return canvas;
}
/** Scale the photo down and encode JPEG until the file is under 300 KB. */
async function fitPhotoUnder300kb(src) {
	const img = await loadImage(src);
	let edge = Math.min(1200, Math.max(img.width, img.height, 1));
	let quality = .8;
	let last = null;
	for (let attempt = 0; attempt < 14; attempt += 1) {
		const blob = await toJpeg(drawFit(img, edge), quality);
		last = blob;
		if (blob.size <= 307200) return {
			dataUrl: await blobToDataUrl(blob),
			blob,
			bytes: blob.size
		};
		if (quality > .46) quality = Math.round((quality - .12) * 100) / 100;
		else {
			edge = Math.round(edge * .78);
			quality = .7;
			if (edge < 320) break;
		}
	}
	if (!last) throw new Error("Could not read that photo.");
	return {
		dataUrl: await blobToDataUrl(last),
		blob: last,
		bytes: last.size
	};
}
//#endregion
export { photo_z9DeWH38_exports as a, loadImage as i, fitPhotoUnder300kb as n, jpegKilobytes as r, PHOTO_BYTE_LIMIT as t };
