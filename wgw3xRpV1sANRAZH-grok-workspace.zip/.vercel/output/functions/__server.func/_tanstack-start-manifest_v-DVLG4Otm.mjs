//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DVLG4Otm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/account",
			"/chat",
			"/contact",
			"/deals",
			"/donate",
			"/login",
			"/my-haat",
			"/needs",
			"/post-need",
			"/schemes",
			"/sell",
			"/services",
			"/terms",
			"/listing/$listingId",
			"/api/auth/$",
			"/api/photo/$listingId/storefront.jpg"
		],
		preloads: [
			"/assets/index-Du_xY1hS.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-CnB0cY5Z.js",
			"/assets/lazyRouteComponent-Cy0Q68bn.js",
			"/assets/useNavigate-CIG13y2s.js",
			"/assets/jsx-runtime-BtH0gOTJ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Du_xY1hS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B0f65bkH.js", "/assets/market-BlSt3A78.js"]
	},
	"/account": {
		filePath: "/workspace/src/routes/account.tsx",
		children: void 0,
		preloads: ["/assets/account-DpZhs4F_.js", "/assets/info-BQaBYf3r.js"]
	},
	"/chat": {
		filePath: "/workspace/src/routes/chat.tsx",
		children: void 0,
		preloads: ["/assets/chat-DYL2_kw8.js", "/assets/info-BQaBYf3r.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-BaELz6CH.js", "/assets/info-BQaBYf3r.js"]
	},
	"/deals": {
		filePath: "/workspace/src/routes/deals.tsx",
		children: void 0,
		preloads: ["/assets/deals-DXRkC5mp.js", "/assets/market-BlSt3A78.js"]
	},
	"/donate": {
		filePath: "/workspace/src/routes/donate.tsx",
		children: void 0,
		preloads: ["/assets/donate-DCbEOQTB.js", "/assets/community-vzyDUil7.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-Bz2M3594.js", "/assets/signin-D2dcRDro.js"]
	},
	"/my-haat": {
		filePath: "/workspace/src/routes/my-haat.tsx",
		children: void 0,
		preloads: ["/assets/my-haat-qrquwCQV.js", "/assets/market-BlSt3A78.js"]
	},
	"/needs": {
		filePath: "/workspace/src/routes/needs.tsx",
		children: void 0,
		preloads: ["/assets/needs-DDjCv5nJ.js", "/assets/community-vzyDUil7.js"]
	},
	"/post-need": {
		filePath: "/workspace/src/routes/post-need.tsx",
		children: void 0,
		preloads: ["/assets/post-need-D-iu1D9W.js", "/assets/community-vzyDUil7.js"]
	},
	"/schemes": {
		filePath: "/workspace/src/routes/schemes.tsx",
		children: void 0,
		preloads: ["/assets/schemes-s5sWxM62.js", "/assets/info-BQaBYf3r.js"]
	},
	"/sell": {
		filePath: "/workspace/src/routes/sell.tsx",
		children: void 0,
		preloads: ["/assets/sell-Cy2Kfns-.js", "/assets/market-BlSt3A78.js"]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: ["/assets/services-1aexWvsL.js", "/assets/community-vzyDUil7.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-BmGuakhH.js", "/assets/info-BQaBYf3r.js"]
	},
	"/listing/$listingId": {
		filePath: "/workspace/src/routes/listing.$listingId.tsx",
		children: void 0,
		preloads: ["/assets/listing._listingId-Sm0RN8AT.js", "/assets/market-BlSt3A78.js"]
	}
} });
//#endregion
export { tsrStartManifest };
