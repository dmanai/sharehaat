-- Community haat board. Published rows are public storefronts.
-- user_id is the signed-in account (text). Seed rows use the literal 'seed'.

create table if not exists haat_profiles (
  user_id text primary key,
  name text not null default '',
  phone text not null default '',
  seller_type text not null default 'Farmer',
  district text not null default 'Dimapur',
  place text not null default '',
  is_service_provider boolean not null default false,
  service_category text not null default '',
  updated_at timestamptz not null default now()
);

create table if not exists haat_listings (
  id text primary key,
  user_id text not null,
  product_code text not null,
  category text not null,
  listing_kind text not null,
  status text not null,
  title text not null,
  photo_url text not null default '',
  district text not null,
  origin_place text not null,
  seller_name text not null,
  seller_phone text not null,
  seller_type text not null,
  price_inr integer not null,
  price_unit text not null,
  qty double precision not null,
  qty_unit text not null,
  handover text not null,
  landmark text not null default '',
  notes text not null default '',
  created_at bigint not null,
  expires_at bigint not null,
  featured boolean not null default false
);

create index if not exists haat_listings_user_idx on haat_listings (user_id);
create index if not exists haat_listings_status_idx on haat_listings (status, expires_at);

create table if not exists haat_needs (
  id text primary key,
  user_id text not null,
  need_code text not null,
  kind text not null,
  item text not null,
  qty double precision not null,
  qty_unit text not null,
  district text not null,
  place_name text not null,
  needed_by text not null,
  budget_inr integer not null default 0,
  buyer_type text not null,
  buyer_name text not null,
  buyer_phone text not null,
  notes text not null default '',
  status text not null,
  created_at bigint not null,
  photo_url text not null default '',
  need_category_type text not null,
  service_category text not null default '',
  area_type text not null default ''
);

create index if not exists haat_needs_user_idx on haat_needs (user_id);

create table if not exists haat_providers (
  id text primary key,
  user_id text not null,
  provider_name text not null,
  phone text not null,
  service_category text not null,
  area_type text not null,
  district text not null,
  town_or_village text not null,
  experience_years integer not null default 1,
  description text not null default '',
  is_verified boolean not null default false,
  registered_at bigint not null
);

create index if not exists haat_providers_user_idx on haat_providers (user_id);

create table if not exists haat_reviews (
  id text primary key,
  user_id text not null,
  target_id text not null,
  target_type text not null,
  target_name text not null,
  reviewer_name text not null,
  reviewer_phone text not null,
  rating integer not null,
  comment text not null,
  created_at bigint not null
);

create index if not exists haat_reviews_user_idx on haat_reviews (user_id);
