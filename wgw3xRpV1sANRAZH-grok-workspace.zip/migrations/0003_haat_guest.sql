-- Guest lots stay on the board. The claim secret is stored only as a hash.
alter table haat_listings add column if not exists claim_status text not null default 'claimed';
alter table haat_listings add column if not exists claim_token_hash text not null default '';
